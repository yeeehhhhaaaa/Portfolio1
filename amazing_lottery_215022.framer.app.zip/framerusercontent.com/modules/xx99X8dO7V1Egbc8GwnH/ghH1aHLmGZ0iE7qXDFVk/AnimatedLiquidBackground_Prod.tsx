import {
    addPropertyControls,
    ControlType,
    RenderTarget,
    useIsStaticRenderer,
} from "framer"
import React, { useEffect, useRef, useMemo } from "react"
import { useColors } from "../useColors.ts"
import {
    getShaderColorFromString,
    PatternShape,
    warpFragmentShader,
    type WarpUniforms,
    PatternShapes,
    ShaderMount as ShaderMountVanilla,
} from "https://framer.com/m/index-uMsj.js@PVl4bshKvCOZO36e3vK1"
import { cubicBezier, useInView } from "framer-motion"

const speedEase = cubicBezier(0.65, 0, 0.88, 0.77)

const templates = {
    Prism: {
        color1: "#050505",
        color2: "#66B3FF",
        color3: "#FFFFFF",
        rotation: -50,
        proportion: 1,
        scale: 0.01,
        speed: 30,
        distortion: 0,
        swirl: 50,
        swirlIterations: 16,
        softness: 47,
        offset: -299,
        shape: "Checks",
        shapeSize: 45,
    },
    Lava: {
        color1: "#FF9F21",
        color2: "#FF0303",
        color3: "#000000",
        rotation: 114,
        proportion: 100,
        scale: 0.52,
        speed: 30,
        distortion: 7,
        swirl: 18,
        swirlIterations: 20,
        softness: 100,
        offset: 717,
        shape: "Edge",
        shapeSize: 12,
    },
    Plasma: {
        color1: "#B566FF",
        color2: "#000000",
        color3: "#000000",
        rotation: 0,
        proportion: 63,
        scale: 0.75,
        speed: 30,
        distortion: 5,
        swirl: 61,
        swirlIterations: 5,
        softness: 100,
        offset: -168,
        shape: "Checks",
        shapeSize: 28,
    },
    Pulse: {
        color1: "#66FF85",
        color2: "#000000",
        color3: "#000000",
        rotation: -167,
        proportion: 92,
        scale: 0,
        speed: 20,
        distortion: 54,
        swirl: 75,
        swirlIterations: 3,
        softness: 28,
        offset: -813,
        shape: "Checks",
        shapeSize: 79,
    },
    Vortex: {
        color1: "#000000",
        color2: "#FFFFFF",
        color3: "#000000",
        rotation: 50,
        proportion: 41,
        scale: 0.4,
        speed: 20,
        distortion: 0,
        swirl: 100,
        swirlIterations: 3,
        softness: 5,
        offset: -744,
        shape: "Stripes",
        shapeSize: 80,
    },
    Mist: {
        color1: "#050505",
        color2: "#FF66B8",
        color3: "#050505",
        rotation: 0,
        proportion: 33,
        scale: 0.48,
        speed: 39,
        distortion: 4,
        swirl: 65,
        swirlIterations: 5,
        softness: 100,
        offset: -235,
        shape: "Edge",
        shapeSize: 48,
    },
}

/**
 * @framerSupportedLayoutWidth fixed
 * @framerSupportedLayoutHeight fixed
 *
 * @framerDisableUnlink
 *
 * @framerIntrinsicWidth 400
 * @framerIntrinsicHeight 400
 */
export default function AnimatedGradientBackground(props) {
    const isStaticRenderer = useIsStaticRenderer()
    const isCanvas = RenderTarget.current() === RenderTarget.canvas
    const useCustomColors =
        props.preset === "custom" || props.colorMode === "custom"
    const values =
        props.preset === "custom"
            ? props
            : templates[props.preset] || Object.values(templates)[0]

    const [color1, color2, color3] = useColors(
        props.color1,
        props.color2,
        props.color3
    )

    const ref = useRef<HTMLDivElement>(null)
    const isInView = useInView(ref, { once: false, amount: 0.1 })

    const currentSpeed = useMemo(() => {
        if (isCanvas && props.preview) return speedEase(props.speed / 100) * 5
        if (!isStaticRenderer && isInView)
            return speedEase(props.speed / 100) * 5
        return 0
    }, [isInView, isStaticRenderer, props.speed, props.preview, isCanvas])

    return (
        <div
            ref={ref}
            style={{
                borderRadius: props.radius,
                overflow: "hidden",
                position: "relative",
                ...props.style,
            }}
        >
            <Warp
                color1={useCustomColors ? color1 : values.color1}
                color2={useCustomColors ? color2 : values.color2}
                color3={useCustomColors ? color3 : values.color3}
                scale={values.scale}
                proportion={values.proportion / 100}
                distortion={values.distortion / 50}
                swirl={values.swirl / 100}
                swirlIterations={
                    values.swirl === 0 ? 0 : values.swirlIterations
                }
                rotation={(values.rotation * Math.PI) / 180}
                speed={currentSpeed}
                seed={values.offset * 10}
                shape={PatternShapes[values.shape]}
                shapeScale={values.shapeSize / 100}
                softness={values.softness / 100}
                style={props.style}
            />
            {props.noise && props.noise.opacity > 0 && (
                <div
                    style={{
                        position: "absolute",
                        inset: 0,
                        backgroundImage: `url("https://framerusercontent.com/images/g0QcWrxr87K0ufOxIUFBakwYA8.png")`,
                        backgroundSize: props.noise.scale * 200,
                        backgroundRepeat: "repeat",
                        opacity: props.noise.opacity / 2,
                    }}
                />
            )}
        </div>
    )
}

addPropertyControls(AnimatedGradientBackground, {
    preset: {
        type: ControlType.Enum,
        defaultValue: Object.keys(templates)[0],
        options: [...Object.keys(templates), "custom"],
        optionTitles: [...Object.keys(templates), "Custom"],
    },
    preview: {
        type: ControlType.Boolean,
        defaultValue: false,
    },
    colorMode: {
        type: ControlType.Enum,
        defaultValue: "preset",
        options: ["preset", "custom"],
        optionTitles: ["Preset", "Custom"],
        displaySegmentedControl: true,
        title: "Colors",
        hidden: (props) => props.preset === "custom",
    },
    color1: {
        type: ControlType.Color,
        defaultValue: "#262626",
        hidden: (props) =>
            props.preset !== "custom" && props.colorMode === "preset",
    },
    color2: {
        type: ControlType.Color,
        defaultValue: "#75c1f0",
        hidden: (props) =>
            props.preset !== "custom" && props.colorMode === "preset",
    },
    color3: {
        type: ControlType.Color,
        defaultValue: "#ffffff",
        hidden: (props) =>
            props.preset !== "custom" && props.colorMode === "preset",
    },
    noise: {
        type: ControlType.Object,
        optional: true,
        icon: "effect",
        controls: {
            opacity: {
                type: ControlType.Number,
                defaultValue: 0.5,
                min: 0,
                max: 1,
                step: 0.01,
            },
            scale: {
                type: ControlType.Number,
                defaultValue: 1,
                min: 0.2,
                max: 2,
                step: 0.1,
            },
        },
    },
    rotation: {
        type: ControlType.Number,
        defaultValue: 0,
        min: -360,
        max: 360,
        step: 1,
        unit: "°",
        hidden: (props) => props.preset !== "custom",
    },
    proportion: {
        type: ControlType.Number,
        defaultValue: 35,
        min: 0,
        max: 100,
        step: 1,
        hidden: (props) => props.preset !== "custom",
    },
    scale: {
        type: ControlType.Number,
        defaultValue: 1,
        min: 0,
        max: 10,
        step: 0.01,
        hidden: (props) => props.preset !== "custom",
    },
    speed: {
        type: ControlType.Number,
        defaultValue: 25,
        step: 1,
        min: 0,
        max: 100,
    },
    distortion: {
        type: ControlType.Number,
        defaultValue: 12,
        min: 0,
        max: 100,
        step: 1,
        hidden: (props) => props.preset !== "custom",
    },
    swirl: {
        type: ControlType.Number,
        defaultValue: 80,
        min: 0,
        max: 100,
        step: 1,
        hidden: (props) => props.preset !== "custom",
    },
    swirlIterations: {
        type: ControlType.Number,
        defaultValue: 10,
        min: 0,
        max: 20,
        step: 1,
        title: "Iterations",
        hidden: (props) => props.swirl === 0 || props.preset !== "custom",
    },
    softness: {
        type: ControlType.Number,
        defaultValue: 100,
        min: 0,
        max: 100,
        step: 1,
        hidden: (props) => props.preset !== "custom",
    },
    offset: {
        type: ControlType.Number,
        defaultValue: 0,
        min: -1000,
        max: 1000,
        step: 1,
        hidden: (props) => props.preset !== "custom",
    },
    shape: {
        type: ControlType.Enum,
        defaultValue: "Checks",
        options: Object.keys(PatternShapes),
        hidden: (props) => props.preset !== "custom",
    },
    shapeSize: {
        type: ControlType.Number,
        defaultValue: 10,
        min: 0,
        max: 100,
        step: 1,
        hidden: (props) => props.preset !== "custom",
    },
    radius: {
        type: ControlType.BorderRadius,
        defaultValue: "0px",
    },
})

//////////////////////////////

const defaultPreset: WarpPreset = {
    name: "Default",
    params: {
        scale: 1,
        rotation: 0,
        speed: 20,
        seed: 0,
        color1: "hsla(0, 0%, 15%, 1)",
        color2: "hsla(203, 80%, 70%, 1)",
        color3: "hsla(0, 0%, 100%, 1)",
        proportion: 0.35,
        softness: 1,
        distortion: 0.25,
        swirl: 0.8,
        swirlIterations: 10,
        shapeScale: 0.1,
        shape: PatternShapes.Checks,
    },
}

type WarpParams = {
    scale?: number
    rotation?: number
    color1?: string
    color2?: string
    color3?: string
    proportion?: number
    softness?: number
    distortion?: number
    swirl?: number
    swirlIterations?: number
    shapeScale?: number
    shape?: PatternShape
} & GlobalParams

type WarpProps = Omit<ShaderMountProps, "fragmentShader"> & WarpParams

type WarpPreset = { name: string; params: Required<WarpParams> }

// Due to Leva controls limitation:
// 1) keep default colors in HSLA format to keep alpha channel
// 2) don't use decimal values on HSL values (to avoid button highlight bug)

const Warp = (props: WarpProps): JSX.Element => {
    const uniforms: WarpUniforms = useMemo(() => {
        return {
            u_scale: props.scale ?? defaultPreset.params.scale,
            u_rotation: props.rotation ?? defaultPreset.params.rotation,
            u_color1: getShaderColorFromString(
                props.color1,
                defaultPreset.params.color1
            ),
            u_color2: getShaderColorFromString(
                props.color2,
                defaultPreset.params.color2
            ),
            u_color3: getShaderColorFromString(
                props.color3,
                defaultPreset.params.color2
            ),
            u_proportion: props.proportion ?? defaultPreset.params.proportion,
            u_softness: props.softness ?? defaultPreset.params.softness,
            u_distortion: props.distortion ?? defaultPreset.params.distortion,
            u_swirl: props.swirl ?? defaultPreset.params.swirl,
            u_swirlIterations:
                props.swirlIterations ?? defaultPreset.params.swirlIterations,
            u_shapeScale: props.shapeScale ?? defaultPreset.params.shapeScale,
            u_shape: props.shape ?? defaultPreset.params.shape,
        }
    }, [
        props.scale,
        props.rotation,
        props.color1,
        props.color2,
        props.color3,
        props.proportion,
        props.softness,
        props.distortion,
        props.swirl,
        props.swirlIterations,
        props.shapeScale,
        props.shape,
        props.speed,
    ])

    return (
        <ShaderMount
            {...props}
            fragmentShader={warpFragmentShader}
            uniforms={uniforms}
        />
    )
}

interface ShaderMountProps {
    ref?: React.RefObject<HTMLCanvasElement>
    fragmentShader: string
    style?: React.CSSProperties
    uniforms?: Record<string, number | number[]>
    webGlContextAttributes?: WebGLContextAttributes
    speed?: number
    seed?: number
}

/** Params that every shader can set as part of their controls */
type GlobalParams = Pick<ShaderMountProps, "speed" | "seed">

const ShaderMount: React.FC<ShaderMountProps> = ({
    ref,
    fragmentShader,
    style,
    uniforms = {},
    webGlContextAttributes,
    speed = 1,
    seed = 0,
}) => {
    const canvasRef = ref ?? useRef<HTMLCanvasElement>(null)
    const shaderMountRef = useRef<ShaderMountVanilla | null>(null)

    useEffect(() => {
        if (canvasRef.current) {
            shaderMountRef.current = new ShaderMountVanilla(
                canvasRef.current,
                fragmentShader,
                uniforms,
                webGlContextAttributes,
                speed,
                seed
            )
        }

        return () => {
            shaderMountRef.current?.dispose()
        }
    }, [fragmentShader, webGlContextAttributes])

    useEffect(() => {
        shaderMountRef.current?.setUniforms(uniforms)
    }, [uniforms])

    useEffect(() => {
        shaderMountRef.current?.setSpeed(speed)
    }, [speed])

    useEffect(() => {
        shaderMountRef.current?.setSeed(seed)
    }, [seed])

    return <canvas ref={canvasRef} style={style} />
}

function mapRange(value, fromLow, fromHigh, toLow, toHigh) {
    if (fromLow === fromHigh) {
        return toLow
    }
    const percentage = (value - fromLow) / (fromHigh - fromLow)
    return toLow + percentage * (toHigh - toLow)
}

AnimatedGradientBackground.displayName = "Animated Gradient Background"
