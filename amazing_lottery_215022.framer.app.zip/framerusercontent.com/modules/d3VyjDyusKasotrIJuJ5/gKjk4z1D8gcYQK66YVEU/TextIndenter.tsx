// Text component with first-line indent functionality and overflow protection
import { useMemo, type CSSProperties } from "react"
import { addPropertyControls, ControlType } from "framer"

interface TextIndenterProps {
    text: string
    indentSpaces: number
    font: any
    textColor: string
    style?: CSSProperties
}

/**
 * @framerSupportedLayoutWidth any-prefer-fixed
 * @framerSupportedLayoutHeight any-prefer-fixed
 */
export default function TextIndenter(props: TextIndenterProps) {
    const {
        text,
        indentSpaces,
        font,
        textColor,
    } = props

    const processedText = useMemo(() => {
        // Handle empty or whitespace-only text
        if (!text || text.trim().length === 0) {
            return text || ""
        }

        // Apply indent
        const spaces = ' '.repeat(Math.max(0, Math.min(indentSpaces, 50)))
        return spaces + text
    }, [text, indentSpaces])

    const isFixedWidth = props?.style && props.style.width === "100%"

    return (
        <div
            style={{
                ...props.style,
                position: "relative",
                ...(isFixedWidth ? { ...props?.style } : { minWidth: "max-content" }),
            }}
        >
            <div
                style={{
                    ...font,
                    color: textColor,
                    whiteSpace: "pre-wrap",
                    wordBreak: "break-word",
                    overflowWrap: "break-word",
                    ...(isFixedWidth ? {} : { width: "max-content" }),
                }}
            >
                {processedText || "Enter your text here..."}
            </div>
        </div>
    )
}

addPropertyControls(TextIndenter, {
    text: {
        type: ControlType.String,
        title: "Text",
        defaultValue: "This is a sample paragraph that will have its first line indented. The indent will only apply to the very beginning of this text, creating a traditional paragraph formatting style.",
        displayTextArea: true,
    },
    indentSpaces: {
        type: ControlType.Number,
        title: "Indent Spaces",
        defaultValue: 4,
        min: 0,
        max: 50,
        step: 1,
        displayStepper: true,
    },
    font: {
        type: ControlType.Font,
        title: "Font",
        defaultValue: {
            fontSize: "15px",
            letterSpacing: "-0.01em",
            lineHeight: "1.3em",
        },
        controls: "extended",
    },
    textColor: {
        type: ControlType.Color,
        title: "Text Color",
        defaultValue: "#000000",
    },
})