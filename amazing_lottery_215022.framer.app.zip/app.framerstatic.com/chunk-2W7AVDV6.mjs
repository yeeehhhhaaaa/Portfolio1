import{a as t}from"https://app.framerstatic.com/chunk-JB2N3EQZ.mjs";import{e as n}from"https://app.framerstatic.com/chunk-AHQIRSXG.mjs";var r=n(t(),1);function u(e){return e+1}function o(){let[,e]=(0,r.useReducer)(u,0);return e}export{o as a};
//# sourceMappingURL=https://app.framerstatic.com/chunk-2W7AVDV6.mjs.map
