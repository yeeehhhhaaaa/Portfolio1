function E(){return Math.floor(Math.random()*4294967285)}export{E as a};
//# sourceMappingURL=https://app.framerstatic.com/chunk-FQ4GQVNA.mjs.map
