import{e as r}from"https://app.framerstatic.com/chunk-BY7KEIXE.mjs";var s={0:!0,1:!0,2:!0,3:!0,4:!0,6:!0,5:!0};function n(o){return r(o)&&s[o]===!0}export{n as a};
//# sourceMappingURL=https://app.framerstatic.com/chunk-AZIC3CCF.mjs.map
