import{i as o}from"https://app.framerstatic.com/chunk-NLPNJSOY.mjs";function r(t){return o.isAutomation?t:`/s/app.0ea0c8cbab9180f75279d5ce9db4a7917c1db155/${t}`}function e(t){let{host:n}=window.location;return`//${n}${r(t)}`}export{r as a,e as b};
//# sourceMappingURL=https://app.framerstatic.com/chunk-O7QNUISX.mjs.map
