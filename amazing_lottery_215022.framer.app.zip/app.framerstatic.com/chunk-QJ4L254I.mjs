import{a as i}from"https://app.framerstatic.com/chunk-ZTI6U46V.mjs";import{c as n}from"https://app.framerstatic.com/chunk-AHQIRSXG.mjs";var a=n(t=>{"use strict";var e=i();t.createRoot=e.createRoot,t.hydrateRoot=e.hydrateRoot;var s});export{a};
//# sourceMappingURL=https://app.framerstatic.com/chunk-QJ4L254I.mjs.map
