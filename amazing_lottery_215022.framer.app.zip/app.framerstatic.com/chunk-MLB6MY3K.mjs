import{a as or,b as so}from"https://app.framerstatic.com/chunk-4F33BGHI.mjs";import{$a as ns,Ag as zs,Be as hs,Bh as Ks,Ce as gs,Cg as Os,Ch as ar,De as ys,Dh as ea,Eb as os,Ee as Qn,Eg as _s,Gb as Jn,Ge as Ss,Gg as $s,Kd as cs,Ld as Hn,Le as vs,Me as bs,Oe as Xn,Sd as Yr,Ub as is,Wd as Zr,Xd as ds,ch as js,dh as Ws,fc as ss,gh as nr,if as Is,ih as Gs,jh as dn,kh as Js,le as ps,lf as ee,mf as er,mh as ot,nf as Vs,nh as rr,ob as rs,of as Fs,oh as At,pf as Es,ph as qs,qe as eo,qf as io,qh as yt,se as fs,sf as Ms,uh as sr,ve as Kn,vh as Hs,we as ms,xg as Us,yg as As,yh as Ue,zg as Bs,zh as St}from"https://app.framerstatic.com/chunk-XBUQY6IO.mjs";import{m as as,p as Ls}from"https://app.framerstatic.com/chunk-RZZ76PXG.mjs";import{a as oo,b as Ns,c as Ps,d as xs}from"https://app.framerstatic.com/chunk-YZJ2HVXJ.mjs";import{a as Ds}from"https://app.framerstatic.com/chunk-LVZYI5SZ.mjs";import{a as Rs,d as pe,e as to,f as Yn,g as no,h as Zn,i as ro}from"https://app.framerstatic.com/chunk-JCMOIATJ.mjs";import{b as cn}from"https://app.framerstatic.com/chunk-7IR24JK2.mjs";import{g as it,j as ir}from"https://app.framerstatic.com/chunk-R2H2AYE5.mjs";import{L as ts}from"https://app.framerstatic.com/chunk-H2F5HPTW.mjs";import{i as ks}from"https://app.framerstatic.com/chunk-2ZSTXRWK.mjs";import{A as Qs,B as Xs,C as Ys,D as Zs,o as Cs,p as Ts,q as ws,y as tr}from"https://app.framerstatic.com/chunk-Q5Q62XNI.mjs";import{$g as nt,Ah as Qr,Bh as rt,Eh as Zi,Hf as Qi,If as Xi,Jb as qr,Kc as qi,Lc as Hi,Nh as jn,Oh as Xr,Y as be,Yc as Ki,Z as Ri,_ as Di,_h as Wn,ba as Ni,ci as es,eb as ji,fb as Jr,hb as Wi,ic as Hr,ii as an,jb as Gi,lb as Ji,rh as $n,xg as Yi,yc as On,yg as _n,zh as Kr}from"https://app.framerstatic.com/chunk-WZS7KLXF.mjs";import{f as Pe}from"https://app.framerstatic.com/chunk-BC6YGFEV.mjs";import{c as Oi,d as _i}from"https://app.framerstatic.com/chunk-DXEB74DT.mjs";import{e as Ii,f as Je}from"https://app.framerstatic.com/chunk-O32NGOFX.mjs";import{mf as Gn}from"https://app.framerstatic.com/chunk-YANCMUIX.mjs";import{f as ls,i as us}from"https://app.framerstatic.com/chunk-AFVYTKXH.mjs";import{$f as rn,$l as tt,Bi as Li,Cc as Ci,Fb as Si,Fd as Ti,Fl as b,Gb as vi,Hd as wi,Il as En,Lc as $r,Ll as Mn,Lo as $i,Mg as sn,Ml as kn,Ol as Ui,Rh as Pi,Yl as Ai,Zh as Gr,am as An,b as Ko,bg as on,bm as kt,bo as zi,cm as Ut,dm as Bn,eg as jr,gg as Wr,hh as ke,hi as xi,jk as Ei,uj as Vi,wc as bi,xj as Fi,zb as Ge}from"https://app.framerstatic.com/chunk-HMZVI6V5.mjs";import{a as qn}from"https://app.framerstatic.com/chunk-RFUJAADQ.mjs";import{b as gi}from"https://app.framerstatic.com/chunk-LV2ZCWZ6.mjs";import{$c as Ur,$d as qo,Ae as ht,Be as Ho,Cp as fi,Dd as Z,Ed as Ar,Ep as mi,Et as Mi,It as Mt,Jt as ki,K as Nn,Ll as si,Ln as ci,Ok as ii,Pj as ri,Ut as Bi,Vm as ai,Wt as zn,Xj as oi,Ys as gt,_d as Et,_n as di,bd as Vn,bt as Un,di as ti,eo as li,fj as z,fo as zr,gh as Yo,gj as w,go as Or,hd as mt,hj as ni,ic as jo,id as Fn,ij as $,jh as Zo,kj as E,lj as u,ls as yi,mh as ei,mj as Ee,nc as Ln,od as Go,oj as Me,oq as hi,pb as xn,pc as Wo,pd as Ne,po as ui,qd as oe,rd as de,rr as et,sd as F,sk as Br,tb as $o,ud as le,vd as ue,vf as Qo,vs as _r,wd as Jo,wf as Xo,xb as kr,zd as Ze}from"https://app.framerstatic.com/chunk-LGEU5DK3.mjs";import{$ as pi,V as _o,y as Oo}from"https://app.framerstatic.com/chunk-MY2IBMSM.mjs";import{a as Vt}from"https://app.framerstatic.com/chunk-WGGGXUCK.mjs";import{o as Ft}from"https://app.framerstatic.com/chunk-W2T2NRHF.mjs";import{b as K,e as B,g as Mr,j as U,m as nn}from"https://app.framerstatic.com/chunk-BY7KEIXE.mjs";import{a as Er,b as Pn}from"https://app.framerstatic.com/chunk-JB2N3EQZ.mjs";import{i as De}from"https://app.framerstatic.com/chunk-NLPNJSOY.mjs";import{c as zo}from"https://app.framerstatic.com/chunk-IUEIJETG.mjs";import{$a as H,Aa as Re,Pa as ve,W as Bo,X as Pt,Xa as In,Y as xt,Za as Rn,_ as en,bb as Dn,f as Ao,ha as N,sa as tn,ta as Lt,xa as Q,za as Fe}from"https://app.framerstatic.com/chunk-6CJRAIE6.mjs";import{a as S,b as Se}from"https://app.framerstatic.com/chunk-EEJLKBFC.mjs";import{e as ft,j as g,k as T,l as Y,m as ye,n as Uo}from"https://app.framerstatic.com/chunk-AHQIRSXG.mjs";var rc=N("DocumentLoader"),ao=N("remote:verify"),cr=class o{constructor(t,e,n){this.componentLoader=t;this.parser=e;this.settings=n;g(this,"canvasTreeVersion",0);g(this,"chunkingHints");this.canvasTreeVersion=this.parser.version,this.chunkingHints=this.parser.getChunkingHints()}static async createPartialParser(t,e,n){if(typeof t=="string"){let r=new Ps(t);return new o(e,r,n)}else{let r=new xs(t);return new o(e,r,n)}}readFirstPage(){let t=!1,e=[];if(this.settings.activeNodeId&&(e.push(...this.parser.getPagesContainingId(this.settings.activeNodeId)),t=e.some(n=>Ue(this.parser.getShallowPage(n)))),!t){let n=this.parser.getShallowPages(),{maybeFirstPage:r}=sr(n,this.parser.getHomePageNodeID());e.push(r.id);let i=0,s;for(let a of n){if(F(a,!0)&&i++,i>1)break;le(a,!0)&&(s??=a.id)}i===1&&s&&s!==r.id&&e.push(s)}return rc.debug("loadPartialDocument():",e),Ds(this.parser,this.componentLoader,e,this.settings.treeServices)}getScopesToLoad(){return this.parser.getPagesToLoad()}getParsedPageById(t){return this.parser.getParsedPageById(t)}buildPage(t){if(!t)return;let e=[],n=ao.isLoggingTraceMessages()?[]:void 0,r=nt(t,this.parser.root.id,{extraChecksAndFixes:!0,errors:e,warnings:n});if(r&&Zn(r,e),e.length>0&&ao.warn("errors loading server tree: "+e.join(`
`)),n&&n.length>0&&ao.trace("warnings loading server tree: "+n.join(`
`)),!!r)return r}};var co=N("app");function $l(o){return o.treeReflectsDocument?oc(o.tree):null}function oc(o){return o.toJS()}function jl(o){function t(e){let{__class:n,width:r,height:i,top:s,bottom:a,left:c,right:d}=e,{children:p}=e;return p?(p=p.map(t),{__class:n,width:r,height:i,top:s,bottom:a,left:c,right:d,children:p}):e.styledText?{__class:n,width:r,height:i,top:s,bottom:a,left:c,right:d,text:e.styledText.blocks.map(l=>l.text)}:{__class:n,width:r,height:i,top:s,bottom:a,left:c,right:d}}return t(o.tree.toJS().root)}function Wl(o,t){let e,n=new XMLHttpRequest;n.open("GET",o.toString(),!1);try{n.send(),e=JSON.parse(n.responseText)}catch(r){co.error(`Retrieving document \u201C${o}\u201D failed. (${r})`)}return lo(e,t)}function ta(o){De.isTest||o.forEach(t=>{co.warn("[repaired]",t)})}function lo(o,t){let e=[];try{let n=Yn(o,t,e);return ta(e),n}catch(n){throw ta(e),co.warn("tree failed to verify:",n),n}}var ln=class extends Error{constructor(){super("cancelled"),this.name="CancelledError"}},dr=class{constructor(t){this.requestIdleCallback=t;g(this,"resumePromiseResolve");g(this,"resumePromise");g(this,"backgroundMode",!1);g(this,"done",!1);g(this,"firstError");g(this,"debugStepListener")}debugResumeOneStep(){this.resume(),this.pause()}currentMode(){return this.backgroundMode?"slow":"fast"}isDone(){return!!this.firstError||this.done}isSuccess(){return!this.firstError&&this.done}isCancelled(){return!!this.firstError&&this.firstError instanceof ln}isError(){return!!this.firstError&&!(this.firstError instanceof ln)}getError(){return this.firstError}cancel(){this.isDone()||(this.firstError=new ln)}error(t){return this.isDone()||(this.firstError=t),t}pause(){this.firstError||this.resumePromise||(this.resumePromise=new Promise(t=>{this.resumePromiseResolve=t}))}resume(){let t=this.resumePromiseResolve;t&&(this.resumePromise=void 0,this.resumePromiseResolve=void 0,t())}isPaused(){return!!this.resumePromise}fast(){return this.backgroundMode=!1,this}slow(){return this.backgroundMode=!0,this}async run(t){S(!this.isDone(),"task is already done");try{await t()}catch(e){throw e instanceof Error?this.error(e):this.error(new Error(String(e??"Unknown Error"),{cause:e}))}finally{this.done=!0}}async sleep(t){if(this.debugStepListener?.(),await Ao(t),this.resumePromise&&await this.resumePromise,this.debugStepListener?.(),this.resumePromise&&await this.resumePromise,this.firstError)throw this.firstError}async yield(){if(this.debugStepListener?.(),this.resumePromise?await this.resumePromise:this.backgroundMode?await new Promise(t=>{this.requestIdleCallback?this.requestIdleCallback(t):typeof requestIdleCallback=="function"?requestIdleCallback(t):setTimeout(t,0)}):await Rn(),this.resumePromise&&await this.resumePromise,this.debugStepListener?.(),this.resumePromise&&await this.resumePromise,this.firstError)throw this.firstError}};var O=N("DocumentLoader"),lr=10,un=1e3;function Bt(o){return o<1024*.75?`${Math.round(o)}b`:o<1024*1024*.75?`${(o/1024).toFixed(2)}kb`:`${(o/1024/1024).toFixed(2)}Mb`}function Ce(o){return o<200?`${o.toFixed(1)}ms`:o<20*1e3?`${(o/1e3).toFixed(3)}s`:`${Math.round(o/1e3)}s`}var qe=class extends Rs.default{constructor(e,n,r,i){super();this.componentLoader=e;this.treeVersion=n;this.documentURL=r;this.settings=i;g(this,"scheduler");g(this,"activelyLoadingScope",!1);g(this,"retryCount",0);g(this,"scopesToLoad",new Set);g(this,"prioritizedScopeIds",new Set);g(this,"currentLoadingScope");g(this,"partialParser");g(this,"canvasTreeVersion",0);g(this,"documentSize",0);g(this,"loadedFirstScope",!1);g(this,"loadingDuration",0);g(this,"parsingDuration",0);g(this,"debugPaused",!1);g(this,"loadingScopesPaused",!1);g(this,"loadAllDataPriority",0);g(this,"updatePauseResumeState",()=>{if(!this.loadedFirstScope){this.scheduler.fast(),this.scheduler.resume();return}let e=this.loadAllDataPriority>0||this.prioritizedScopeIds.size>0,n=this.loadingScopesPaused||this.debugPaused;e?this.scheduler.fast():this.scheduler.slow(),e||!n||this.scopesToLoad.size<=0?this.scheduler.resume():this.scheduler.pause()});g(this,"tree");g(this,"loadCallbacksPerScope",new Map);g(this,"addedByDiff",new Set);g(this,"removedByDiff",new Set);this.scheduler=new dr(i.requestIdleCallback),O.debug("new:",this.treeVersion,this.documentURL)}pauseLoadingScopes(){this.loadingScopesPaused||(this.loadingScopesPaused=!0,O.debug("pauseLoadingScopes"),this.updatePauseResumeState())}resumeLoadingScopes(){this.loadingScopesPaused&&(this.loadingScopesPaused=!1,O.debug("resumeLoadingScopes"),this.updatePauseResumeState())}prioritizeLoadingAllData(e){let n="preload"in e&&e.preload;if(n&&Xr())return()=>{};let r=performance.now(),i=this.numberOfScopesToLoad();this.loadAllDataPriority=Math.max(1,this.loadAllDataPriority+1),O.debug("prioritizeLoadingScopes:",this.loadAllDataPriority),this.updatePauseResumeState();let s=n||"doNotTrack"in e&&e.doNotTrack,a=!1,c=s?void 0:this.afterAllDataLoaded(()=>{if(a)return;S("operationName"in e,"operationName is required");let f=performance.now()-r;Pe("fulltree_force_load",{operationName:e.operationName,durationMs:Math.round(f),background:e.operationInBackground,shallowScopesCount:i})}),p=Ft.isOn("dataOnlyTree")&&jn()?this.afterAllDataLoaded(()=>{if(a)return;S(!("preload"in e),"preload should never load all data");let l={operationName:e.operationName,durationMs:Math.round(performance.now()-r),background:e.operationInBackground,shallowScopesCount:i};O.reportError(new Error("Full tree loaded"),l,{operationName:e.operationName})}):void 0;return()=>{a||(a=!0,c?.(),p?.(),this.stopPrioritizingLoadingAllData())}}stopPrioritizingLoadingAllData(){this.loadAllDataPriority-=1,O.debug("stopPrioritizingLoadingScopes:",this.loadAllDataPriority),this.updatePauseResumeState()}debugPause(){this.debugPaused||(this.debugPaused=!0,O.debug("debugPause"),this.updatePauseResumeState())}debugResume(){this.debugPaused&&(this.debugPaused=!1,O.debug("debugResume"),this.updatePauseResumeState())}isDebugPaused(){return this.debugPaused}afterAllDataLoaded(e){let n=this.scopesToLoad.size===0;if(e){if(n){let r=!1;return queueMicrotask(()=>{r||e()}),()=>{r=!0}}return this.once("loadedAllData",e),()=>{this.off("loadedAllData",e)}}return n?Promise.resolve():new Promise(r=>{this.once("loadedAllData",r)})}async start(){await this.scheduler.run(async()=>{O.debug("start"),pe("parsingInit"),this.updatePauseResumeState();let e=performance.now(),n=await this.loadData();if(this.loadingDuration=performance.now()-e,await this.scheduler.yield(),!this.settings.partialParsing||typeof n=="string"&&!Ns(n))return this.parseFullDocumentSync(n);let r=await this.loadDocumentVersion(n);await this.scheduler.yield(),this.tree=await this.loadFirstTree(r),await this.loadAllScopesAsync()})}async loadAllScopesAsync(){this.loadedFirstScope=!0,this.updatePauseResumeState(),await this.scheduler.yield(),pe("parsingResume");let e;for(;(e=this.nextScopeIdToLoad())!==void 0;)await this.loadScopeAsync(e),this.updatePauseResumeState(),await this.scheduler.yield();await this.emitWrapped(()=>{S(this.tree,"tree must have been set"),this.tree.setService("loader",void 0),this.emit("loadedAllData")}),O.debug("done",Bt(this.documentSize),"loading:",Ce(this.loadingDuration),"parsing:",Ce(this.parsingDuration))}async loadData(){if(this.settings.loadedData)return this.settings.loadedData;O.debug("Document in cache is not up to date. Tree version:",this.treeVersion);let e=this.settings.initData,n=e?.version===this.treeVersion,r=e?.prefetchPromise;if(e&&delete e.prefetchPromise,n&&r){O.debug("loadData: prefetch");let c=await r;if(r.then(d=>d.duration).then(d=>{pe("dataLoad",d)}),await this.scheduler.yield(),c.buffer){O.debug("loadData: prefetch bytes parser");let d=await c.buffer;return await this.scheduler.yield(),c.status<200||c.status>=300?this.handleErrorAndRetry(c.status,"Error loading project data"):new Uint8Array(d)}if(c.text){let d=await c.text;return await this.scheduler.yield(),c.status<200||c.status>=300?this.handleErrorAndRetry(c.status,d):d}}O.debug("loadData: fetch");let i;this.settings.refreshAccessToken&&(i=await this.settings.refreshAccessToken({}),await this.scheduler.yield());let s=await fetch(this.documentURL,i);await this.scheduler.yield();function a(c){if(!c.body)return!1;let d=new URLSearchParams(window.location.search).has("bytes"),p=document.cookie.includes("bytes-parser=true"),l=parseInt(c.headers.get("Uncompressed-Content-Length")??"0",10)>2e8;return d&&(document.cookie="bytes-parser=true; path=/;"),d||p||l}if(pe("dataLoad"),s.status<200||s.status>=300){let c=await s.text();return this.handleErrorAndRetry(s.status,c)}if(a(s)){O.debug("loadData: using streaming parser");let c=await s.arrayBuffer();return new Uint8Array(c)}else{O.debug("loadData: using text parser");let c=await s.text();return await this.scheduler.yield(),c}}async handleErrorAndRetry(e,n){let r=!1;try{r=JSON.parse(n).retry}catch{}if(r&&this.retryCount<lr)return O.debug("onErrorStatusLoaded, retry:",this.retryCount),await this.scheduler.sleep(this.retryCount*un+Math.random()*un),this.retryCount+=1,this.loadData();throw Error(r?"Too many retries":`Fetch Error: ${e} - ${n}`)}parseFullDocumentSync(e){if(typeof e!="string")throw new Error("Full document sync parsing requires string data, not ReadableStream");let n=performance.now();this.documentSize=e.length;let r=JSON.parse(e);if(!B(r.version))throw Error("cannot read document version");if(this.canvasTreeVersion=r.version,O.debug("parseFullDocumentSync",this.canvasTreeVersion,Bt(this.documentSize),Ce(this.loadingDuration)),this.emit("loadedDocumentVersion",r.version),this.scheduler.isDone())return;let i=lo(r,this.componentLoader);this.emit("loadedFirstData",i),!this.scheduler.isDone()&&(this.emit("loadedAllData"),this.parsingDuration+=performance.now()-n,pe("parsingFirstPage"),O.debug("done",Bt(this.documentSize),"loading:",Ce(this.loadingDuration),"parsing:",Ce(this.parsingDuration)))}hasLoadedScope(e){let n=this.scopesToLoad.has(e),r=this.currentLoadingScope?.id===e;return!n&&!r}numberOfScopesToLoad(){return this.scopesToLoad.size}prioritizeLoadingScope(e,n){let r,i;if(typeof n=="function")this.addScopeLoadCallback(e,n);else if(n&&"onLoaded"in n)this.addScopeLoadCallback(e,n.onLoaded),i=n;else{let s=new In;r=s,this.addScopeLoadCallback(e,s.resolve),i=n}if(!(i?.preload&&Xr()))return this.scopesToLoad.has(e)&&(this.prioritizedScopeIds.add(e),this.updatePauseResumeState(),this.addScopeLoadCallback(e,this.updatePauseResumeState)),r}nextScopeIdToLoad(){for(let n of this.prioritizedScopeIds)if(this.prioritizedScopeIds.delete(n),!!this.scopesToLoad.has(n))return this.scopesToLoad.delete(n),this.scheduler.fast(),n;let e=this.loadAllDataPriority>0;this.settings.loadInBackground&&!e?this.scheduler.slow():this.scheduler.fast();for(let n of this.scopesToLoad)return this.scopesToLoad.delete(n),n}async loadDocumentVersion(e){let n=performance.now(),r=await cr.createPartialParser(e,this.componentLoader,this.settings);return typeof e=="string"?this.documentSize=e.length:this.documentSize=0,this.canvasTreeVersion=r.canvasTreeVersion,this.parsingDuration+=performance.now()-n,O.debug("loadDocumentVersion",this.canvasTreeVersion,typeof e=="string"?Bt(this.documentSize):"stream",Ce(this.loadingDuration)),await this.emitWrapped(()=>{if(this.scheduler.isDone())return;let i=performance.now();this.emit("loadedDocumentVersion",this.canvasTreeVersion),this.parsingDuration+=performance.now()-i}),this.partialParser=r,r}async loadFirstTree(e){let n=performance.now(),r=e.readFirstPage();this.scopesToLoad=e.getScopesToLoad();for(let i of this.scopesToLoad){let s=r.get(i);s&&(s.cache.isShallowLoad=!0)}return this.parsingDuration+=performance.now()-n,O.debug("loadFirstTree",Ce(this.parsingDuration)),await this.emitWrapped(()=>{if(this.scheduler.isDone())return;let i=performance.now();r.setService("loader",this),r.chunkingHints=e.chunkingHints,this.emit("loadedFirstData",r),pe("parsingFirstPage"),this.parsingDuration+=performance.now()-i}),r}async loadScopeAsync(e){S(!this.currentLoadingScope,"already have a currently loading scope"),this.activelyLoadingScope=!0,this.currentLoadingScope=this.createLoadingScope(e);let n=await this.currentLoadingScope.run(this.scheduler);if(O.debug("loadScopeAsync:",e,Ce(n.duration),"scheduler mode:",this.scheduler.currentMode()),!n.hasNode()){this.activelyLoadingScope=!1;return}await this.emitWrapped(()=>{if(this.activelyLoadingScope=!1,this.scheduler.isDone())return;let r=performance.now(),i=n.take();this.currentLoadingScope=void 0,i&&(this.emit("loadedScope",i),this.parsingDuration+=n.duration+performance.now()-r,this.signalScopeLoadCallbacks(i.id))})}createLoadingScope(e){return S(this.partialParser,"loadScope before the parser is available"),new uo(e,this.partialParser)}loadScope(e){if(this.currentLoadingScope?.id===e){let r=this.currentLoadingScope.force();return this.parsingDuration+=r.duration,this.currentLoadingScope=void 0,r.take()}if(this.prioritizedScopeIds.delete(e),!this.scopesToLoad.has(e))return;this.scopesToLoad.delete(e);let n=this.createLoadingScope(e).force();return this.parsingDuration+=n.duration,O.debug("loadScope:",e,Ce(n.duration)),this.signalScopeLoadCallbacks(e),n.take()}addScopeLoadCallback(e,n){if(!n)return;if(this.hasLoadedScope(e)){setTimeout(n);return}let r=this.loadCallbacksPerScope.get(e)??[];r.push(n),this.loadCallbacksPerScope.set(e,r)}signalScopeLoadCallbacks(e){setTimeout(()=>{let n=this.loadCallbacksPerScope.get(e);if(n){for(let r of n)r();this.loadCallbacksPerScope.delete(e)}})}async emitWrapped(e){this.settings.asyncEventWrapper?(await this.scheduler.yield(),await this.settings.asyncEventWrapper(e)):(await this.scheduler.yield(),e())}resetTreeForRecovery(e){e.setService("loader",this);for(let n of this.scopesToLoad){let r=e.get(n);r&&(r.cache.isShallowLoad=!0)}this.tree=e}async nodeIdsToLoad(){let e=performance.now(),n=new Set;if(!this.partialParser)return n;let r=performance.now();for(let i of this.scopesToLoad){performance.now()-r>50&&(await Rn(),r=performance.now());let s=this.partialParser.getParsedPageById(i);na(n,s)}for(let i of this.addedByDiff)n.add(i);for(let i of this.removedByDiff)n.delete(i);return O.debug("nodeIdsToLoad",n.size,Ce(performance.now()-e)),n}addNodeChanges(e){for(let n of e){let r=n.id;n.added?(this.addedByDiff.add(r),this.removedByDiff.delete(r)):n.removed&&(this.addedByDiff.delete(r),this.removedByDiff.add(r))}}};function na(o,t){if(t&&(o.add(t.id),!!t.children))for(let e of t.children)na(o,e)}var vt=class{constructor(t,e){this.node=t;this.duration=e}hasNode(){return!!this.node}take(){let t=this.node;return this.node=void 0,t}},uo=class{constructor(t,e){this.id=t;this.parser=e;g(this,"data");g(this,"loadedScope")}async run(t){if(this.loadedScope)return this.loadedScope;let e=performance.now();this.data=this.parser.getParsedPageById(this.id);let n=performance.now()-e;if(await t.yield(),this.loadedScope)return this.loadedScope;let r=performance.now(),i=this.parser.buildPage(this.data);return i&&(i.cache.isShallowLoad=!1),this.loadedScope=new vt(i,n+performance.now()-r),this.loadedScope}force(){if(this.loadedScope)return this.loadedScope;let t=performance.now();this.data||(this.data=this.parser.getParsedPageById(this.id));let e=this.parser.buildPage(this.data);return e&&(e.cache.isShallowLoad=!1),this.loadedScope=new vt(e,performance.now()-t),this.loadedScope}};var ic={cache:!0,mutable:!0,update:!0,parentid:!0,originalid:!0,duplicatedFrom:!0,moduleSourceRevision:!0,moduleSourceRevisionHint:!0,moduleSourceRevisionCommittedHint:!0,kitSectionsStructure:!0,kitSectionHash:!0,kitSectionSource:!0,kitPageHTMLHash:!0,customizations:!0,customizationsDescription:!0,customizationsSectionId:!0,customizationsCategory:!0,customizationsRules:!0,isApplyingCustomizations:!0,layoutTemplateIdentifierOverride:!0,abTestingParentId:!0,abTestingDistributionWeightPpm:!0};function xe(o,t){if(!U(t)&&!ic[o]&&!o.startsWith("export")&&!bi(o))return t}function sc(o,t){if(o!=="children")return xe(o,t)}function ac(o,t,e,n,r){if(!ai(o)||!Br(t))return t;if(t.type==="slot")return!Mr(t.value)||Ze(e)&&e.slotsAreChildNodes?t:t.value.map(i=>{let s=r.get(i.reference);return Wn(n,s)?s:void 0});if(t.type==="componentinstance"){if(!K(t.value))return t;let i=r.get(t.value);return Wn(n,i)?i:void 0}else if(t.type==="array"){if(!Mr(t.value))return t;let i=[],s=!1;for(let a of t.value){if(!Br(a)||a.type!=="componentinstance"||(s=!0,!K(a.value)))continue;let c=r.get(a.value);Wn(n,c)&&i.push(c)}return s?i:t}return t}function cc(o,t){return(e,n,r)=>xe(e,ac(e,n,r,t,o))}var pn=N("ModuleSourceRevision");function Iu(o){return ve(H(o,xe))}function Ru(o,t,e){let n=ve(H(t,xe));for(let r of e){let i=o.get(Ci(r.id,t.id));i&&(n+=ve(H(i,xe)))}return n}function dc(o,t){switch(o.__class){case"CollectionItemNode":case"ImageStylePresetNode":case"InlineCodeStylePresetNode":case"LayoutTemplateNode":case"LinkStylePresetNode":case"SmartComponentNode":case"TableStylePresetNode":case"WebPageNode":return ve(H(o,xe));case"FrameNode":{let e=t.get(o.parentid);return!e||!le(e)?void 0:ve(H(o,cc(t,e.id)))}case"CollectionNode":{S(Z(o),"Expected collection node");let e=H(t.root.locales),n=H(t.root.webMetadata?.translatePagePaths),r=H(o,sc),i=H(o.getUnsortedChildren()?.map(s=>s.moduleSourceRevision));return ve(e+n+r+i)}case"PresetsListNode":{let e=o.children?.filter(n=>!Ri(n,t))??[];return ve(H(e,xe))}case"TextStylePresetNode":case"BlockquoteStylePresetNode":{if(Ur(o))return o.moduleSourceRevision;let e=H(o,xe);return o.cache.replicaInstances?.forEach(n=>{let r=t.getNodeWithTrait(n,Ur);r&&(e+=H(r,xe))}),ve(e)}case"VectorSetNode":{S(de(o),"Expected VectorSetNode");let e=o.getVectorSetItems().map(n=>{let r=Fe("vector",n.id,"default").localId,i=t.getNodeWithTrait(r,zi);return i?i.save.moduleId:""});return ve(H(e)+o.name)}case"ShapeContainerNode":{if(!ke(o))return;let e=t.getScopeNodeFor(o);if(!de(e))return;let n=H(o,xe);return ve(n+H(e.variables))}case"CustomCodeScopeNode":{S(ht(o),"Expected CustomCodeScopeNode");let e=o.loaded;S(e,"Expected CustomCodeScopeNode to be loaded");let n={};for(let i of e.children)if(!(!Ho(i)||!i.pageIds))for(let s of i.pageIds){let a=t.getNodeWithTrait(s,Ln);a&&(n[s]=a.dataIdentifier)}let r=H(o,xe);return ve(r+H(n))}case"CanvasPageNode":case"RootNode":return;case"ComponentPresetNode":return;case"AbTestsEntityTypeRootNode":case"AgentPanelTool":case"AgentDragSelectTool":case"AgentSelectTool":case"AnalyticsScopeNode":case"BlockquoteEntityTypeRootNode":case"BooleanShapeNode":case"BoxShadow":case"CanvasNode":case"CanvasScopeNode":case"CustomCodeNode":case"DesignPageNode":case"ChatTool":case"CMSEntityTypeRootNode":case"CodeComponentNode":case"CodeFileEntityTypeRootNode":case"CollectionReferenceVariableEditTool":case"Color":case"ColorEntityTypeRootNode":case"ColorStyleTokenListNode":case"ColorStyleTokenNode":case"ComponentEntityTypeRootNode":case"ConicGradient":case"ContentManagementNode":case"CreateCodeComponentBaseTool":case"CreateFrameBaseTool":case"CreateShapeBaseTool":case"CreateTextTool":case"EntityFolderNode":case"EntityReferenceNode":case"EntityRootNode":case"ContentManagementEntityTypeRootNode":case"ErrorListNode":case"ErrorNode":case"ExportOptions":case"ExternalModuleNode":case"ExternalModulesListNode":case"FeedbackTool":case"FormBooleanInputNode":case"FormPlainTextInputNode":case"FormSelectNode":case"FunnelNode":case"FunnelsEntityTypeRootNode":case"FunnelStepActionNode":case"FunnelStepNode":case"GapTool":case"GradientColorStop":case"GradientToolManagerTool":case"GuideMoveTool":case"HeaderRouteNode":case"HighlightStackItemTool":case"HighlightTool":case"InitialTool":case"InlineCodeEntityTypeRootNode":case"LayoutTemplateEntityTypeRootNode":case"LineAnchorMoveTool":case"LinearGradient":case"LinkEntityTypeRootNode":case"LinkTool":case"LoadingShieldTool":case"LocalizationGlossaryItemNode":case"LocalizationGlossaryNode":case"LocalModuleNode":case"LocalModulesListNode":case"MoveTool":case"MutableNode":case"OvalShapeNode":case"OverlayNode":case"PaddingTool":case"PageLinkTool":case"PanTool":case"PathCurveBendTool":case"PathDefaultTool":case"PathNode":case"PathSegment":case"PathSegmentAdditionTool":case"PathSegmentHandleMoveTool":case"PathSegmentMoveTool":case"PathSegmentSelectTool":case"PolygonShapeNode":case"PreviewSettings":case"ProxyRouteNode":case"RadialGradient":case"RadiusTool":case"RecoveryTool":case"RectangleShapeNode":case"RedirectRouteNode":case"ResizeTool":case"RewriteRouteNode":case"RichTextEditTool":case"RichTextNode":case"RichTextVariableEditTool":case"RotateTool":case"RouteNode":case"RouteLocaleNode":case"RouteSegmentNode":case"RouteSegmentRootNode":case"RoutesNode":case"SampleColorTool":case"ScaleTool":case"ScopeNode":case"SelectTool":case"ShaderNode":case"Shadow":case"ShapeGroupNode":case"SlotConnectTool":case"SlotNode":case"SlotPropertyNode":case"StarShapeNode":case"StringVariableEditTool":case"DateVariableEditTool":case"EnumVariableEditTool":case"StyledTextDraft":case"SVGNode":case"TestTool":case"TextEditTool":case"TextEntityTypeRootNode":case"TextNode":case"VectorSetEntityTypeRootNode":case"VekterGradientTool":case"VekterPathEngine":case"VekterTool":case"ViewportResizeTool":case"ZoomSelectTool":case"ZoomTool":return;default:Se(o.__class,"getModuleRevision: node.__class must be a valid value")}}function fo(o,t){let e=o.get(t);return!e||!be(e,o)?!1:U(e.moduleSourceRevisionHint)||e.moduleSourceRevisionCommittedHint===e.moduleSourceRevisionHint?(pn.debug(`Hint hasn't changed for ${e.id}.`),!1):(pn.debug(`Initial Revision: ${e.moduleSourceRevision}`),!0)}function po(o,t){let e=o.get(t);if(!e||!be(e,o))return;let n=performance.now(),r=dc(e,o);pn.debug(`Spent ${performance.now()-n}ms computing module revision for ${e.id}`);let i=B(r)&&r!==e.moduleSourceRevision;pn.debug(`Revisions: ${e.moduleSourceRevision}, ${r}`);let s=e.moduleSourceRevisionHint,a=i?{moduleSourceRevision:r,moduleSourceRevisionCommittedHint:s}:{moduleSourceRevisionCommittedHint:s};return pn.debug(i?`Updating moduleSourceRevision for ${e.id}.`:`Updating moduleSourceRevisionCommittedHint for ${e.id}.`),e.setIgnoringReplica(a,o),i?r:void 0}function ra(o,t){return t(e=>{if(e.isViewOnly)return;let n=e.get(o);return Z(n)&&n.getUnsortedChildren()?.forEach(r=>{fo(e,r.id)&&po(e,r.id)}),po(e,o)})}function oa(o,t){return t(e=>{if(!e.isViewOnly)return o.reduce((n,r)=>(n[r.id]=po(e,r.id)??1,n),{})})}var lc=N("CodeGenerationStore"),uc="transform",Ot,bt,ur=class{constructor(t){this.sourceNode=t;Y(this,Ot,[]);Y(this,bt)}start(t){let e=performance.now();return{end:n=>{T(this,Ot).push([t,performance.now()-e]),ye(this,bt,T(this,bt)??n),t===uc&&this.completeSession()}}}restartSession(){ye(this,Ot,[]),ye(this,bt,void 0)}completeSession(){T(this,bt)?.forEach(({type:t,source:e,artifacts:n})=>{let r=pc(t,this.sourceNode);if(!r)return;let i={codeType:r,durationMs:0,updateCount:0,updateDurationMs:0,serializationDurationMs:0,compilationDurationMs:0,synchronizationDurationMs:0,size:e.length,id:this.sourceNode.id,nodes:n?.metrics?.nodes??1,variants:n?.metrics?.variants??0,svgBytes:n?.metrics?.svgBytes,textBytes:n?.metrics?.textBytes};for(let[a,c]of T(this,Ot))switch(i.durationMs+=c,a){case"update":i.updateCount++,i.updateDurationMs+=c;break;case"serialize":i.serializationDurationMs+=c;break;case"transform":i.compilationDurationMs+=c;break;case"synchronize":i.synchronizationDurationMs+=c;break;default:Se(a)}let s;for(s in i){let a=i[s];B(a)&&(i[s]=Math.round(a))}lc.trace("Code Generation Metrics",i),Pe("code_generation",i)}),this.restartSession()}};Ot=new WeakMap,bt=new WeakMap;function pc(o,t){switch(o){case"canvasComponent":return"smart_component";case"css":return"styles_preset";case"collection":return"collection";case"draftCollection":return"draft_collection";case"componentPresets":return"component_presets";case"screen":return F(t)?"web_page":"prototype_screen";case"prototype":return"prototype";case"vector":return"vector";case"vectorSet":return"vector_set";case"snippets":return"snippets";case"codeFile":case"config":case"siteMetadata":case"webPageMetadata":case"layoutTemplate":case"localization":case"design":case"kit":case"shader":return;default:Se(o)}}function fc(o,t){let e={};if(!t||li(o))return e;for(let n of o.cases)for(let r of t){let i=n.nameLocalized;if(!i)continue;let s=i[r.id]?.value;if(!K(s))continue;let a=e[n.id]??{};e[n.id]=a,a[r.id]=s}return e}function ia(o,t,e){if(o.cases.length===0)return u`(value) => value`;let n=fc(o,t),r=u`value`,i=u`locale`,s=u`fallbackLocale`;return new w(E.lines(u`(${r}, ${i}) => {`,u`const ${s} = ${i}?.fallback;`,u`switch (${r}) {`,...o.cases.map(({id:a,name:c})=>{let d=n[a];return d?new w(E.lines(u`case ${a}:`,u`switch (${i}?.id) {`,...Object.entries(d).map(([p,l])=>u`case ${p}: return ${l};`),u`default:`,u`if (${s}) return ${w.fn(e,r,s)};`,u`return ${c};`,u`}`)):u`case ${a}: return ${c};`}),u`default: return "";`,u`}`,u`}`))}var mo="framercms";function sa(o,t,e){return`${o}-${t}.${e}`}var pr=class{constructor(t){this.componentSourceNodeId=t;g(this,"assets",{})}create(t,e,n){let r=sa(this.componentSourceNodeId,t,e);return this.assets[r]=n,u`new URL(${`./${r}`}, import.meta.url).href`}};var aa=ft(Er(),1);function j(o,...t){if(!o)throw Error("Assertion Error"+(t.length>0?": "+t.join(" "):""))}function fn(o){throw new Error(`Unexpected value: ${o}`)}var mc=ft(Pn(),1);var ca=`// src/code-generation/components/cms/bundled/getRichTextJsonResolver.tsx?bundle
import { AutoBreakpointVariant, ComponentPresetsConsumer, Link, motion } from "framer";

// ../../library/src/router/lazy.tsx
import { forwardRef, isValidElement, useEffect } from "react";

// ../../library/src/utils/utils.ts
var isWindow = typeof window !== "undefined";
var supportsRequestIdleCallback = isWindow && typeof window.requestIdleCallback === "function";

// ../../library/src/router/lazy.tsx
var preloadKey = "preload";
function isLazyComponentType(componentType) {
  return typeof componentType === "object" && componentType !== null && !isValidElement(componentType) && preloadKey in componentType;
}

// src/code-generation/components/cms/bundled/getRichTextJsonResolver.tsx?bundle
import { Fragment, createElement } from "react";

// src/code-generation/components/cms/bundled/assert.ts
function assert(condition, ...msg) {
  if (condition) return;
  throw Error("Assertion Error" + (msg.length > 0 ? ": " + msg.join(" ") : ""));
}

// src/code-generation/components/cms/bundled/getRichTextJsonResolver.tsx?bundle
var RichTextJsonType = /* @__PURE__ */ ((RichTextJsonType2) => {
  RichTextJsonType2[RichTextJsonType2["Fragment"] = 1] = "Fragment";
  RichTextJsonType2[RichTextJsonType2["Link"] = 2] = "Link";
  RichTextJsonType2[RichTextJsonType2["Module"] = 3] = "Module";
  RichTextJsonType2[RichTextJsonType2["Tag"] = 4] = "Tag";
  RichTextJsonType2[RichTextJsonType2["Text"] = 5] = "Text";
  return RichTextJsonType2;
})(RichTextJsonType || {});
function getRichTextJsonResolver(components) {
  const cache = /* @__PURE__ */ new Map();
  function deserializeChildren(children) {
    return children.map(deserializeNode);
  }
  function deserializeNode(node) {
    switch (node[0]) {
      case 1 /* Fragment */: {
        const [, ...children] = node;
        const childNodes = deserializeChildren(children);
        return createElement(Fragment, void 0, ...childNodes);
      }
      case 2 /* Link */: {
        const [, props, ...children] = node;
        const childNodes = deserializeChildren(children);
        return createElement(Link, props, ...childNodes);
      }
      case 3 /* Module */: {
        const [, identifier, props, richTextKeys, vectorSetItemKeys] = node;
        for (const key of richTextKeys) {
          const value = props[key];
          if (!value) continue;
          props[key] = deserializeNode(value);
        }
        for (const key of vectorSetItemKeys) {
          const value = props[key];
          if (typeof value !== "string") continue;
          const VectorSetItem = components[value];
          if (!VectorSetItem) continue;
          if (isLazyComponentType(VectorSetItem)) {
            void VectorSetItem.preload();
          }
          props[key] = VectorSetItem;
        }
        const Component = components[identifier];
        assert(Component, "Module not found");
        if (isLazyComponentType(Component)) {
          void Component.preload();
        }
        return <ComponentPresetsConsumer componentIdentifier={identifier}>
						{(presetProps) => <AutoBreakpointVariant component={Component} props={{ ...presetProps, ...props }} />}
					</ComponentPresetsConsumer>;
      }
      case 4 /* Tag */: {
        const [, tag, props, ...children] = node;
        const childNodes = deserializeChildren(children);
        if (tag === "a") {
          return createElement(motion.a, props, ...childNodes);
        }
        return createElement(tag, props, ...childNodes);
      }
      case 5 /* Text */: {
        const [, text] = node;
        return text;
      }
    }
  }
  return (pointer) => {
    const cached = cache.get(pointer);
    if (cached) return cached;
    const json = JSON.parse(pointer);
    const result = deserializeNode(json);
    cache.set(pointer, result);
    return result;
  };
}
export {
  RichTextJsonType,
  getRichTextJsonResolver
};
`;var fr=class{constructor(t,e,n,r,i,s,a,c,d){this.collectionNode=t;this.componentLoader=e;this.tree=n;this.imports=r;this.submodules=i;this.bindings=s;this.declarations=a;this.assets=c;this.links=d;g(this,"scopeNode");g(this,"cache",new Map);g(this,"components",{});g(this,"resolvers");g(this,"serializers",{fragment:t=>[1,...t],link:(t,e)=>[2,t,...e],module:(t,e)=>{if(!this.addModuleImport(t))return;let r=this.componentLoader.reactComponentForIdentifier(t);S(r,"Component must exist for module");let i=[],s=[];for(let a in r.properties){let c=r.properties[a];if(c){if(c.type==="richtext")i.push(a);else if(c.type==="vectorsetitem"){let d=e[a];if(!K(d)||!Lt(d)||!this.addModuleImport(d))continue;s.push(a)}}}return[3,t,e,i,s]},tag:(t,e,n)=>[4,t,e,...n],text:t=>[5,t]});g(this,"resolveRichTextBinding");this.resolveRichTextBinding=this.bindings.create("resolveRichText"),this.scopeNode=this.tree.getScopeNodeFor(this.collectionNode),this.resolvers=us(this.assets,this.links,void 0,void 0)}addModuleImport(t){if(t in this.components)return!0;let e=Re(t),n=this.imports.addModuleImport(e,{lazy:!0});return n?(this.components[t]=n,!0):!1}add(t){let e=this.cache.get(t);if(e)return e;let n=ls(t,this.resolvers,this.serializers,{componentLoader:this.componentLoader,resolveVectorSetItem:i=>i,tree:this.tree,nodeId:this.collectionNode.id,scopeId:this.scopeNode?.id}),r=JSON.stringify(n);return this.cache.set(t,r),r}serialize(){let t=this.imports.addImport(this.submodules.create(ca).submoduleImport,{exportSpecifier:"getRichTextJsonResolver"}),e=this.declarations.dedupe("richTextComponents",this.components);this.declarations.create(u`const ${this.resolveRichTextBinding} = ${w.fn(t,e)}`)}};var mr=class{constructor(){g(this,"values",new Map)}add(t){let e=this.values.get(t);if(B(e))return e;let n=this.values.size;return this.values.set(t,n),n}serialize(t,e,n){let r=[];for(let[s,a]of this.values){let c=Re(s),{importSpecifier:d}=ki(c,"collection",t,e);S(d,"Import specifier must be defined"),r[a]=u`() => import(${d})`}let i=n.dedupe("vectors",r);return n.dedupe("resolveVectorSetItem",u`(pointer: number) => {${u.joinLines(u`const vector = ${i}[pointer]`,u`if (vector) return vector().then(v => v.default)`)}}`)}};var W={Uint8:1,Uint16:2,Uint32:4,BigUint64:8,Int8:1,Int16:2,Int32:4,BigInt64:8,Float32:4,Float64:8},hr=class{constructor(t){this.bytes=t;g(this,"offset",0);g(this,"view");g(this,"decoder",new TextDecoder);this.view=_t(this.bytes)}getOffset(){return this.offset}ensureLength(t){let e=this.bytes.length;if(!(this.offset+t<=e))throw new Error("Reading out of bounds")}readUint8(){let t=W.Uint8;this.ensureLength(t);let e=this.view.getUint8(this.offset);return this.offset+=t,e}readUint16(){let t=W.Uint16;this.ensureLength(t);let e=this.view.getUint16(this.offset);return this.offset+=t,e}readUint32(){let t=W.Uint32;this.ensureLength(t);let e=this.view.getUint32(this.offset);return this.offset+=t,e}readUint64(){let t=this.readBigUint64();return Number(t)}readBigUint64(){let t=W.BigUint64;this.ensureLength(t);let e=this.view.getBigUint64(this.offset);return this.offset+=t,e}readInt8(){let t=W.Int8;this.ensureLength(t);let e=this.view.getInt8(this.offset);return this.offset+=t,e}readInt16(){let t=W.Int16;this.ensureLength(t);let e=this.view.getInt16(this.offset);return this.offset+=t,e}readInt32(){let t=W.Int32;this.ensureLength(t);let e=this.view.getInt32(this.offset);return this.offset+=t,e}readInt64(){let t=this.readBigInt64();return Number(t)}readBigInt64(){let t=W.BigInt64;this.ensureLength(t);let e=this.view.getBigInt64(this.offset);return this.offset+=t,e}readFloat32(){let t=W.Float32;this.ensureLength(t);let e=this.view.getFloat32(this.offset);return this.offset+=t,e}readFloat64(){let t=W.Float64;this.ensureLength(t);let e=this.view.getFloat64(this.offset);return this.offset+=t,e}readBytes(t){let e=this.offset,n=e+t,r=this.bytes.subarray(e,n);return this.offset=n,r}readString(){let t=this.readUint32(),e=this.readBytes(t);return this.decoder.decode(e)}readJson(){let t=this.readString();return JSON.parse(t)}};function _t(o){return new DataView(o.buffer,o.byteOffset,o.byteLength)}var hc=1024,gc=1.5,ho=o=>2**o-1,go=o=>-(2**(o-1)),yo=o=>2**(o-1)-1,Ae={Uint8:0,Uint16:0,Uint32:0,Uint64:0,BigUint64:0,Int8:go(8),Int16:go(16),Int32:go(32),Int64:Number.MIN_SAFE_INTEGER,BigInt64:-(BigInt(2)**BigInt(63))},Be={Uint8:ho(8),Uint16:ho(16),Uint32:ho(32),Uint64:Number.MAX_SAFE_INTEGER,BigUint64:BigInt(2)**BigInt(64)-BigInt(1),Int8:yo(8),Int16:yo(16),Int32:yo(32),Int64:Number.MAX_SAFE_INTEGER,BigInt64:BigInt(2)**BigInt(63)-BigInt(1)};function ze(o,t,e,n){j(o>=t,o,"outside lower bound for",n),j(o<=e,o,"outside upper bound for",n)}var Ct=class{constructor(){g(this,"offset",0);g(this,"bytes",new Uint8Array(hc));g(this,"view",_t(this.bytes));g(this,"encoder",new TextEncoder);g(this,"encodedStrings",new Map)}getOffset(){return this.offset}slice(t=0,e=this.offset){return this.bytes.slice(t,e)}subarray(t=0,e=this.offset){return this.bytes.subarray(t,e)}ensureLength(t){let e=this.bytes.length;if(this.offset+t<=e)return;let n=Math.ceil(e*gc)+t,r=new Uint8Array(n);r.set(this.bytes),this.bytes=r,this.view=_t(r)}writeUint8(t){ze(t,Ae.Uint8,Be.Uint8,"Uint8");let e=W.Uint8;this.ensureLength(e),this.view.setUint8(this.offset,t),this.offset+=e}writeUint16(t){ze(t,Ae.Uint16,Be.Uint16,"Uint16");let e=W.Uint16;this.ensureLength(e),this.view.setUint16(this.offset,t),this.offset+=e}writeUint32(t){ze(t,Ae.Uint32,Be.Uint32,"Uint32");let e=W.Uint32;this.ensureLength(e),this.view.setUint32(this.offset,t),this.offset+=e}writeUint64(t){ze(t,Ae.Uint64,Be.Uint64,"Uint64");let e=BigInt(t);this.writeBigUint64(e)}writeBigUint64(t){ze(t,Ae.BigUint64,Be.BigUint64,"BigUint64");let e=W.BigUint64;this.ensureLength(e),this.view.setBigUint64(this.offset,t),this.offset+=e}writeInt8(t){ze(t,Ae.Int8,Be.Int8,"Int8");let e=W.Int8;this.ensureLength(e),this.view.setInt8(this.offset,t),this.offset+=e}writeInt16(t){ze(t,Ae.Int16,Be.Int16,"Int16");let e=W.Int16;this.ensureLength(e),this.view.setInt16(this.offset,t),this.offset+=e}writeInt32(t){ze(t,Ae.Int32,Be.Int32,"Int32");let e=W.Int32;this.ensureLength(e),this.view.setInt32(this.offset,t),this.offset+=e}writeInt64(t){ze(t,Ae.Int64,Be.Int64,"Int64");let e=BigInt(t);this.writeBigInt64(e)}writeBigInt64(t){ze(t,Ae.BigInt64,Be.BigInt64,"BigInt64");let e=W.BigInt64;this.ensureLength(e),this.view.setBigInt64(this.offset,t),this.offset+=e}writeFloat32(t){let e=W.Float32;this.ensureLength(e),this.view.setFloat32(this.offset,t),this.offset+=e}writeFloat64(t){let e=W.Float64;this.ensureLength(e),this.view.setFloat64(this.offset,t),this.offset+=e}writeBytes(t){let e=t.length;this.ensureLength(e),this.bytes.set(t,this.offset),this.offset+=e}encodeString(t){let e=this.encodedStrings.get(t);if(e)return e;let n=this.encoder.encode(t);return this.encodedStrings.set(t,n),n}writeString(t){let e=this.encodeString(t),n=e.length;this.writeUint32(n),this.writeBytes(e)}writeJson(t){let e=JSON.stringify(t);this.writeString(e)}};var da=`var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __defNormalProp = (obj, key, value) => key in obj ? __defProp(obj, key, { enumerable: true, configurable: true, writable: true, value }) : obj[key] = value;
var __commonJS = (cb, mod) => function __require() {
  return mod || (0, cb[__getOwnPropNames(cb)[0]])((mod = { exports: {} }).exports, mod), mod.exports;
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));
var __publicField = (obj, key, value) => __defNormalProp(obj, typeof key !== "symbol" ? key + "" : key, value);

// ../../../node_modules/dataloader/index.js
var require_dataloader = __commonJS({
  "../../../node_modules/dataloader/index.js"(exports, module) {
    "use strict";
    var DataLoader2 = /* @__PURE__ */ function() {
      function DataLoader3(batchLoadFn, options) {
        if (typeof batchLoadFn !== "function") {
          throw new TypeError("DataLoader must be constructed with a function which accepts " + ("Array<key> and returns Promise<Array<value>>, but got: " + batchLoadFn + "."));
        }
        this._batchLoadFn = batchLoadFn;
        this._maxBatchSize = getValidMaxBatchSize(options);
        this._batchScheduleFn = getValidBatchScheduleFn(options);
        this._cacheKeyFn = getValidCacheKeyFn(options);
        this._cacheMap = getValidCacheMap(options);
        this._batch = null;
        this.name = getValidName(options);
      }
      var _proto = DataLoader3.prototype;
      _proto.load = function load(key) {
        if (key === null || key === void 0) {
          throw new TypeError("The loader.load() function must be called with a value, " + ("but got: " + String(key) + "."));
        }
        var batch = getCurrentBatch(this);
        var cacheMap = this._cacheMap;
        var cacheKey = this._cacheKeyFn(key);
        if (cacheMap) {
          var cachedPromise = cacheMap.get(cacheKey);
          if (cachedPromise) {
            var cacheHits = batch.cacheHits || (batch.cacheHits = []);
            return new Promise(function(resolve) {
              cacheHits.push(function() {
                resolve(cachedPromise);
              });
            });
          }
        }
        batch.keys.push(key);
        var promise = new Promise(function(resolve, reject) {
          batch.callbacks.push({
            resolve,
            reject
          });
        });
        if (cacheMap) {
          cacheMap.set(cacheKey, promise);
        }
        return promise;
      };
      _proto.loadMany = function loadMany(keys) {
        if (!isArrayLike(keys)) {
          throw new TypeError("The loader.loadMany() function must be called with Array<key> " + ("but got: " + keys + "."));
        }
        var loadPromises = [];
        for (var i = 0; i < keys.length; i++) {
          loadPromises.push(this.load(keys[i])["catch"](function(error) {
            return error;
          }));
        }
        return Promise.all(loadPromises);
      };
      _proto.clear = function clear(key) {
        var cacheMap = this._cacheMap;
        if (cacheMap) {
          var cacheKey = this._cacheKeyFn(key);
          cacheMap["delete"](cacheKey);
        }
        return this;
      };
      _proto.clearAll = function clearAll() {
        var cacheMap = this._cacheMap;
        if (cacheMap) {
          cacheMap.clear();
        }
        return this;
      };
      _proto.prime = function prime(key, value) {
        var cacheMap = this._cacheMap;
        if (cacheMap) {
          var cacheKey = this._cacheKeyFn(key);
          if (cacheMap.get(cacheKey) === void 0) {
            var promise;
            if (value instanceof Error) {
              promise = Promise.reject(value);
              promise["catch"](function() {
              });
            } else {
              promise = Promise.resolve(value);
            }
            cacheMap.set(cacheKey, promise);
          }
        }
        return this;
      };
      return DataLoader3;
    }();
    var enqueuePostPromiseJob = typeof process === "object" && typeof process.nextTick === "function" ? function(fn) {
      if (!resolvedPromise) {
        resolvedPromise = Promise.resolve();
      }
      resolvedPromise.then(function() {
        process.nextTick(fn);
      });
    } : typeof setImmediate === "function" ? function(fn) {
      setImmediate(fn);
    } : function(fn) {
      setTimeout(fn);
    };
    var resolvedPromise;
    function getCurrentBatch(loader) {
      var existingBatch = loader._batch;
      if (existingBatch !== null && !existingBatch.hasDispatched && existingBatch.keys.length < loader._maxBatchSize) {
        return existingBatch;
      }
      var newBatch = {
        hasDispatched: false,
        keys: [],
        callbacks: []
      };
      loader._batch = newBatch;
      loader._batchScheduleFn(function() {
        dispatchBatch(loader, newBatch);
      });
      return newBatch;
    }
    function dispatchBatch(loader, batch) {
      batch.hasDispatched = true;
      if (batch.keys.length === 0) {
        resolveCacheHits(batch);
        return;
      }
      var batchPromise;
      try {
        batchPromise = loader._batchLoadFn(batch.keys);
      } catch (e) {
        return failedDispatch(loader, batch, new TypeError("DataLoader must be constructed with a function which accepts Array<key> and returns Promise<Array<value>>, but the function " + ("errored synchronously: " + String(e) + ".")));
      }
      if (!batchPromise || typeof batchPromise.then !== "function") {
        return failedDispatch(loader, batch, new TypeError("DataLoader must be constructed with a function which accepts Array<key> and returns Promise<Array<value>>, but the function did " + ("not return a Promise: " + String(batchPromise) + ".")));
      }
      batchPromise.then(function(values) {
        if (!isArrayLike(values)) {
          throw new TypeError("DataLoader must be constructed with a function which accepts Array<key> and returns Promise<Array<value>>, but the function did " + ("not return a Promise of an Array: " + String(values) + "."));
        }
        if (values.length !== batch.keys.length) {
          throw new TypeError("DataLoader must be constructed with a function which accepts Array<key> and returns Promise<Array<value>>, but the function did not return a Promise of an Array of the same length as the Array of keys." + ("\\n\\nKeys:\\n" + String(batch.keys)) + ("\\n\\nValues:\\n" + String(values)));
        }
        resolveCacheHits(batch);
        for (var i = 0; i < batch.callbacks.length; i++) {
          var value = values[i];
          if (value instanceof Error) {
            batch.callbacks[i].reject(value);
          } else {
            batch.callbacks[i].resolve(value);
          }
        }
      })["catch"](function(error) {
        failedDispatch(loader, batch, error);
      });
    }
    function failedDispatch(loader, batch, error) {
      resolveCacheHits(batch);
      for (var i = 0; i < batch.keys.length; i++) {
        loader.clear(batch.keys[i]);
        batch.callbacks[i].reject(error);
      }
    }
    function resolveCacheHits(batch) {
      if (batch.cacheHits) {
        for (var i = 0; i < batch.cacheHits.length; i++) {
          batch.cacheHits[i]();
        }
      }
    }
    function getValidMaxBatchSize(options) {
      var shouldBatch = !options || options.batch !== false;
      if (!shouldBatch) {
        return 1;
      }
      var maxBatchSize = options && options.maxBatchSize;
      if (maxBatchSize === void 0) {
        return Infinity;
      }
      if (typeof maxBatchSize !== "number" || maxBatchSize < 1) {
        throw new TypeError("maxBatchSize must be a positive number: " + maxBatchSize);
      }
      return maxBatchSize;
    }
    function getValidBatchScheduleFn(options) {
      var batchScheduleFn = options && options.batchScheduleFn;
      if (batchScheduleFn === void 0) {
        return enqueuePostPromiseJob;
      }
      if (typeof batchScheduleFn !== "function") {
        throw new TypeError("batchScheduleFn must be a function: " + batchScheduleFn);
      }
      return batchScheduleFn;
    }
    function getValidCacheKeyFn(options) {
      var cacheKeyFn = options && options.cacheKeyFn;
      if (cacheKeyFn === void 0) {
        return function(key) {
          return key;
        };
      }
      if (typeof cacheKeyFn !== "function") {
        throw new TypeError("cacheKeyFn must be a function: " + cacheKeyFn);
      }
      return cacheKeyFn;
    }
    function getValidCacheMap(options) {
      var shouldCache = !options || options.cache !== false;
      if (!shouldCache) {
        return null;
      }
      var cacheMap = options && options.cacheMap;
      if (cacheMap === void 0) {
        return /* @__PURE__ */ new Map();
      }
      if (cacheMap !== null) {
        var cacheFunctions = ["get", "set", "delete", "clear"];
        var missingFunctions = cacheFunctions.filter(function(fnName) {
          return cacheMap && typeof cacheMap[fnName] !== "function";
        });
        if (missingFunctions.length !== 0) {
          throw new TypeError("Custom cacheMap missing methods: " + missingFunctions.join(", "));
        }
      }
      return cacheMap;
    }
    function getValidName(options) {
      if (options && options.name) {
        return options.name;
      }
      return null;
    }
    function isArrayLike(x) {
      return typeof x === "object" && x !== null && typeof x.length === "number" && (x.length === 0 || x.length > 0 && Object.prototype.hasOwnProperty.call(x, x.length - 1));
    }
    module.exports = DataLoader2;
  }
});

// src/code-generation/components/cms/bundled/DatabaseCollection.ts?bundle
var import_dataloader = __toESM(require_dataloader(), 1);

// src/code-generation/components/cms/bundled/BufferReader.ts
var BYTE_LENGTH = {
  Uint8: 1,
  Uint16: 2,
  Uint32: 4,
  BigUint64: 8,
  Int8: 1,
  Int16: 2,
  Int32: 4,
  BigInt64: 8,
  Float32: 4,
  Float64: 8
};
var BufferReader = class {
  constructor(bytes) {
    this.bytes = bytes;
    __publicField(this, "offset", 0);
    __publicField(this, "view");
    __publicField(this, "decoder", new TextDecoder());
    this.view = getDataView(this.bytes);
  }
  getOffset() {
    return this.offset;
  }
  ensureLength(requiredBytes) {
    const oldLength = this.bytes.length;
    if (this.offset + requiredBytes <= oldLength) return;
    throw new Error("Reading out of bounds");
  }
  readUint8() {
    const size = BYTE_LENGTH.Uint8;
    this.ensureLength(size);
    const value = this.view.getUint8(this.offset);
    this.offset += size;
    return value;
  }
  readUint16() {
    const size = BYTE_LENGTH.Uint16;
    this.ensureLength(size);
    const value = this.view.getUint16(this.offset);
    this.offset += size;
    return value;
  }
  readUint32() {
    const size = BYTE_LENGTH.Uint32;
    this.ensureLength(size);
    const value = this.view.getUint32(this.offset);
    this.offset += size;
    return value;
  }
  readUint64() {
    const bigint = this.readBigUint64();
    return Number(bigint);
  }
  readBigUint64() {
    const size = BYTE_LENGTH.BigUint64;
    this.ensureLength(size);
    const value = this.view.getBigUint64(this.offset);
    this.offset += size;
    return value;
  }
  readInt8() {
    const size = BYTE_LENGTH.Int8;
    this.ensureLength(size);
    const value = this.view.getInt8(this.offset);
    this.offset += size;
    return value;
  }
  readInt16() {
    const size = BYTE_LENGTH.Int16;
    this.ensureLength(size);
    const value = this.view.getInt16(this.offset);
    this.offset += size;
    return value;
  }
  readInt32() {
    const size = BYTE_LENGTH.Int32;
    this.ensureLength(size);
    const value = this.view.getInt32(this.offset);
    this.offset += size;
    return value;
  }
  readInt64() {
    const bigint = this.readBigInt64();
    return Number(bigint);
  }
  readBigInt64() {
    const size = BYTE_LENGTH.BigInt64;
    this.ensureLength(size);
    const value = this.view.getBigInt64(this.offset);
    this.offset += size;
    return value;
  }
  readFloat32() {
    const size = BYTE_LENGTH.Float32;
    this.ensureLength(size);
    const value = this.view.getFloat32(this.offset);
    this.offset += size;
    return value;
  }
  readFloat64() {
    const size = BYTE_LENGTH.Float64;
    this.ensureLength(size);
    const value = this.view.getFloat64(this.offset);
    this.offset += size;
    return value;
  }
  readBytes(length) {
    const start = this.offset;
    const end = start + length;
    const value = this.bytes.subarray(start, end);
    this.offset = end;
    return value;
  }
  readString() {
    const length = this.readUint32();
    const bytes = this.readBytes(length);
    return this.decoder.decode(bytes);
  }
  readJson() {
    const string = this.readString();
    return JSON.parse(string);
  }
};
function getDataView(bytes) {
  return new DataView(bytes.buffer, bytes.byteOffset, bytes.byteLength);
}

// src/code-generation/components/cms/bundled/DatabaseDictionaryIndex.ts
import { ControlType as ControlType2 } from "framer";

// ../../library/src/utils/utils.ts
var isWindow = typeof window !== "undefined";
var supportsRequestIdleCallback = isWindow && typeof window.requestIdleCallback === "function";

// src/code-generation/components/cms/bundled/assert.ts
function assert(condition, ...msg) {
  if (condition) return;
  throw Error("Assertion Error" + (msg.length > 0 ? ": " + msg.join(" ") : ""));
}
function assertNever(condition) {
  throw new Error(\`Unexpected value: \${condition}\`);
}

// src/code-generation/components/cms/bundled/BufferWriter.ts
var INITIAL_BUFFER_SIZE = 1024;
var GROWTH_FACTOR = 1.5;
var maxUnsignedNumber = (bits) => 2 ** bits - 1;
var minSignedNumber = (bits) => -(2 ** (bits - 1));
var maxSignedNumber = (bits) => 2 ** (bits - 1) - 1;
var MIN_VALUE = {
  Uint8: 0,
  Uint16: 0,
  Uint32: 0,
  Uint64: 0,
  BigUint64: 0,
  Int8: minSignedNumber(8),
  Int16: minSignedNumber(16),
  Int32: minSignedNumber(32),
  Int64: Number.MIN_SAFE_INTEGER,
  BigInt64: -(BigInt(2) ** BigInt(63))
};
var MAX_VALUE = {
  Uint8: maxUnsignedNumber(8),
  Uint16: maxUnsignedNumber(16),
  Uint32: maxUnsignedNumber(32),
  Uint64: Number.MAX_SAFE_INTEGER,
  BigUint64: BigInt(2) ** BigInt(64) - BigInt(1),
  Int8: maxSignedNumber(8),
  Int16: maxSignedNumber(16),
  Int32: maxSignedNumber(32),
  Int64: Number.MAX_SAFE_INTEGER,
  BigInt64: BigInt(2) ** BigInt(63) - BigInt(1)
};
function assertRange(value, min, max, dataType) {
  assert(value >= min, value, "outside lower bound for", dataType);
  assert(value <= max, value, "outside upper bound for", dataType);
}
var BufferWriter = class {
  constructor() {
    __publicField(this, "offset", 0);
    __publicField(this, "bytes", new Uint8Array(INITIAL_BUFFER_SIZE));
    __publicField(this, "view", getDataView(this.bytes));
    __publicField(this, "encoder", new TextEncoder());
    __publicField(this, "encodedStrings", /* @__PURE__ */ new Map());
  }
  getOffset() {
    return this.offset;
  }
  slice(start = 0, end = this.offset) {
    return this.bytes.slice(start, end);
  }
  subarray(start = 0, end = this.offset) {
    return this.bytes.subarray(start, end);
  }
  ensureLength(requiredBytes) {
    const oldLength = this.bytes.length;
    if (this.offset + requiredBytes <= oldLength) return;
    const newLength = Math.ceil(oldLength * GROWTH_FACTOR) + requiredBytes;
    const newBytes = new Uint8Array(newLength);
    newBytes.set(this.bytes);
    this.bytes = newBytes;
    this.view = getDataView(newBytes);
  }
  writeUint8(value) {
    assertRange(value, MIN_VALUE.Uint8, MAX_VALUE.Uint8, "Uint8");
    const size = BYTE_LENGTH.Uint8;
    this.ensureLength(size);
    this.view.setUint8(this.offset, value);
    this.offset += size;
  }
  writeUint16(value) {
    assertRange(value, MIN_VALUE.Uint16, MAX_VALUE.Uint16, "Uint16");
    const size = BYTE_LENGTH.Uint16;
    this.ensureLength(size);
    this.view.setUint16(this.offset, value);
    this.offset += size;
  }
  writeUint32(value) {
    assertRange(value, MIN_VALUE.Uint32, MAX_VALUE.Uint32, "Uint32");
    const size = BYTE_LENGTH.Uint32;
    this.ensureLength(size);
    this.view.setUint32(this.offset, value);
    this.offset += size;
  }
  writeUint64(value) {
    assertRange(value, MIN_VALUE.Uint64, MAX_VALUE.Uint64, "Uint64");
    const bigint = BigInt(value);
    this.writeBigUint64(bigint);
  }
  writeBigUint64(value) {
    assertRange(value, MIN_VALUE.BigUint64, MAX_VALUE.BigUint64, "BigUint64");
    const size = BYTE_LENGTH.BigUint64;
    this.ensureLength(size);
    this.view.setBigUint64(this.offset, value);
    this.offset += size;
  }
  writeInt8(value) {
    assertRange(value, MIN_VALUE.Int8, MAX_VALUE.Int8, "Int8");
    const size = BYTE_LENGTH.Int8;
    this.ensureLength(size);
    this.view.setInt8(this.offset, value);
    this.offset += size;
  }
  writeInt16(value) {
    assertRange(value, MIN_VALUE.Int16, MAX_VALUE.Int16, "Int16");
    const size = BYTE_LENGTH.Int16;
    this.ensureLength(size);
    this.view.setInt16(this.offset, value);
    this.offset += size;
  }
  writeInt32(value) {
    assertRange(value, MIN_VALUE.Int32, MAX_VALUE.Int32, "Int32");
    const size = BYTE_LENGTH.Int32;
    this.ensureLength(size);
    this.view.setInt32(this.offset, value);
    this.offset += size;
  }
  writeInt64(value) {
    assertRange(value, MIN_VALUE.Int64, MAX_VALUE.Int64, "Int64");
    const bigint = BigInt(value);
    this.writeBigInt64(bigint);
  }
  writeBigInt64(value) {
    assertRange(value, MIN_VALUE.BigInt64, MAX_VALUE.BigInt64, "BigInt64");
    const size = BYTE_LENGTH.BigInt64;
    this.ensureLength(size);
    this.view.setBigInt64(this.offset, value);
    this.offset += size;
  }
  writeFloat32(value) {
    const size = BYTE_LENGTH.Float32;
    this.ensureLength(size);
    this.view.setFloat32(this.offset, value);
    this.offset += size;
  }
  writeFloat64(value) {
    const size = BYTE_LENGTH.Float64;
    this.ensureLength(size);
    this.view.setFloat64(this.offset, value);
    this.offset += size;
  }
  writeBytes(value) {
    const size = value.length;
    this.ensureLength(size);
    this.bytes.set(value, this.offset);
    this.offset += size;
  }
  encodeString(value) {
    const cached = this.encodedStrings.get(value);
    if (cached) return cached;
    const bytes = this.encoder.encode(value);
    this.encodedStrings.set(value, bytes);
    return bytes;
  }
  writeString(value) {
    const bytes = this.encodeString(value);
    const size = bytes.length;
    this.writeUint32(size);
    this.writeBytes(bytes);
  }
  writeJson(value) {
    const json = JSON.stringify(value);
    this.writeString(json);
  }
};

// src/utils/typeChecks.ts
function isString(value) {
  return typeof value === "string";
}
function isNumber(value) {
  return Number.isFinite(value);
}
function isNull(value) {
  return value === null;
}

// src/code-generation/components/cms/bundled/models/DatabaseItemPointerModel.ts
var DatabaseItemPointerModel = class _DatabaseItemPointerModel {
  constructor(chunkId, offset, length) {
    this.chunkId = chunkId;
    this.offset = offset;
    this.length = length;
  }
  static fromString(value) {
    const [chunkId, offset, length] = value.split("/").map(Number);
    assert(isNumber(chunkId), "Invalid chunkId");
    assert(isNumber(offset), "Invalid offset");
    assert(isNumber(length), "Invalid length");
    return new _DatabaseItemPointerModel(chunkId, offset, length);
  }
  toString() {
    return \`\${this.chunkId}/\${this.offset}/\${this.length}\`;
  }
  static read(reader) {
    const chunkId = reader.readUint16();
    const offset = reader.readUint32();
    const length = reader.readUint32();
    return new _DatabaseItemPointerModel(chunkId, offset, length);
  }
  write(writer) {
    writer.writeUint16(this.chunkId);
    writer.writeUint32(this.offset);
    writer.writeUint32(this.length);
  }
  compare(other) {
    if (this.chunkId < other.chunkId) return -1;
    if (this.chunkId > other.chunkId) return 1;
    if (this.offset < other.offset) return -1;
    if (this.offset > other.offset) return 1;
    assert(this.length === other.length);
    return 0;
  }
};

// src/code-generation/components/cms/bundled/models/DatabaseValueModel.ts
import { ControlType } from "framer";
function getValueType(value) {
  if (isNull(value)) {
    return 0 /* Null */;
  }
  switch (value.type) {
    case ControlType.Array:
      return 1 /* Array */;
    case ControlType.Boolean:
      return 2 /* Boolean */;
    case ControlType.Color:
      return 3 /* Color */;
    case ControlType.Date:
      return 4 /* Date */;
    case ControlType.Enum:
      return 5 /* Enum */;
    case ControlType.File:
      return 6 /* File */;
    case ControlType.ResponsiveImage:
      return 10 /* ResponsiveImage */;
    case ControlType.Link:
      return 7 /* Link */;
    case ControlType.Number:
      return 8 /* Number */;
    case ControlType.Object:
      return 9 /* Object */;
    case ControlType.RichText:
      return 11 /* RichText */;
    case ControlType.String:
      return 12 /* String */;
    case ControlType.VectorSetItem:
      return 13 /* VectorSetItem */;
    default:
      assertNever(value);
  }
}
var DatabaseValueModel;
((DatabaseValueModel2) => {
  function read(reader) {
    const type = reader.readUint8();
    switch (type) {
      case 0 /* Null */:
        return null;
      case 1 /* Array */:
        return readArray(reader);
      case 2 /* Boolean */:
        return readBoolean(reader);
      case 3 /* Color */:
        return readColor(reader);
      case 4 /* Date */:
        return readDate(reader);
      case 5 /* Enum */:
        return readEnum(reader);
      case 6 /* File */:
        return readFile(reader);
      case 7 /* Link */:
        return readLink(reader);
      case 8 /* Number */:
        return readNumber(reader);
      case 9 /* Object */:
        return readObject(reader);
      case 10 /* ResponsiveImage */:
        return readResponsiveImage(reader);
      case 11 /* RichText */:
        return readRichText(reader);
      case 12 /* String */:
        return readString(reader);
      case 13 /* VectorSetItem */:
        return readVectorSetItem(reader);
      default:
        assertNever(type);
    }
  }
  DatabaseValueModel2.read = read;
  function write(writer, value) {
    const type = getValueType(value);
    writer.writeUint8(type);
    if (isNull(value)) return;
    switch (value.type) {
      case ControlType.Array:
        return writeArray(writer, value);
      case ControlType.Boolean:
        return writeBoolean(writer, value);
      case ControlType.Color:
        return writeColor(writer, value);
      case ControlType.Date:
        return writeDate(writer, value);
      case ControlType.Enum:
        return writeEnum(writer, value);
      case ControlType.File:
        return writeFile(writer, value);
      case ControlType.Link:
        return writeLink(writer, value);
      case ControlType.Number:
        return writeNumber(writer, value);
      case ControlType.Object:
        return writeObject(writer, value);
      case ControlType.ResponsiveImage:
        return writeResponsiveImage(writer, value);
      case ControlType.RichText:
        return writeRichText(writer, value);
      case ControlType.VectorSetItem:
        return writeVectorSetItem(writer, value);
      case ControlType.String:
        return writeString(writer, value);
      default:
        assertNever(value);
    }
  }
  DatabaseValueModel2.write = write;
  function compare(left, right, collation) {
    const leftType = getValueType(left);
    const rightType = getValueType(right);
    if (leftType < rightType) return -1;
    if (leftType > rightType) return 1;
    if (isNull(left) || isNull(right)) return 0;
    switch (left.type) {
      case ControlType.Array:
        assert(right.type === ControlType.Array);
        return compareArray(left, right, collation);
      case ControlType.Boolean:
        assert(right.type === ControlType.Boolean);
        return compareBoolean(left, right);
      case ControlType.Color:
        assert(right.type === ControlType.Color);
        return compareColor(left, right);
      case ControlType.Date:
        assert(right.type === ControlType.Date);
        return compareDate(left, right);
      case ControlType.Enum:
        assert(right.type === ControlType.Enum);
        return compareEnum(left, right);
      case ControlType.File:
        assert(right.type === ControlType.File);
        return compareFile(left, right);
      case ControlType.Link:
        assert(right.type === ControlType.Link);
        return compareLink(left, right);
      case ControlType.Number:
        assert(right.type === ControlType.Number);
        return compareNumber(left, right);
      case ControlType.Object:
        assert(right.type === ControlType.Object);
        return compareObject(left, right, collation);
      case ControlType.ResponsiveImage:
        assert(right.type === ControlType.ResponsiveImage);
        return compareResponsiveImage(left, right);
      case ControlType.RichText:
        assert(right.type === ControlType.RichText);
        return compareRichText(left, right);
      case ControlType.VectorSetItem:
        assert(right.type === ControlType.VectorSetItem);
        return compareVectorSetItem(left, right);
      case ControlType.String:
        assert(right.type === ControlType.String);
        return compareString(left, right, collation);
      default:
        assertNever(left);
    }
  }
  DatabaseValueModel2.compare = compare;
})(DatabaseValueModel || (DatabaseValueModel = {}));
function readArray(reader) {
  const length = reader.readUint16();
  const value = [];
  for (let i = 0; i < length; i++) {
    const item = DatabaseValueModel.read(reader);
    value.push(item);
  }
  return {
    type: ControlType.Array,
    value
  };
}
function writeArray(writer, value) {
  writer.writeUint16(value.value.length);
  for (const item of value.value) {
    DatabaseValueModel.write(writer, item);
  }
}
function compareArray(left, right, collation) {
  const leftLength = left.value.length;
  const rightLength = right.value.length;
  if (leftLength < rightLength) return -1;
  if (leftLength > rightLength) return 1;
  for (let i = 0; i < leftLength; i++) {
    const leftItem = left.value[i];
    const rightItem = right.value[i];
    const result = DatabaseValueModel.compare(leftItem, rightItem, collation);
    if (result !== 0) return result;
  }
  return 0;
}
function readBoolean(reader) {
  return {
    type: ControlType.Boolean,
    value: reader.readUint8() !== 0
  };
}
function writeBoolean(writer, value) {
  writer.writeUint8(value.value ? 1 : 0);
}
function compareBoolean(left, right) {
  if (left.value < right.value) return -1;
  if (left.value > right.value) return 1;
  return 0;
}
function readColor(reader) {
  return {
    type: ControlType.Color,
    value: reader.readString()
  };
}
function writeColor(writer, value) {
  writer.writeString(value.value);
}
function compareColor(left, right) {
  if (left.value < right.value) return -1;
  if (left.value > right.value) return 1;
  return 0;
}
function readDate(reader) {
  const timestamp = reader.readInt64();
  const date = new Date(timestamp);
  return {
    type: ControlType.Date,
    value: date.toISOString()
  };
}
function writeDate(writer, value) {
  const date = new Date(value.value);
  const timestamp = date.getTime();
  writer.writeInt64(timestamp);
}
function compareDate(left, right) {
  const leftDate = new Date(left.value);
  const rightDate = new Date(right.value);
  if (leftDate < rightDate) return -1;
  if (leftDate > rightDate) return 1;
  return 0;
}
function readEnum(reader) {
  return {
    type: ControlType.Enum,
    value: reader.readString()
  };
}
function writeEnum(writer, value) {
  writer.writeString(value.value);
}
function compareEnum(left, right) {
  if (left.value < right.value) return -1;
  if (left.value > right.value) return 1;
  return 0;
}
function readFile(reader) {
  return {
    type: ControlType.File,
    value: reader.readString()
  };
}
function writeFile(writer, value) {
  writer.writeString(value.value);
}
function compareFile(left, right) {
  if (left.value < right.value) return -1;
  if (left.value > right.value) return 1;
  return 0;
}
function readLink(reader) {
  return {
    type: ControlType.Link,
    value: reader.readJson()
  };
}
function writeLink(writer, value) {
  writer.writeJson(value.value);
}
function compareLink(left, right) {
  const leftEncoded = JSON.stringify(left.value);
  const rightEncoded = JSON.stringify(right.value);
  if (leftEncoded < rightEncoded) return -1;
  if (leftEncoded > rightEncoded) return 1;
  return 0;
}
function readNumber(reader) {
  return {
    type: ControlType.Number,
    value: reader.readFloat64()
  };
}
function writeNumber(writer, value) {
  writer.writeFloat64(value.value);
}
function compareNumber(left, right) {
  if (left.value < right.value) return -1;
  if (left.value > right.value) return 1;
  return 0;
}
function readObject(reader) {
  const length = reader.readUint16();
  const result = {};
  for (let i = 0; i < length; i++) {
    const key = reader.readString();
    result[key] = DatabaseValueModel.read(reader);
  }
  return {
    type: ControlType.Object,
    value: result
  };
}
function writeObject(writer, value) {
  const entries = Object.entries(value.value);
  writer.writeUint16(entries.length);
  for (const [key, item] of entries) {
    writer.writeString(key);
    DatabaseValueModel.write(writer, item);
  }
}
function compareObject(left, right, collation) {
  const leftKeys = Object.keys(left.value).sort();
  const rightKeys = Object.keys(right.value).sort();
  if (leftKeys.length < rightKeys.length) return -1;
  if (leftKeys.length > rightKeys.length) return 1;
  for (let i = 0; i < leftKeys.length; i++) {
    const leftKey = leftKeys[i];
    const rightKey = rightKeys[i];
    if (leftKey < rightKey) return -1;
    if (leftKey > rightKey) return 1;
    const leftValue = left.value[leftKey] ?? null;
    const rightValue = right.value[rightKey] ?? null;
    const result = DatabaseValueModel.compare(leftValue, rightValue, collation);
    if (result !== 0) return result;
  }
  return 0;
}
function readResponsiveImage(reader) {
  return {
    type: ControlType.ResponsiveImage,
    value: reader.readJson()
  };
}
function writeResponsiveImage(writer, value) {
  writer.writeJson(value.value);
}
function compareResponsiveImage(left, right) {
  const leftEncoded = JSON.stringify(left.value);
  const rightEncoded = JSON.stringify(right.value);
  if (leftEncoded < rightEncoded) return -1;
  if (leftEncoded > rightEncoded) return 1;
  return 0;
}
function readRichText(reader) {
  const type = reader.readInt8();
  if (type === 0) {
    return {
      type: ControlType.RichText,
      value: reader.readUint32()
    };
  }
  if (type === 1) {
    return {
      type: ControlType.RichText,
      value: reader.readString()
    };
  }
  throw new Error(\`Invalid rich text pointer\`);
}
function writeRichText(writer, value) {
  if (isNumber(value.value)) {
    writer.writeInt8(0);
    writer.writeUint32(value.value);
    return;
  }
  if (isString(value.value)) {
    writer.writeInt8(1);
    writer.writeString(value.value);
    return;
  }
  throw new Error(\`Invalid rich text pointer\`);
}
function compareRichText(left, right) {
  const leftValue = left.value;
  const rightValue = right.value;
  if (isNumber(leftValue) && isNumber(rightValue)) {
    if (leftValue < rightValue) return -1;
    if (leftValue > rightValue) return 1;
    return 0;
  }
  if (isString(leftValue) && isString(rightValue)) {
    if (leftValue < rightValue) return -1;
    if (leftValue > rightValue) return 1;
    return 0;
  }
  throw new Error(\`Invalid rich text pointer\`);
}
function readString(reader) {
  return {
    type: ControlType.String,
    value: reader.readString()
  };
}
function writeString(writer, value) {
  writer.writeString(value.value);
}
function compareString(left, right, collation) {
  let leftValue = left.value;
  let rightValue = right.value;
  if (collation.type === 0 /* CaseInsensitive */) {
    leftValue = left.value.toLowerCase();
    rightValue = right.value.toLowerCase();
  }
  if (leftValue < rightValue) return -1;
  if (leftValue > rightValue) return 1;
  return 0;
}
function readVectorSetItem(reader) {
  return {
    type: ControlType.VectorSetItem,
    value: reader.readUint32()
  };
}
function writeVectorSetItem(writer, value) {
  writer.writeUint32(value.value);
}
function compareVectorSetItem(left, right) {
  const leftValue = left.value;
  const rightValue = right.value;
  if (leftValue < rightValue) return -1;
  if (leftValue > rightValue) return 1;
  return 0;
}

// src/code-generation/components/cms/bundled/models/DatabaseDictionaryIndexModel.ts
var DatabaseDictionaryIndexModel = class _DatabaseDictionaryIndexModel {
  constructor(fieldNames, options) {
    this.fieldNames = fieldNames;
    this.options = options;
    __publicField(this, "entries", []);
  }
  sortEntries() {
    this.entries.sort((left, right) => {
      for (let i = 0; i < this.fieldNames.length; i++) {
        const leftValue = left.values[i];
        const rightValue = right.values[i];
        const result = DatabaseValueModel.compare(leftValue, rightValue, this.options.collation);
        if (result !== 0) return result;
      }
      return left.pointer.compare(right.pointer);
    });
  }
  static deserialize(bytes) {
    const reader = new BufferReader(bytes);
    const collation = reader.readJson();
    const fieldCount = reader.readUint8();
    const fieldNames = [];
    for (let i = 0; i < fieldCount; i++) {
      const fieldName = reader.readString();
      fieldNames.push(fieldName);
    }
    const index = new _DatabaseDictionaryIndexModel(fieldNames, {
      collation
    });
    const entryCount = reader.readUint32();
    for (let i = 0; i < entryCount; i++) {
      const values = [];
      for (let j = 0; j < fieldCount; j++) {
        const fieldValue = DatabaseValueModel.read(reader);
        values.push(fieldValue);
      }
      const pointer = DatabaseItemPointerModel.read(reader);
      index.entries.push({ values, pointer });
    }
    return index;
  }
  serialize() {
    const writer = new BufferWriter();
    writer.writeJson(this.options.collation);
    writer.writeUint8(this.fieldNames.length);
    for (const fieldName of this.fieldNames) {
      writer.writeString(fieldName);
    }
    this.sortEntries();
    writer.writeUint32(this.entries.length);
    for (const entry of this.entries) {
      const { values, pointer } = entry;
      for (const value of values) {
        DatabaseValueModel.write(writer, value);
      }
      pointer.write(writer);
    }
    return writer.subarray();
  }
  addItem(item, pointer) {
    const values = this.fieldNames.map((fieldName) => {
      return item.getField(fieldName) ?? null;
    });
    this.entries.push({ values, pointer });
  }
};

// src/code-generation/components/cms/bundled/fetchWithRetries.ts
var maxRetries = 3;
var baseDelay = 250;
var retriableHTTPCodes = [
  408,
  // Request Timeout
  429,
  // Too Many Requests
  500,
  // Internal Server Error
  502,
  // Bad Gateway
  503,
  // Service Unavailable
  504
  // Gateway Timeout
];
var fetchWithRetries = async (input, init) => {
  let retryCount = 0;
  while (true) {
    try {
      const res = await fetch(input, init);
      if (!retriableHTTPCodes.includes(res.status) || ++retryCount > maxRetries) {
        return res;
      }
    } catch (error) {
      if (init?.signal?.aborted || ++retryCount > maxRetries) {
        throw error;
      }
    }
    await retryDelay(retryCount);
  }
};
async function retryDelay(retryCount) {
  const backoffExponent = retryCount - 1;
  const jitter = Math.random() + 1;
  const timeout = Math.floor(baseDelay * jitter * 2 ** backoffExponent);
  await new Promise((resolve) => {
    setTimeout(resolve, timeout);
  });
}

// src/code-generation/components/cms/bundled/rangeRequest.ts
async function rangeRequest(url, ranges) {
  const collapsedRanges = collapseRanges(ranges);
  const rangeStrings = [];
  let expectedLength = 0;
  for (const range of collapsedRanges) {
    rangeStrings.push(\`\${range.from}-\${range.to - 1}\`);
    expectedLength += range.to - range.from;
  }
  const rangeUrl = new URL(url);
  const rangeQuery = rangeStrings.join(",");
  rangeUrl.searchParams.set("range", rangeQuery);
  const response = await fetchWithRetries(rangeUrl);
  if (response.status !== 200) {
    throw new Error(\`Request failed: \${response.status} \${response.statusText}\`);
  }
  const buffer = await response.arrayBuffer();
  const bytes = new Uint8Array(buffer);
  if (bytes.length !== expectedLength) {
    throw new Error("Request failed: Unexpected response length");
  }
  const file = new PartialFile();
  let start = 0;
  for (const range of collapsedRanges) {
    const length = range.to - range.from;
    const end = start + length;
    const part = bytes.subarray(start, end);
    file.write(range.from, part);
    start = end;
  }
  return ranges.map((range) => {
    return file.read(range.from, range.to - range.from);
  });
}
var PartialFile = class {
  constructor() {
    __publicField(this, "chunks", []);
  }
  read(position, length) {
    for (const chunk of this.chunks) {
      if (position < chunk.start) {
        throw new Error("Missing data");
      }
      if (position > chunk.end) {
        continue;
      }
      if (position + length > chunk.end) {
        throw new Error("Missing data");
      }
      const from = position - chunk.start;
      const to = from + length;
      return chunk.data.slice(from, to);
    }
    throw new Error("Missing data");
  }
  write(position, data) {
    let start = position;
    let end = start + data.length;
    let fromIndex = 0;
    let toIndex = this.chunks.length;
    for (; fromIndex < toIndex; fromIndex++) {
      const chunk2 = this.chunks[fromIndex];
      assert(chunk2, "Missing chunk");
      if (start > chunk2.end) {
        continue;
      }
      if (start > chunk2.start) {
        const offset = start - chunk2.start;
        const prefix = chunk2.data.subarray(0, offset);
        data = join(prefix, data);
        start = chunk2.start;
      }
      break;
    }
    for (; toIndex > fromIndex; toIndex--) {
      const chunk2 = this.chunks[toIndex - 1];
      assert(chunk2, "Missing chunk");
      if (end < chunk2.start) {
        continue;
      }
      if (end < chunk2.end) {
        const offset = end - chunk2.start;
        const suffix = chunk2.data.subarray(offset);
        data = join(data, suffix);
        end = chunk2.end;
      }
      break;
    }
    const chunk = {
      start,
      end,
      data
    };
    const deleteCount = toIndex - fromIndex;
    this.chunks.splice(fromIndex, deleteCount, chunk);
  }
};
function join(left, right) {
  const length = left.length + right.length;
  const result = new Uint8Array(length);
  result.set(left, 0);
  result.set(right, left.length);
  return result;
}
function collapseRanges(ranges) {
  assert(ranges.length > 0, "Must have at least one range");
  const sorted = [...ranges].sort((a, b) => a.from - b.from);
  const collapsed = [];
  for (const range of sorted) {
    const index = collapsed.length - 1;
    const previous = collapsed[index];
    if (previous && range.from <= previous.to) {
      collapsed[index] = {
        from: previous.from,
        to: Math.max(previous.to, range.to)
      };
    } else {
      collapsed.push(range);
    }
  }
  return collapsed;
}

// src/code-generation/components/cms/bundled/DatabaseDictionaryIndex.ts
var DatabaseDictionaryIndex = class {
  constructor(options) {
    this.options = options;
    __publicField(this, "schema");
    __publicField(this, "fields");
    __publicField(this, "supportedLookupTypes", [
      "All" /* All */,
      "Equals" /* Equals */,
      "NotEquals" /* NotEquals */,
      "LessThan" /* LessThan */,
      "GreaterThan" /* GreaterThan */,
      "Contains" /* Contains */,
      "StartsWith" /* StartsWith */,
      "EndsWith" /* EndsWith */
    ]);
    __publicField(this, "modelPromise");
    __publicField(this, "model");
    __publicField(this, "collation");
    const schema = {};
    const fields = [];
    for (const fieldName of this.options.fieldNames) {
      const definition = this.options.collectionSchema[fieldName];
      assert(definition, "Missing definition for field", fieldName);
      schema[fieldName] = definition;
      fields.push({ type: "Identifier", name: fieldName });
    }
    this.schema = schema;
    this.fields = fields;
    this.collation = this.options.collation;
  }
  async loadModel() {
    const [bytes] = await rangeRequest(this.options.url, [this.options.range]);
    assert(bytes, "Failed to load model");
    return DatabaseDictionaryIndexModel.deserialize(bytes);
  }
  async getModel() {
    this.modelPromise ??= this.loadModel();
    this.model ??= await this.modelPromise;
    return this.model;
  }
  async lookupItems(queries) {
    assert(queries.length === this.fields.length, "Invalid query length");
    const model = await this.getModel();
    const chunks = queries.reduce(
      (memo, query, position) => memo.flatMap((entries) => {
        switch (query.type) {
          case "All" /* All */:
            return [entries];
          case "Equals" /* Equals */:
            return this.queryEquals(entries, query, position);
          case "NotEquals" /* NotEquals */:
            return this.queryNotEquals(entries, query, position);
          case "LessThan" /* LessThan */:
            return this.queryLessThan(entries, query, position);
          case "GreaterThan" /* GreaterThan */:
            return this.queryGreaterThan(entries, query, position);
          case "Contains" /* Contains */:
            return this.queryContains(entries, query, position);
          case "StartsWith" /* StartsWith */:
            return this.queryStartsWith(entries, query, position);
          case "EndsWith" /* EndsWith */:
            return this.queryEndsWith(entries, query, position);
          default:
            assertNever(query);
        }
      }),
      [model.entries]
    );
    const result = [];
    for (const entries of chunks) {
      for (const entry of entries) {
        const data = {};
        for (let i = 0; i < this.options.fieldNames.length; i++) {
          const fieldName = this.options.fieldNames[i];
          const fieldValue = entry.values[i];
          data[fieldName] = fieldValue;
        }
        result.push({ pointer: entry.pointer.toString(), data });
      }
    }
    return result;
  }
  queryEquals(entries, query, position) {
    const leftMost = this.getLeftMost(entries, position, query.value);
    const rightMost = this.getRightMost(entries, position, query.value);
    const slice = entries.slice(leftMost, rightMost + 1);
    return slice.length > 0 ? [slice] : [];
  }
  queryNotEquals(entries, query, position) {
    const leftMost = this.getLeftMost(entries, position, query.value);
    const rightMost = this.getRightMost(entries, position, query.value);
    const result = [];
    const before = entries.slice(0, leftMost);
    if (before.length > 0) result.push(before);
    const after = entries.slice(rightMost + 1);
    if (after.length > 0) result.push(after);
    return result;
  }
  queryLessThan(entries, query, position) {
    const nullBound = this.getRightMost(entries, position, null);
    entries = entries.slice(nullBound + 1);
    if (query.inclusive) {
      const rightMost = this.getRightMost(entries, position, query.value);
      const slice2 = entries.slice(0, rightMost + 1);
      return slice2.length > 0 ? [slice2] : [];
    }
    const leftMost = this.getLeftMost(entries, position, query.value);
    const slice = entries.slice(0, leftMost);
    return slice.length > 0 ? [slice] : [];
  }
  queryGreaterThan(entries, query, position) {
    const nullBound = this.getRightMost(entries, position, null);
    entries = entries.slice(nullBound + 1);
    if (query.inclusive) {
      const leftMost = this.getLeftMost(entries, position, query.value);
      const slice2 = entries.slice(leftMost);
      return slice2.length > 0 ? [slice2] : [];
    }
    const rightMost = this.getRightMost(entries, position, query.value);
    const slice = entries.slice(rightMost + 1);
    return slice.length > 0 ? [slice] : [];
  }
  queryContains(entries, query, position) {
    return this.findItems(entries, position, (current) => {
      if (current?.type !== ControlType2.String) return false;
      if (query.value?.type !== ControlType2.String) return false;
      let source = current.value;
      let target = query.value.value;
      if (this.collation.type === 0 /* CaseInsensitive */) {
        source = source.toLowerCase();
        target = target.toLowerCase();
      }
      return source.includes(target);
    });
  }
  queryStartsWith(entries, query, position) {
    return this.findItems(entries, position, (current) => {
      if (current?.type !== ControlType2.String) return false;
      if (query.value?.type !== ControlType2.String) return false;
      let source = current.value;
      let target = query.value.value;
      if (this.collation.type === 0 /* CaseInsensitive */) {
        source = source.toLowerCase();
        target = target.toLowerCase();
      }
      return source.startsWith(target);
    });
  }
  queryEndsWith(entries, query, position) {
    return this.findItems(entries, position, (current) => {
      if (current?.type !== ControlType2.String) return false;
      if (query.value?.type !== ControlType2.String) return false;
      let source = current.value;
      let target = query.value.value;
      if (this.collation.type === 0 /* CaseInsensitive */) {
        source = source.toLowerCase();
        target = target.toLowerCase();
      }
      return source.endsWith(target);
    });
  }
  /**
   * Returns the index of the left most entry that is equal to the target.
   *
   * \`\`\`text
   *   Left most
   *       \u2193
   * \u250C\u2500\u2500\u2500\u252C\u2500\u2500\u2500\u252C\u2500\u2500\u2500\u252C\u2500\u2500\u2500\u252C\u2500\u2500\u2500\u252C\u2500\u2500\u2500\u2510
   * \u2502 1 \u2502 2 \u2502 2 \u2502 2 \u2502 2 \u2502 3 \u2502
   * \u2514\u2500\u2500\u2500\u2534\u2500\u2500\u2500\u2534\u2500\u2500\u2500\u2534\u2500\u2500\u2500\u2534\u2500\u2500\u2500\u2534\u2500\u2500\u2500\u2518
   * \`\`\`
   *
   * @param entries The entries array to search in.
   * @param position The position of the value in the entry.
   * @param target The target value to search for.
   * @returns The index of the left most entry that is equal to the target.
   */
  getLeftMost(entries, position, target) {
    let left = 0;
    let right = entries.length;
    while (left < right) {
      const middle = left + right >> 1;
      const entry = entries[middle];
      const value = entry.values[position];
      if (DatabaseValueModel.compare(value, target, this.collation) < 0) {
        left = middle + 1;
      } else {
        right = middle;
      }
    }
    return left;
  }
  /**
   * Returns the index of the right most entry that is equal to the target.
   *
   * \`\`\`text
   *              Right most
   *                   \u2193
   * \u250C\u2500\u2500\u2500\u252C\u2500\u2500\u2500\u252C\u2500\u2500\u2500\u252C\u2500\u2500\u2500\u252C\u2500\u2500\u2500\u252C\u2500\u2500\u2500\u2510
   * \u2502 1 \u2502 2 \u2502 2 \u2502 2 \u2502 2 \u2502 3 \u2502
   * \u2514\u2500\u2500\u2500\u2534\u2500\u2500\u2500\u2534\u2500\u2500\u2500\u2534\u2500\u2500\u2500\u2534\u2500\u2500\u2500\u2534\u2500\u2500\u2500\u2518
   * \`\`\`
   *
   * @param entries The entries array to search in.
   * @param position The position of the value in the entry.
   * @param target The target value to search for.
   * @returns The index of the right most entry that is equal to the target.
   */
  getRightMost(entries, position, target) {
    let left = 0;
    let right = entries.length;
    while (left < right) {
      const middle = left + right >> 1;
      const entry = entries[middle];
      const value = entry.values[position];
      if (DatabaseValueModel.compare(value, target, this.collation) > 0) {
        right = middle;
      } else {
        left = middle + 1;
      }
    }
    return right - 1;
  }
  /**
   * Finds all items that are matching the predicate and groups adjacent items together.
   *
   * @param entries The entries array to search in.
   * @param position The position of the value in the entry.
   * @param predicate The predicate to match the values against.
   * @returns An array of chunks that match the predicate.
   */
  findItems(entries, position, predicate) {
    const result = [];
    let start = 0;
    for (let i = 0; i < entries.length; i++) {
      const entry = entries[i];
      const value = entry.values[position];
      const isMatching = predicate(value);
      if (isMatching) continue;
      if (start < i) {
        const slice = entries.slice(start, i);
        result.push(slice);
      }
      start = i + 1;
    }
    if (start < entries.length) {
      const slice = entries.slice(start);
      result.push(slice);
    }
    return result;
  }
};

// src/code-generation/components/cms/bundled/models/DatabaseItemModel.ts
var DatabaseItemModel = class _DatabaseItemModel {
  constructor() {
    __publicField(this, "fields", /* @__PURE__ */ new Map());
  }
  static read(reader) {
    const item = new _DatabaseItemModel();
    const fieldCount = reader.readUint16();
    for (let i = 0; i < fieldCount; i++) {
      const key = reader.readString();
      const value = DatabaseValueModel.read(reader);
      item.setField(key, value);
    }
    return item;
  }
  write(writer) {
    writer.writeUint16(this.fields.size);
    for (const [key, value] of this.fields) {
      writer.writeString(key);
      DatabaseValueModel.write(writer, value);
    }
  }
  getData() {
    const data = {};
    for (const [key, value] of this.fields) {
      data[key] = value;
    }
    return data;
  }
  setField(key, value) {
    this.fields.set(key, value);
  }
  getField(key) {
    return this.fields.get(key);
  }
};

// src/code-generation/components/cms/bundled/DatabaseCollection.ts?bundle
var DatabaseChunk = class {
  constructor(id, url) {
    this.id = id;
    this.url = url;
    __publicField(this, "itemsPromise");
    __publicField(this, "itemLoader", new import_dataloader.default(
      async (pointers) => {
        const ranges = pointers.map((pointer) => {
          const pointerModel = DatabaseItemPointerModel.fromString(pointer);
          return { from: pointerModel.offset, to: pointerModel.offset + pointerModel.length };
        });
        const rangeBytes = await rangeRequest(this.url, ranges);
        return rangeBytes.map((bytes, index) => {
          const reader = new BufferReader(bytes);
          const itemModel = DatabaseItemModel.read(reader);
          const pointer = pointers[index];
          assert(pointer, "Missing pointer");
          return {
            pointer,
            data: itemModel.getData()
          };
        });
      },
      { maxBatchSize: 250 }
    ));
  }
  scanItems() {
    this.itemsPromise ??= fetchWithRetries(this.url).then(async (response) => {
      if (!response.ok) {
        throw new Error(\`Request failed: \${response.status} \${response.statusText}\`);
      }
      const buffer = await response.arrayBuffer();
      const bytes = new Uint8Array(buffer);
      const reader = new BufferReader(bytes);
      const items = [];
      const itemCount = reader.readUint32();
      for (let i = 0; i < itemCount; i++) {
        const offset = reader.getOffset();
        const itemModel = DatabaseItemModel.read(reader);
        const length = reader.getOffset() - offset;
        const pointerModel = new DatabaseItemPointerModel(this.id, offset, length);
        const pointer = pointerModel.toString();
        const item = {
          pointer,
          data: itemModel.getData()
        };
        this.itemLoader.prime(pointer, item);
        items.push(item);
      }
      return items;
    });
    return this.itemsPromise;
  }
  resolveItem(pointer) {
    return this.itemLoader.load(pointer);
  }
};
var DatabaseCollection = class {
  constructor(options) {
    this.options = options;
    __publicField(this, "id");
    __publicField(this, "schema");
    __publicField(this, "indexes");
    __publicField(this, "resolveRichText");
    __publicField(this, "resolveVectorSetItem");
    __publicField(this, "chunks");
    this.chunks = this.options.chunks.map((url, id) => {
      return new DatabaseChunk(id, url);
    });
    this.schema = options.schema;
    this.indexes = options.indexes;
    this.resolveRichText = options.resolveRichText;
    this.resolveVectorSetItem = options.resolveVectorSetItem;
    this.id = options.id;
  }
  async scanItems() {
    const chunkedItems = await Promise.all(
      this.chunks.map(async (chunk) => {
        return chunk.scanItems();
      })
    );
    return chunkedItems.flat();
  }
  resolveItems(pointers) {
    return Promise.all(
      pointers.map((pointer) => {
        const pointerModel = DatabaseItemPointerModel.fromString(pointer);
        const chunk = this.chunks[pointerModel.chunkId];
        assert(chunk, "Missing chunk");
        return chunk.resolveItem(pointer);
      })
    );
  }
  compareItems(left, right) {
    const leftModel = DatabaseItemPointerModel.fromString(left.pointer);
    const rightModel = DatabaseItemPointerModel.fromString(right.pointer);
    return leftModel.compare(rightModel);
  }
  compareValues(left, right, collation) {
    return DatabaseValueModel.compare(left, right, collation);
  }
};
export {
  DatabaseCollection,
  DatabaseDictionaryIndex
};
`;var la=`var __defProp = Object.defineProperty;
var __defNormalProp = (obj, key, value) => key in obj ? __defProp(obj, key, { enumerable: true, configurable: true, writable: true, value }) : obj[key] = value;
var __publicField = (obj, key, value) => __defNormalProp(obj, typeof key !== "symbol" ? key + "" : key, value);

// src/code-generation/components/cms/bundled/DraftDatabaseCollection.ts?bundle
import { ControlType } from "framer";

// src/utils/typeChecks.ts
function isString(value) {
  return typeof value === "string";
}
function isNumber(value) {
  return Number.isFinite(value);
}

// src/code-generation/components/cms/bundled/assert.ts
function assert(condition, ...msg) {
  if (condition) return;
  throw Error("Assertion Error" + (msg.length > 0 ? ": " + msg.join(" ") : ""));
}

// src/code-generation/components/cms/bundled/DraftDatabaseCollection.ts?bundle
var DraftDatabaseCollection = class {
  constructor(draftCollection, originalCollection, previousItemId, nextItemId) {
    this.draftCollection = draftCollection;
    this.originalCollection = originalCollection;
    this.previousItemId = previousItemId;
    this.nextItemId = nextItemId;
    __publicField(this, "schema");
    // We cannot use the original indexes because the draft items
    // are not in the original collection.
    // Having no indexes means that we perform a full collection scan for every query.
    __publicField(this, "indexes", []);
    __publicField(this, "itemsPromise");
    this.schema = originalCollection.schema;
    this.itemsPromise = this.getItems();
  }
  async getItems() {
    const [[...draftItems], [...originalItems]] = await Promise.all([
      this.draftCollection.scanItems(),
      this.originalCollection.scanItems()
    ]);
    const lastDraftItem = draftItems.pop();
    const firstOriginalItem = originalItems.shift();
    if (lastDraftItem) {
      draftItems.push({
        ...lastDraftItem,
        data: {
          ...lastDraftItem.data,
          [this.nextItemId]: firstOriginalItem?.data.id ?? null
        }
      });
    }
    if (firstOriginalItem) {
      originalItems.unshift({
        ...firstOriginalItem,
        data: {
          ...firstOriginalItem.data,
          [this.previousItemId]: lastDraftItem?.data.id ?? null
        }
      });
    }
    return draftItems.map(draftItem).concat(...originalItems);
  }
  /**
   * Get all items, updating pointers for draft items.
   */
  scanItems() {
    return this.itemsPromise;
  }
  /**
   * Depending on the pointer, resolve draft rich text from the draft
   * collection, and original rich text from the original collection.
   */
  resolveRichText(pointer) {
    if (isDraftRichTextPointer(pointer)) {
      const originalPointer = undraftRichTextPointer(pointer);
      return this.draftCollection.resolveRichText(originalPointer);
    }
    return this.originalCollection.resolveRichText(pointer);
  }
  resolveVectorSetItem(pointer) {
    if (isDraftVectorSetItemPointer(pointer)) {
      const originalPointer = undraftVectorSetItemPointer(pointer);
      return this.draftCollection.resolveVectorSetItem?.(originalPointer);
    }
    return this.originalCollection.resolveVectorSetItem?.(pointer);
  }
  async resolveItems(pointers) {
    const items = await this.itemsPromise;
    return pointers.map((pointer) => {
      const item = items.find((current) => current.pointer === pointer);
      assert(item, "Item must exist");
      return item;
    });
  }
  /**
   * Compare two items, the draft items should come first.
   */
  compareItems(left, right) {
    const leftIsDraft = isDraftPointer(left.pointer);
    const rightIsDraft = isDraftPointer(right.pointer);
    if (leftIsDraft && rightIsDraft) {
      const originalLeft = undraftItem(left);
      const originalRight = undraftItem(right);
      return this.draftCollection.compareItems(originalLeft, originalRight);
    }
    if (leftIsDraft) return -1;
    if (rightIsDraft) return 1;
    return this.originalCollection.compareItems(left, right);
  }
};
var draftPrefix = "draft:";
function isDraftPointer(pointer) {
  return pointer.startsWith(draftPrefix);
}
function draftPointer(pointer) {
  assert(!isDraftPointer(pointer), "Should be a non-draft pointer");
  return draftPrefix + pointer;
}
function undraftPointer(pointer) {
  assert(isDraftPointer(pointer), "Should be a draft pointer");
  return pointer.slice(draftPrefix.length);
}
function isDraftRichTextPointer(pointer) {
  if (isNumber(pointer)) {
    return pointer < 0;
  }
  if (isString(pointer)) {
    return pointer.startsWith(draftPrefix);
  }
  throw new Error("Invalid rich text pointer");
}
function draftRichTextPointer(pointer) {
  assert(!isDraftRichTextPointer(pointer), "Should be a non-draft rich text pointer");
  if (isNumber(pointer)) {
    return -pointer - 1;
  }
  if (isString(pointer)) {
    return draftPrefix + pointer;
  }
  throw new Error("Invalid rich text pointer");
}
function undraftRichTextPointer(pointer) {
  assert(isDraftRichTextPointer(pointer), "Should be a draft rich text pointer");
  if (isNumber(pointer)) {
    return -pointer - 1;
  }
  if (isString(pointer)) {
    return pointer.slice(draftPrefix.length);
  }
  throw new Error("Invalid rich text pointer");
}
function isDraftVectorSetItemPointer(pointer) {
  assert(isNumber(pointer), "Invalid vector set item pointer");
  return pointer < 0;
}
function draftVectorSetItemPointer(pointer) {
  assert(isNumber(pointer), "Invalid vector set item pointer");
  assert(!isDraftVectorSetItemPointer(pointer), "Should be a non-draft vector set item pointer");
  return -pointer - 1;
}
function undraftVectorSetItemPointer(pointer) {
  assert(isNumber(pointer), "Invalid vector set item pointer");
  assert(isDraftVectorSetItemPointer(pointer), "Should be a draft vector set item pointer");
  return -pointer - 1;
}
function draftItem(item) {
  const data = {};
  for (const [key, value] of Object.entries(item.data)) {
    if (value?.type === ControlType.RichText) {
      data[key] = {
        type: ControlType.RichText,
        value: draftRichTextPointer(value.value)
      };
    } else if (value?.type === ControlType.VectorSetItem) {
      data[key] = {
        type: ControlType.VectorSetItem,
        value: draftVectorSetItemPointer(value.value)
      };
    } else {
      data[key] = value;
    }
  }
  return {
    pointer: draftPointer(item.pointer),
    data
  };
}
function undraftItem(item) {
  const data = {};
  for (const [key, value] of Object.entries(item.data)) {
    if (value?.type === ControlType.RichText) {
      data[key] = {
        type: ControlType.RichText,
        value: undraftRichTextPointer(value.value)
      };
    } else if (value?.type === ControlType.VectorSetItem) {
      data[key] = {
        type: ControlType.VectorSetItem,
        value: undraftVectorSetItemPointer(value.value)
      };
    } else {
      data[key] = value;
    }
  }
  return {
    pointer: undraftPointer(item.pointer),
    data
  };
}
export {
  DraftDatabaseCollection
};
`;var $t=class o{constructor(t,e,n){this.chunkId=t;this.offset=e;this.length=n}static fromString(t){let[e,n,r]=t.split("/").map(Number);return j(B(e),"Invalid chunkId"),j(B(n),"Invalid offset"),j(B(r),"Invalid length"),new o(e,n,r)}toString(){return`${this.chunkId}/${this.offset}/${this.length}`}static read(t){let e=t.readUint16(),n=t.readUint32(),r=t.readUint32();return new o(e,n,r)}write(t){t.writeUint16(this.chunkId),t.writeUint32(this.offset),t.writeUint32(this.length)}compare(t){return this.chunkId<t.chunkId?-1:this.chunkId>t.chunkId?1:this.offset<t.offset?-1:this.offset>t.offset?1:(j(this.length===t.length),0)}};function So(o){if(nn(o))return 0;switch(o.type){case"array":return 1;case"boolean":return 2;case"color":return 3;case"date":return 4;case"enum":return 5;case"file":return 6;case"responsiveimage":return 10;case"link":return 7;case"number":return 8;case"object":return 9;case"richtext":return 11;case"string":return 12;case"vectorsetitem":return 13;default:fn(o)}}var ie;(n=>{function o(r){let i=r.readUint8();switch(i){case 0:return null;case 1:return Sc(r);case 2:return Cc(r);case 3:return Ic(r);case 4:return Nc(r);case 5:return Lc(r);case 6:return Ec(r);case 7:return Uc(r);case 8:return zc(r);case 9:return $c(r);case 10:return Gc(r);case 11:return Hc(r);case 12:return Xc(r);case 13:return ed(r);default:fn(i)}}n.read=o;function t(r,i){let s=So(i);if(r.writeUint8(s),!nn(i))switch(i.type){case"array":return vc(r,i);case"boolean":return Tc(r,i);case"color":return Rc(r,i);case"date":return Pc(r,i);case"enum":return Vc(r,i);case"file":return Mc(r,i);case"link":return Ac(r,i);case"number":return Oc(r,i);case"object":return jc(r,i);case"responsiveimage":return Jc(r,i);case"richtext":return Kc(r,i);case"vectorsetitem":return td(r,i);case"string":return Yc(r,i);default:fn(i)}}n.write=t;function e(r,i,s){let a=So(r),c=So(i);if(a<c)return-1;if(a>c)return 1;if(nn(r)||nn(i))return 0;switch(r.type){case"array":return j(i.type==="array"),bc(r,i,s);case"boolean":return j(i.type==="boolean"),wc(r,i);case"color":return j(i.type==="color"),Dc(r,i);case"date":return j(i.type==="date"),xc(r,i);case"enum":return j(i.type==="enum"),Fc(r,i);case"file":return j(i.type==="file"),kc(r,i);case"link":return j(i.type==="link"),Bc(r,i);case"number":return j(i.type==="number"),_c(r,i);case"object":return j(i.type==="object"),Wc(r,i,s);case"responsiveimage":return j(i.type==="responsiveimage"),qc(r,i);case"richtext":return j(i.type==="richtext"),Qc(r,i);case"vectorsetitem":return j(i.type==="vectorsetitem"),nd(r,i);case"string":return j(i.type==="string"),Zc(r,i,s);default:fn(r)}}n.compare=e})(ie||={});function Sc(o){let t=o.readUint16(),e=[];for(let n=0;n<t;n++){let r=ie.read(o);e.push(r)}return{type:"array",value:e}}function vc(o,t){o.writeUint16(t.value.length);for(let e of t.value)ie.write(o,e)}function bc(o,t,e){let n=o.value.length,r=t.value.length;if(n<r)return-1;if(n>r)return 1;for(let i=0;i<n;i++){let s=o.value[i],a=t.value[i],c=ie.compare(s,a,e);if(c!==0)return c}return 0}function Cc(o){return{type:"boolean",value:o.readUint8()!==0}}function Tc(o,t){o.writeUint8(t.value?1:0)}function wc(o,t){return o.value<t.value?-1:o.value>t.value?1:0}function Ic(o){return{type:"color",value:o.readString()}}function Rc(o,t){o.writeString(t.value)}function Dc(o,t){return o.value<t.value?-1:o.value>t.value?1:0}function Nc(o){let t=o.readInt64(),e=new Date(t);return{type:"date",value:e.toISOString()}}function Pc(o,t){let n=new Date(t.value).getTime();o.writeInt64(n)}function xc(o,t){let e=new Date(o.value),n=new Date(t.value);return e<n?-1:e>n?1:0}function Lc(o){return{type:"enum",value:o.readString()}}function Vc(o,t){o.writeString(t.value)}function Fc(o,t){return o.value<t.value?-1:o.value>t.value?1:0}function Ec(o){return{type:"file",value:o.readString()}}function Mc(o,t){o.writeString(t.value)}function kc(o,t){return o.value<t.value?-1:o.value>t.value?1:0}function Uc(o){return{type:"link",value:o.readJson()}}function Ac(o,t){o.writeJson(t.value)}function Bc(o,t){let e=JSON.stringify(o.value),n=JSON.stringify(t.value);return e<n?-1:e>n?1:0}function zc(o){return{type:"number",value:o.readFloat64()}}function Oc(o,t){o.writeFloat64(t.value)}function _c(o,t){return o.value<t.value?-1:o.value>t.value?1:0}function $c(o){let t=o.readUint16(),e={};for(let n=0;n<t;n++){let r=o.readString();e[r]=ie.read(o)}return{type:"object",value:e}}function jc(o,t){let e=Object.entries(t.value);o.writeUint16(e.length);for(let[n,r]of e)o.writeString(n),ie.write(o,r)}function Wc(o,t,e){let n=Object.keys(o.value).sort(),r=Object.keys(t.value).sort();if(n.length<r.length)return-1;if(n.length>r.length)return 1;for(let i=0;i<n.length;i++){let s=n[i],a=r[i];if(s<a)return-1;if(s>a)return 1;let c=o.value[s]??null,d=t.value[a]??null,p=ie.compare(c,d,e);if(p!==0)return p}return 0}function Gc(o){return{type:"responsiveimage",value:o.readJson()}}function Jc(o,t){o.writeJson(t.value)}function qc(o,t){let e=JSON.stringify(o.value),n=JSON.stringify(t.value);return e<n?-1:e>n?1:0}function Hc(o){let t=o.readInt8();if(t===0)return{type:"richtext",value:o.readUint32()};if(t===1)return{type:"richtext",value:o.readString()};throw new Error("Invalid rich text pointer")}function Kc(o,t){if(B(t.value)){o.writeInt8(0),o.writeUint32(t.value);return}if(K(t.value)){o.writeInt8(1),o.writeString(t.value);return}throw new Error("Invalid rich text pointer")}function Qc(o,t){let e=o.value,n=t.value;if(B(e)&&B(n)||K(e)&&K(n))return e<n?-1:e>n?1:0;throw new Error("Invalid rich text pointer")}function Xc(o){return{type:"string",value:o.readString()}}function Yc(o,t){o.writeString(t.value)}function Zc(o,t,e){let n=o.value,r=t.value;return e.type===0&&(n=o.value.toLowerCase(),r=t.value.toLowerCase()),n<r?-1:n>r?1:0}function ed(o){return{type:"vectorsetitem",value:o.readUint32()}}function td(o,t){o.writeUint32(t.value)}function nd(o,t){let e=o.value,n=t.value;return e<n?-1:e>n?1:0}var Oe=class o{constructor(t,e){this.fieldNames=t;this.options=e;g(this,"entries",[])}sortEntries(){this.entries.sort((t,e)=>{for(let n=0;n<this.fieldNames.length;n++){let r=t.values[n],i=e.values[n],s=ie.compare(r,i,this.options.collation);if(s!==0)return s}return t.pointer.compare(e.pointer)})}static deserialize(t){let e=new hr(t),n=e.readJson(),r=e.readUint8(),i=[];for(let c=0;c<r;c++){let d=e.readString();i.push(d)}let s=new o(i,{collation:n}),a=e.readUint32();for(let c=0;c<a;c++){let d=[];for(let l=0;l<r;l++){let f=ie.read(e);d.push(f)}let p=$t.read(e);s.entries.push({values:d,pointer:p})}return s}serialize(){let t=new Ct;t.writeJson(this.options.collation),t.writeUint8(this.fieldNames.length);for(let e of this.fieldNames)t.writeString(e);this.sortEntries(),t.writeUint32(this.entries.length);for(let e of this.entries){let{values:n,pointer:r}=e;for(let i of n)ie.write(t,i);r.write(t)}return t.subarray()}addItem(t,e){let n=this.fieldNames.map(r=>t.getField(r)??null);this.entries.push({values:n,pointer:e})}};var gr=class o{constructor(){g(this,"fields",new Map)}static read(t){let e=new o,n=t.readUint16();for(let r=0;r<n;r++){let i=t.readString(),s=ie.read(t);e.setField(i,s)}return e}write(t){t.writeUint16(this.fields.size);for(let[e,n]of this.fields)t.writeString(e),ie.write(t,n)}getData(){let t={};for(let[e,n]of this.fields)t[e]=n;return t}setField(t,e){this.fields.set(t,e)}getField(t){return this.fields.get(t)}};function vo(o){return u`${o}.replace("/modules/", "/cms/")`}var rd=N("serializeDatabase"),bo=4*1024*1024,od=5e3;async function ua(o,t,e,n,r,i,s,a,c,d,p,l,f){let y=new fr(o,t,e,s,r,d,p,a,c),h=o.getPropertyControls(e,t),m=Object.entries(h),v=yi(e,"includeDrafts"),C={[Je]:{type:St("string",s),isNullable:!1},[jr]:{type:St("date",s),isNullable:!0},[Wr]:{type:St("date",s),isNullable:!0},[rn]:{type:St("string",s),isNullable:!0},[on]:{type:St("string",s),isNullable:!0}};function I(A){return St(A,s)}for(let[A,we]of m){let Ve=Zs(we,I);Ve&&(C[A]=Ve)}let R=p.dedupe("schema",new $(C,0)),M=Qs(o.variables),P=o.getSlugVariable(),D=r.create(da),x,k,re=f?!0:void 0,ae=o.getSortedChildren().filter(A=>A.isDraft===re),lt=crypto.randomUUID();if(f){let A=Q("collection",o.id);if(x=u`${s.addImport(`../${A}`,{exportSpecifier:"default",importBinding:"originalCollection"})}.collectionByLocaleId`,ae.length===0){let Ve={id:lt,displayName:o.resolveValue("name")??"Unknown",collectionByLocaleId:x};return u`${Ve}`}let we=r.create(la);k=s.addImport(we.submoduleImport,{exportSpecifier:"DraftDatabaseCollection"})}let Xe=s.addImport(D.submoduleImport,{exportSpecifier:"DatabaseCollection"}),Ye={};for(let A of v){let Yt=function(){let L=new Ct;return L.writeUint32(0),L},It=function(L){let V=ge.subarray(0,L);_t(V).setUint32(0,Zt),ut.push(V)};var je=Yt,Xt=It;let we=[new Oe([Je],{collation:{type:1}}),new Oe([rn],{collation:{type:1}}),new Oe([on],{collation:{type:1}})];P&&we.push(new Oe([Je,P.id],{collation:{type:1}}),new Oe([P.id,Je],{collation:{type:1}}));for(let[L]of m)we.push(new Oe([L],{collation:{type:0}}));let Ve=new mr,wt=ae.filter(L=>{let V=ks(e,L);return V?V.includes(A.id):!0}),Sn=[];for(let L=0;L<wt.length;L++){let V=wt[L];S(V,"Node must exist");let J=new gr;J.setField(Je,{type:"string",value:V.id});let We=V.createdAt;We&&J.setField(jr,{type:"date",value:new Date(We).toISOString()});let Ie=V.updatedAt;Ie&&J.setField(Wr,{type:"date",value:new Date(Ie).toISOString()});let Nt=wt[L-1];Nt&&J.setField(rn,{type:"string",value:Nt.id});let Tn=wt[L+1];Tn&&J.setField(on,{type:"string",value:Tn.id});let pt={resolveColor(q){return l.addColor(q)},resolveFile(q){return a.resolve(q)?.src},resolveImage(q,ce){return a.resolveResponsiveImage(q,{focalPoint:ce})},resolveLink(q){let ce=c.create(q);if(!U(ce)&&!ni(ce))return ce},resolveRichTextPointer(q){return y.add(q)},resolveVectorSetItemPointer(q){return Ve.add(q)}};for(let[q,ce]of m){let wn=Xs(q,ce,M,h,V);if(U(wn))continue;let ko=Ys({control:ce,controlProp:wn,resolvers:pt,locale:A});U(ko)||J.setField(q,ko)}Sn.push(J)}let ut=[],Zt=0,ge=Yt();for(let L of Sn){let V=ge.getOffset();L.write(ge),ge.getOffset()>bo&&(It(V),ge=Yt(),V=ge.getOffset(),Zt=0,L.write(ge)),Zt++;let J=ge.getOffset()-V,We=new $t(ut.length,V,J);for(let Ie of we)Ie.addItem(L,We)}ge.getOffset()>0&&It();let Vr=s.addImport(D.submoduleImport,{exportSpecifier:"DatabaseDictionaryIndex"}),vn=ut.map((L,V)=>vo(i.create(`chunk-${A.id}-${V}`,mo,L)));ut.reduce((L,V)=>L+V.length,0)<od&&(we.length=0);let Rt=[],Dt=1/0;for(let L of we){let V=L.serialize();if(V.length>=bo){rd.warn("Skipping index:",V.length);continue}Dt+V.length>bo&&(Rt.push([]),Dt=0);let J=Rt.at(-1);S(J,"Chunk must exist"),J.push({model:L,bytes:V}),Dt+=V.length}let bn=[];for(let L=0;L<Rt.length;L++){let V=Rt[L];S(V,"Chunk must exist");let J=new Ct,We=[];for(let{bytes:pt}of V){let q=J.getOffset();J.writeBytes(pt);let ce=J.getOffset();We.push({from:q,to:ce})}let Ie=J.subarray(),Nt=vo(i.create(`indexes-${A.id}-${L}`,mo,Ie)),Tn=V.map(({model:pt},q)=>{if(pt instanceof Oe){let ce=We[q];S(ce,"Can't find range for index");let wn={url:Nt,range:ce,fieldNames:p.dedupe("fieldNames",pt.fieldNames),collation:p.dedupe("collation",pt.options.collation),collectionSchema:R};return u`new ${Vr}(${wn})`}throw new Error("Unsupported index type")});bn.push(...Tn)}let Fr=Ve.serialize(t,n,p),Cn={id:lt+A.id,schema:R,chunks:vn,indexes:bn,resolveRichText:y.resolveRichTextBinding,resolveVectorSetItem:Fr};if(x&&k){let L=u`new ${Xe}(${Cn})`,V=u`${x}[${A.id}]`;Ye[A.id]=u`new ${k}(${L}, ${V}, ${rn}, ${on})`}else Ye[A.id]=u`new ${Xe}(${Cn})`}y.serialize();let ne={id:lt,displayName:o.resolveValue("name")??"Unknown",collectionByLocaleId:Ye};return u`${ne}`}var fa=ee(async(o,t,e)=>Promise.all([pa(o.id,t,!1),pa(o.id,t,!0)]));async function pa(o,t,e){let{componentLoader:n,modulesStore:r,tree:i,assetMap:s}=t,a=e?"draftCollection":"collection",c=new Kn(s),d=new pr(o),p=new Ss(a,n,r,o),l=i.getNodeWithTrait(o,Z);S(l,"Must have a source node to serialize");let f=l.moduleSourceRevision,y=ss(l);await Jn(y,r,n);let{module:h}=is(n,r,l);Pe("collection_update",{moduleId:h?.id,recordCount:l.getItemCount(),source:"unknown"});let m=l.getSlugVariable()?.id,v=new gt,C=new Mt(a,n,r,v),I=new Mn(v),R=new zn(l,n,C,v,void 0,i,r),M=new En,P=await ua(l,n,i,r,p,d,C,c,R,v,I,M,e),D=tt("",{framerRecordIdKey:Je,framerSlug:m,framerEnumToDisplayNameUtils:"2",framerCollectionUtils:"1",framerCollectionId:l.id,framerColorSyntax:M.hasColorsOfType("wideGamut"),framerAutoSizeImages:!0,framerData:!0}),x=v.create("data"),k=ld(l,x,i,n,C,a),re=ad(C,I,x,Je,m),ae=u.joinLines(...C.statements,...I.list(),D,u`const ${x} = ${P}`,u`export default ${x}`,k,...sd(l.variables,i.root.locales),re);return{type:a,revision:f,source:ae,artifacts:{assets:new Set(c.keys),binaryAssets:d.assets,submodules:p.serialize(),metrics:{nodes:l.getItemCount()}}}}function sd(o,t){let e=[],n=new $;for(let r of o){if(r.type!=="enum")continue;let i=new w(Yi(r.id));e.push(u`export const ${i} = ${ia(r,t,i)};`),n[r.id]=i}return e.push(u`export const ${new w(_n)} = ${n};`),e}function ad(o,t,e,n,r){return u.joinLines(u`export const utils = {`,u`async getSlugByRecordId(id, locale) {`,r?cd(o,t,e,n,r):void 0,u`},`,u`async getRecordIdBySlug(slug, locale) {`,r?dd(o,t,e,n,r):void 0,u`},`,u`}`)}function ma(o,t){let e=o.addImport("framer",{exportSpecifier:"QueryEngine"});return t.dedupe("queryEngine",u`new ${e}()`)}function cd(o,t,e,n,r){let i=ma(o,t),s={from:{type:"Collection",data:e},select:[{type:"Identifier",name:r}],where:{type:"BinaryOperation",operator:"==",left:{type:"Identifier",name:n},right:{type:"LiteralValue",value:u`id`}},limit:{type:"LiteralValue",value:1}};return u.joinLines(u`const [item] = await ${i}.query(${s}, locale)`,u`return item?.[${r}]`)}function dd(o,t,e,n,r){let i=ma(o,t),s={from:{type:"Collection",data:e},select:[{type:"Identifier",name:n}],where:{type:"BinaryOperation",operator:"==",left:{type:"Identifier",name:r},right:{type:"LiteralValue",value:u`slug`}},limit:{type:"LiteralValue",value:1}};return u.joinLines(u`const [item] = await ${i}.query(${s}, locale)`,u`return item?.[${n}]`)}function ld(o,t,e,n,r,i){let s=Ks(o,n,e,r,void 0,i,"ContentManagement");if(U(s))return;let a=r.addImport("framer",{exportSpecifier:"addPropertyControls"});return w.fn(a,t,s)}function yr({componentName:o,fontObjects:t,fontReferences:e,imports:n,declarations:r,sharedFontArrays:i=[]}){return u.joinLines(...r.list(),w.fn(n.addImport("framer",{exportSpecifier:"addFonts"}),o,mn({fontObjects:t,fontReferences:e,sharedFontArrays:i}),{supportsExplicitInterCodegen:!0}))}function mn({fontObjects:o,fontReferences:t,sharedFontArrays:e=[]}){let n=[],r={explicitInter:!0,fonts:[]};for(let i of o){try{new URL(i.url)}catch(s){throw new Error(`Expected URL for font "${i.uiFamilyName}" to be a valid, absolute URL, but got: ${i.url}`,{cause:s})}r.fonts.push(i)}n.push(r);for(let i of t.values())n.push(u`...${i}`);for(let i of e)n.push(u`...${i}`);return n}var ha=ee(async(o,{componentLoader:t,assetMap:e,tree:n,modulesStore:r})=>{let i=new gt,s=new Kn(e),a=new Mt("componentPresets",t,r,i),c=new zn(o,t,a,i,void 0,n,r),d=new Mn(i),p=new Ui(o,i),l=new fs(o,n,p,d,i,a,s),f=new ys(i,p,l,s,c),y=o.moduleSourceRevision,h={},m={},v=o.getComponentPresets();await Jn(v.map(R=>R.componentIdentifier),r,t);let C=new gt,I=new kn(C);for(let R of v){let M=t.reactComponentForIdentifier(R.componentIdentifier);S(M,"Can't find react component for preset");let P=R.getFontsForCodeGeneration(t);await _o.loadFonts(P);let D=new Qn(I),x=hi($i(M,"onlyPresets"),R.getRawControlProps()),k=ps(R,M.properties,x,{context:{assets:s,imports:a,links:c,fonts:D,fetches:f}});h[R.id]=new $(k),(D.fontObjects.size>0||D.fontReferences.size>0)&&(m[R.id]=mn({fontObjects:D.fontObjects,fontReferences:D.fontReferences}))}return[{revision:y,type:"componentPresets",source:u.joinLines(...a.statements,u`export const props = ${h}`,...I.list(),u`export const fonts = ${m}`),artifacts:{assets:s.keys,metrics:{nodes:Object.keys(h).length}}}]});var ud=N("CodeGenerationStore");function ga(o,t,e){return e.add(o),t[o]?.forEach(n=>{e.has(n)||ga(n,t,e)}),e}function pd(o,t){let e={};for(let{fromNode:n,toNode:r}of t){let i=e[n]??new Set;i.add(r),e[n]=i}return ga(o,e,new Set([o]))}var ya=ee(async(o,{componentLoader:t,tree:e,treeStore:n,modulesStore:r})=>{let i=n.treeIndex,s=z(`Prototype/${o.name||"Generated Prototype"}`),a=e.get(o.homeNodeId);S(a,"Can't serialize",s,": home node must exist.");let c=e.getRect(a),d=new Mt("prototype",t,r);d.addImport("react",{exportSpecifier:"*",importBinding:"React"}),d.addImport("framer-motion",{exportSpecifier:"LayoutGroup"}),d.addImport("framer",{exportSpecifier:"PageRoot"}),d.addImport("framer",{exportSpecifier:"useInitialRouteComponent"});let p={};for(let m of pd(a.id,i.getPrototypeScreenLinks(e,o.id))){let C=`../${Q("screen",m)}`;try{await os(t,[Fe("screen",m,"default").value],r);let I=d.addImport(C,{exportSpecifier:"default",importBinding:"Screen",lazy:m!==o.homeNodeId});p[m]={page:I,path:m}}catch{ud.error("Missing module for prototype screen",{screenId:m})}}let l=z(o.homeNodeId),f=z(p),y=u`${d.addImport("react",{exportSpecifier:"*",importBinding:"React"})}.useId`,h=new w(E.sections(E.linesFrom(d.statements),`const routes = ${f}`,E.lines("function Prototype({ layoutId }: { layoutId?: string }): JSX.Element {",`  const InitialRouteComponent = useInitialRouteComponent(routes, "${o.homeNodeId}")`,`  const defaultLayoutId = ${w.fn(y)};`,"  if (!InitialRouteComponent) return null","  return (","    <LayoutGroup id={layoutId ?? defaultLayoutId} inherit={false}>",`      <PageRoot RootComponent={InitialRouteComponent} isWebsite={false} routeId={${l}} routes={routes} />`,"    </LayoutGroup>","  )","}"),E.lines(tt("This is a generated Framer component.",{framerIntrinsicHeight:c?.height,framerIntrinsicWidth:c?.width,framerSupportedLayoutWidth:"fixed",framerSupportedLayoutHeight:"fixed",framerPrototype:!0}),"const Component: React.ComponentType<{}> = React.memo(Prototype)","export default Component;"),`Component.displayName = ${s};`));return[{type:"prototype",source:h,revision:void 0}]});async function Sr(o,t,e,n,r,i){return mi(t)&&t.usesDOMRectCached()&&!t.getDOMRect()&&(await fd(t,n,e,r),!t.cache.getRawDOMRect(t.id)&&i)?Nn.atOrigin(i):o.getRect(t)}async function fd(o,t,e,n){if(t){let s=(await t([o.id]))?.[0];if(s){let{layoutMetrics:a}=s,c=Nn.from(a);o.cache.setRawDOMRect(o.id,c);return}}if(!e)return;let r=md(e,n);if(r){let i=Nn.atOrigin(r);o.cache.setRawDOMRect(o.id,i)}}function md(o,t){if(!tn(o))return;let e=t.getPersistedModuleByLocalIdentifier(o);if(!e)return;let{intrinsicWidth:n,intrinsicHeight:r}=e.metadata;if(B(n)&&B(r))return{width:n,height:r}}var me={Screen:u`Screen`,activeVariantCallback:b.activeVariantCallback,css:b.css,delay:b.delay,ref:b.ref,serializationHash:b.serializationHash,sharedStyleClassNames:b.sharedStyleClassNames,restProps:b.restProps,refBinding:b.refBinding},hd=new Set(Object.values(me).map(o=>z(o))),Sa=ee(async(o,t,{serializationId:e,initialIntrinsicSize:n})=>{let{modulesStore:r,tree:i}=t,s=i.getScopeNodeFor(o);if(!ue(s))return[];let a=i.get(o.id);S(a,"Must have a source node to serialize. This should be a primary variant."),S(ue(s),"Must have a scope node to serialize. This should be a CanvasPage Node.");let c=`FramerScreen${et(o.id)}`,d=Fe("screen",o.id,"default").value,{jsx:p,ctx:l}=await Xn(a,s,t,new Set(hd).add(c),e);S(p,"There must be JSX to serialize.");let f=l.imports,y=await Sr(i,a,d,t.measureNodes,r,n),h=l.events.navigationTargets.size>0,m=l.events.handlers.size>0,v=l.events.variantOnAppearId.get(o.id),C=l.events.keyBindHooks.size>0,I=[];for(let ne of l.events.navigationTargets)ne!==hs&&I.push(ne);let R=l.fonts.fontObjects,M=new Map(l.fonts.fontReferences),P=[],D=new Set(l.css.sharedStyleIds),x=[];for(let ne of D){let je=Q("css",ne),Xt=f.addImport(`../${je}`,{exportSpecifier:"*",importBinding:"sharedStyle"});x.push(Xt),P.push(w.fn(f.addImport("framer",{exportSpecifier:"getFontsFromSharedStyle"}),u`${Xt}.fonts`))}let k;for(let ne of l.componentPresetIds){k??=f.addImport(`../${Hn}`,{exportSpecifier:"*",importBinding:"componentPresets"});let je=u`${k}.fonts?.[${ne}]`;P.push(u`(${je} ? ${w.fn(l.imports.addImport("framer",{exportSpecifier:"getFontsFromComponentPreset"}),je)} : [])`)}let re=new Map;kt(l.css.get(),re);let ae=new w(c),lt=f.addImport("react",{exportSpecifier:"useRef"}),Xe=s.resolveValue("name"),Ye=E.lines(h&&`const preload = ${z(I)};`,...l.variables.fallbackDeclarations(),...l.declarations.file.list(),u`const ${me.serializationHash} = ${e}`,u`const ${me.Screen} = ${gd({props:u`style, className`},u`const fallbackRef = ${w.fn(u`${lt}<HTMLElement>`,u`null`)}`,u`const ${me.refBinding} = ${me.ref} ?? fallbackRef`,h?u`const navigate = ${w.fn(f.addImport("framer",{exportSpecifier:"usePrototypeNavigate"}),{preload:u`preload`})}`:void 0,m&&u`const { ${me.activeVariantCallback}, ${me.delay} } = ${w.fn(f.addImport("framer",{exportSpecifier:"useActiveVariantCallback"}))}`,...l.events.handlers.values(),u`const ${me.sharedStyleClassNames} = ${x.map(ne=>u`${ne}.className`)}`,...l.declarations.component.list(),C&&E.linesFrom(l.events.keyBindHooks),v&&w.fn(f.addImport("framer",{exportSpecifier:"useOnAppear"}),v),u`return ${p}`)}`,u`const ${me.css} = ${[...l.css.conditionalRules(e),An,...Ut(re),...x.map(ne=>u`...${ne}.css`)]}`,Bn(ae,e,me.Screen,me.css,{framerIntrinsicHeight:y.height,framerIntrinsicWidth:y.width,framerSupportedLayoutWidth:"fixed",framerSupportedLayoutHeight:"fixed",framerScreen:void 0,framerDisplayContentsDiv:!1},f),u`${ae}.displayName = ${`Screens/${Xe?Xe.trim():"Generated Component"}`};`,u`${ae}.defaultProps = ${{width:y.width,height:y.height}};`,yr({componentName:ae,fontObjects:R,fontReferences:M,imports:f,declarations:l.declarations.font,sharedFontArrays:P}));return[{type:"screen",revision:void 0,source:new w(E.sections(E.linesFrom(f.statements),Ye)),artifacts:{assets:l.assets.keys,packageDependencies:l.packages.dependencies,metrics:l.metrics.get()}}]});function gd({props:o},...t){return new w(E.lines(u`React.forwardRef(function({ ${o}, ...${me.restProps} }, ${me.ref}) {`,...t,u`});`))}var ba="{serializationId}";function va(o){return`.${ba} ${o}`}var Ca=ee(async(o,{componentLoader:t,tree:e},{serializationId:n})=>{let r=new gt,i=new kn(r),s=new Qn(i),a=o.getFontsForCodeGeneration(),c=o.moduleSourceRevision,d=ti(o);for(let I of a)s.addFontObjectBySelector(I,d);let p=[],l=new En,f={componentLoader:t,colors:l};for(let{selectors:I,declarations:R}of o.getCSS(f)){let M=I.map(va);p.push(`${M.join(", ")} { ${R} }`)}let y=e.getNodesWithTrait(o.cache.replicaInstances??[],Wi).filter(Ni).sort((I,R)=>(R.breakpointWidth??0)-(I.breakpointWidth??0));for(let I=0;I<y.length;I++){let R=y[I];if(U(R))continue;let M=y[I+1],P=R.breakpointWidth-1,D=M?.breakpointWidth??0;for(let{selectors:x,declarations:k}of R.getCSS(f)){let ae=`${x.map(va).join(", ")} { ${k} }`;p.push(`@media (max-width: ${P}px) and (min-width: ${D}px) { ${ae} }`)}}let h=l.getWideGamutColorRules(`.${n}`);h.length&&p.push(`@supports (color: color(display-p3 1 1 1)) { ${h.join(" ")} }`);let m=p.map(I=>I.replaceAll(ba,n)),v=mn({fontObjects:s.fontObjects,fontReferences:s.fontReferences}),C=u.joinLines(u`import { fontStore } from "framer";`,u`fontStore.loadFonts(${a});`,...i.list(),u`export const fonts = ${v};`,u`export const css = ${m};`,u`export const className = ${n};`);return[{revision:c,type:"css",source:C,artifacts:{metrics:{nodes:p.length}}}]});function To(o){if(Ko(o))return{widthType:o.widthType,heightType:o.heightType,...wi(o)?{minHeight:o.minHeight,maxHeight:o.maxHeight,minWidth:o.minWidth,maxWidth:o.maxWidth}:Ti}}function wo(o,t){if(oi(t))return{min:o.getRect(t).width}}var yd=new Set(Object.values(b).map(o=>z(o)));function Sd(o,t){if(Fn(o)){let e=t.get(o.parentid);return!le(e)||!e.isLoaded()?null:e}return t.current(o)}var Io=ee(async(o,t,{serializationId:e,initialIntrinsicSize:n})=>{let{modulesStore:r,tree:i,aiGenerationStore:s,measureNodes:a}=t,c=be(o,i)?o.moduleSourceRevision:void 0,d=Sd(o,i);S(d?.isLoaded(),"The scope node must be valid.");let p=bs(d),l=Ge(d)?d.baseVariantId:o.id,f=i.get(l);S(f,"Must have a source node to serialize. This should be a primary variant.");let y=`Framer${o.id}`,h=new w(y),{jsx:m,ctx:v}=await Xn(f,d,t,new Set(yd).add(y),e);S(m,"There must be JSX to serialize.");let C=v.imports,I=le(d),R=I?void 0:d.instanceIdentifier,M=await Sr(i,f,R,a,r,n),P=Ge(d)?d.getReplicaVariants():[],{variants:D,hook:x}=v.preload.getHook(),{gestures:k,breakpoints:re,classNames:ae,sizes:lt,appearEventMap:Xe}=Md(f,P,v,D),Ye=Ne(d)?[d.baseVariantId,...d.getTopLevelReplicaVariants().map(tr)]:[],ne=Ye.length>1,je=!en(k),Xt=!en(Xe),A=!en(re),we=u`${C.addImport("react",{exportSpecifier:"*",importBinding:"React"})}.useId`,{mediaQueries:Ve,sharedStyleImports:wt,sharedFontArrays:Sn,css:Yt}=Ld(e,v,P,re,d),ut=Ed(d,v.componentLoader,v.declarations),Zt=Me.applyTransforms(m,kd(d,v,xd(d,f,P,Ve,i,v),A?b.baseVariant:void 0,ut)),ge=Td(d,t,C,v.preload,v.variables),It=Ft.isOn("autobahnNavigation")?v.preload.getRouteLoaderCode():void 0,Vr=F(d)?io(d,ge?.controlMap):new Set,vn={};for(let Ie of Vr){let Nt=kr(Ie,d.id);vn[Ie]=v.variables.create(Nt)}let{props:Mo,types:Rt,propertyControls:Dt,variableMap:bn}=ar(d,v,ms(d),p,ut),Fr=!A&&u`const ${b.layoutDependency} = ${w.fn(v.declarations.file.dedupe("createLayoutDependency",u`(props, variants) => {${u.joinLines(u`if (props.layoutDependency) return variants.join('-') + props.layoutDependency`,u`return variants.join('-')`)}}`),b.props,b.variants)}`,{cursors:Cn}=v.customCursors,L=C.addImport("react",{exportSpecifier:"useRef"}),V=Pd(d),J=E.sections(je&&u`const ${b.enabledGestures} = ${k};`,ne&&`const ${b.cycleOrder} = ${z(Ye)};`,A&&`const ${b.breakpoints} = ${z(Ve)}`,A&&`const ${b.isBrowser} = () => typeof document !== "undefined";`,I&&u`const ${b.variant} = undefined;`,I&&u`const ${b.breakpoints} = undefined;`,I&&u`const ${b.layoutId} = undefined;`,I&&u`const ${b.className} = undefined;`,I&&u`const ${b.style} = undefined;`,F(d)&&u`export const ${b.queryParamNames} = ${V}`,u`const ${b.serializationHash} = ${e}`,`const ${b.variantClassNames} = ${z(ae)};`,!A&&wd,u.linesFrom(v.variables.fallbackDeclarations()),...v.declarations.file.list(),`export interface Props extends React.HTMLAttributes<HTMLDivElement> { ${Rt} }`,`const ${b.Component} = ${bd(u`const fallbackRef = ${w.fn(u`${L}<HTMLElement>`,u`null`)}`,u`const ${b.refBinding} = ${b.ref} ?? fallbackRef`,u`const ${b.defaultLayoutId} = ${w.fn(we)}`,`const { ${b.activeLocale}, ${b.setLocale} } = ${w.fn(C.addImport("framer",{exportSpecifier:"useLocaleInfo"}))}`,v.variables.shouldProvideLayoutDirection?u`const ${b.layoutDirection} = ${w.fn(C.addImport("framer",{exportSpecifier:"useLayoutDirection"}))}`:void 0,Ne(d)||F(d)?u`const ${b.componentViewport} = ${w.fn(v.imports.addImport("framer",{exportSpecifier:"useComponentViewport"}))}`:void 0,Dd({data:ge,imports:C,preload:v.preload}),F(d)&&Nd(i,t.componentLoader,d,C,v.variables),Mo,F(d)&&Id({webPageNodeId:o.id,metadataDependencies:vn,imports:C,bindings:v.bindings}),A?u.joinLines(u`const [${b.baseVariant}, ${b.hydratedBaseVariant}] = ${w.fn(C.addImport("framer",{exportSpecifier:"useHydratedBreakpointVariants"}),b.variant,b.breakpoints,u`false`)};`,u`const ${b.gestureVariant} = undefined;`):vd(f.id,je,ne,C),Fr,Fd(v),...v.events.routeHandlers.values(),v.events.handlers.size>0&&u`const { ${b.activeVariantCallback}, ${b.delay} } = ${w.fn(C.addImport("framer",{exportSpecifier:"useActiveVariantCallback"}),A?u`undefined`:b.baseVariant)}`,...v.events.handlers.values(),Xt&&w.fn(C.addImport("framer",{exportSpecifier:"useOnVariantChange"}),A?b.hydratedBaseVariant:b.baseVariant,Xe),u`const ${b.sharedStyleClassNames} = ${wt.map(Ie=>u`${Ie}.className`)}`,...v.declarations.component.list(),Cn,x?.(je?b.enabledGestures:u`undefined`),u`return (${Zt})`)}`,Yt,Bn(h,e,b.Component,b.css,Cd(d,v,M,lt,bn),C),`${y}.displayName = ${z(d.resolveValue("name")?.trim()||"Generated Component")};`,`${y}.defaultProps = ${z({width:M.width,height:M.height})};`,Dt&&w.fn(C.addImport("framer",{exportSpecifier:"addPropertyControls"}),h,new w(`${z(Dt)} as any`)),yr({componentName:h,fontObjects:v.fonts.fontObjects,fontReferences:v.fonts.fontReferences,imports:C,declarations:v.declarations.font,sharedFontArrays:Sn}),It&&u`${h}.loader = ${It}`),[We]=F(d)?await Es(d,t,{serializationId:e}):[];return er([{type:p,revision:c,source:new w(E.sections(E.linesFrom(C.statements),J)),artifacts:{packageDependencies:v.packages.dependencies,errors:v.errors.errors,assets:v.assets.keys,metrics:v.metrics.get(),kitSectionsStructure:s.cacheKitSectionsStructure(o.id,v.kitSectionsStructure.structure)}},We,v.localizedValues.module(c)])});function vd(o,t,e,n){let r=$.fromEntries([[b.defaultVariant,o],[b.variant,b.variant],[b.variantClassNames,b.variantClassNames],[b.enabledGestures,t?b.enabledGestures:void 0],[b.cycleOrder,e?b.cycleOrder:void 0],[b.ref,b.refBinding]]),i=w.fn(n.addImport("framer",{exportSpecifier:"useVariantState"}),r),s=b.variants,a=b.baseVariant,c=u`setVariant`,d=b.gestureVariant,p=b.classNames,l=b.setGestureState,f=b.gestureHandlers,y=b.clearLoadingGesture,h=b.isLoading;return E.lines(u`const ${{variants:s,baseVariant:a,setVariant:c,gestureVariant:d,classNames:p,setGestureState:l,gestureHandlers:f,clearLoadingGesture:y,isLoading:h}} = ${i}`)}function bd(...o){return E.sections(u`React.forwardRef<HTMLDivElement, Props>(function(${b.props}, ${b.ref}) {`,...o,u`});`)}function Cd(o,t,e,n,r){let{height:i,width:s}=e,a={propertyName:"variant",data:Object.fromEntries(Object.entries(n).map(([d,p])=>[d,Li(p)]))},c={framerIntrinsicHeight:i,framerIntrinsicWidth:s,framerRootFontSize:fi(o)?o.getPrimaryVariant()?.rootFontSize:void 0,framerCanvasComponentVariantDetails:JSON.stringify(a),framerVariables:r&&JSON.stringify(r),framerImmutableVariables:!0,framerDisplayContentsDiv:!1,framerAutoSizeImages:!0,framerComponentViewportWidth:!0,framerColorSyntax:!0,framerVectorSets:t.vectorSets.annotation()};if(oe(o)){let d={},p=o.getBreakpointValues();for(let l in p){let f=t.tree.get(l);d[l]={...p[l],canvasClassName:Ra(l),minHeight:f?.height,viewportHeight:f?.viewportHeight,name:f?.resolveValue("name")??void 0,width:f?.widthType===0?f?.width:void 0,rootFontSize:f?.rootFontSize??Yo}}c.framerHitTargets=t.hitTargets.annotation(),c.framerBreakpoints=JSON.stringify(d),c.framerDefaultVariant=o.baseVariantId,c.framerTrackingIds=t.trackingIds.annotation(),c.framerLayoutTemplate=!0}else F(o)?(c.framerAcceptsLayoutTemplate=t.acceptsLayoutTemplate,c.framerTrackingIds=t.trackingIds.annotation(),c.framerScrollSections=t.elementIds.annotation()??!1,c.framerResponsiveScreen=!0,c.framerLayoutTemplateFlowEffect=!0):Ne(o)?c.framerTrackingIds=t.trackingIds.annotation():le(o)?c.framerDesign=!0:Ne(o)||(c.framerScreen=!0);return c}function Td(o,t,e,n,r){if(!F(o)||!Ln(o)||!Bi(t.tree,o))return;let s=o.getProvidedControlMap(t.tree,void 0,t.componentLoader,t.componentLoader.activeBundleHash)??new Map,a=Cs(o),c={defaultCollectionAlias:a,identifier:o.dataIdentifier,controlMap:s},d=io(o,s);for(let v of d){let C=kr(v,o.id);r.create(C)}let p=r.getBindings(o.id),l=new Set;for(let[v]of s)p.has(v)&&l.add(v);function f(v){let C=e.addModuleImport(v);return S(C,"Can't import collection"),C}let y=new Set,h=ws(s,l,y,a,f),m=Ts(o.dataIdentifier,s,y,a,f);return n.addDetailPageQuery(m,h,a),c}var wd=E.lines("function addPropertyOverrides(overrides, ...variants) {","const nextOverrides = {}","variants?.forEach(variant => variant && Object.assign(nextOverrides, overrides[variant]))","return nextOverrides","}");function Id({webPageNodeId:o,metadataDependencies:t,imports:e,bindings:n}){let r=e.addImport(`../${Vs(o).localId}`,{exportSpecifier:"default",importBinding:"metadataProvider"}),i=n.create("metadata"),s=e.addImport("framer",{exportSpecifier:"useMetadata"}),a=w.fn(r,t,b.activeLocale),c=Object.values(t).concat(b.activeLocale);return E.lines(u`const ${i} = React.useMemo(() => ${a}, ${c})`,w.fn(s,i))}function Rd(o){if(ri(o))return{type:o.gesture,topLevel:o.replicaInfo.inheritsFrom}}function Dd({data:o,imports:t,preload:e}){if(!o)return;let n=t.addImport("framer",{exportSpecifier:"useCurrentPathVariables"}),r=t.addImport("framer",{exportSpecifier:"NotFoundError"}),i=t.addImport("framer",{exportSpecifier:"useQueryData"}),s=t.addImport("framer",{exportSpecifier:"getWhereExpressionFromPathVariables"}),a=e.getDetailPageQueryConstant();S(a,"Detail page query constant should be registered before createDataRecordBinding");let c=w.fn(s,b.currentPathVariables,o.defaultCollectionAlias),d=u`const [${b.currentRouteData}] = ${w.fn(i,u`${a}(${c})`)};`;return u.joinLines(u`const ${b.currentPathVariables} = ${w.fn(n)};`,d,u`const ${b.getFromCurrentRouteData} = (key) => {
            if (!${b.currentRouteData}) throw new ${r}(\`No data matches path variables: \${JSON.stringify(${b.currentPathVariables})}\`);
            return ${b.currentRouteData}[key];
        };`)}function Nd(o,t,e,n,r){let i=e.variables.filter(Or);if(i.length===0)return;let s=r.getBindings(e.id),a=[];for(let c of i){if(!zr(c))continue;let d=eo(c),p;switch(c.type){case"boolean":{let h=n.addImport("framer",{exportSpecifier:"useBooleanQueryParam"}),m=new $({initialValue:c.optional?void 0:c.initialValue,parameterName:d,optional:c.optional?!0:void 0});p=w.fn(h,m);break}case"string":{let h=n.addImport("framer",{exportSpecifier:"useStringQueryParam"}),m=new $({initialValue:c.optional?void 0:c.initialValue,parameterName:d,optional:c.optional===!0?!0:void 0});p=w.fn(h,m);break}case"number":{let h=n.addImport("framer",{exportSpecifier:"useNumberQueryParam"}),m=new $({initialValue:c.optional?void 0:c.initialValue,parameterName:d,optional:c.optional===!0?!0:void 0});p=w.fn(h,m);break}case"date":{let h=n.addImport("framer",{exportSpecifier:"useDateQueryParam"}),m=new $({initialValue:c.optional?void 0:c.initialValue,parameterName:d,displayTime:c.options?.displayTime===!0?!0:void 0,optional:c.optional===!0?!0:void 0});p=w.fn(h,m);break}case"collectionreference":{let h=n.addImport("framer",{exportSpecifier:"useCollectionReferenceQueryParam"}),m=new $({collectionId:_r(c.dataIdentifier),initialValue:c.optional?void 0:c.initialValue,parameterName:d,optional:c.optional===!0?!0:void 0});p=w.fn(h,m);break}case"multicollectionreference":{let h=n.addImport("framer",{exportSpecifier:"useMultiCollectionReferenceQueryParam"}),m=new $({collectionId:_r(c.dataIdentifier),initialValue:c.optional?void 0:c.initialValue,parameterName:d,optional:c.optional===!0?!0:void 0});p=w.fn(h,m);break}case"controlReference":{if(c.expectedType!=="enum")continue;let h=ui(o,t,c);if(!h||h.type!=="enum")continue;let m=n.addImport("framer",{exportSpecifier:"useEnumQueryParam"}),v=c.entityIdentifier,C=Re(v);if(!Lt(C))continue;let I=c.controlKey,M=t.dataForIdentifier(v)?.annotations?.framerEnumToDisplayNameUtils;S(K(M)&&Number.parseInt(M,10)===2,"Unexpected FramerEnumToDisplayNameUtils version");let P=n.addModuleImport(C,{exportSpecifier:_n});if(!P)continue;let D=n.addModuleImport(C,{importBinding:`${si(I)}CollectionData`});if(!D)continue;let x=K(c.initialValue)?c.initialValue:ci("enum"),k;c.optional===!0||!x?k=new $({getOptionTitle:u`${P}?.[${I}]`,initialValue:void 0,optional:!0,options:u`${D}.propertyControls?.[${I}]?.options`,parameterName:d}):k=new $({getOptionTitle:u`${P}?.[${I}]`,initialValue:x,options:u`${D}.propertyControls?.[${I}]?.options`,parameterName:d}),p=w.fn(m,k);break}default:Se(c)}let l=s.get(c.id);if(!l)continue;let f=r.getSetterBinding(c.id),y=[l];f&&y.push(f),a.push(u`const ${y} = ${p};`)}return u.joinLines(...a)}function Pd(o){return F(o)?o.variables.flatMap(t=>Or(t)?zr(t)?[eo(t)]:[]:[]):[]}function Ra(o){return`framer-${et(o)}-override`}function Ta(o,t){if(!(!Si(o)||vi(o)&&!o.fillEnabled))return o.fillType==="color"&&jo(o.fillColor)?t(o.fillColor,o,"fill"):Pi(o)}function wa(o){if(!Zo(o))return;let t=o.rootFontSize/16*100;return ei(t,"%")}function Ia(o,t){return K(o)?o:w.fn(t.imports.addImport("framer",{exportSpecifier:"safeCSSValue"}),o)}function xd(o,t,e,n,r,i){if(!oe(o)&&!F(o))return;let s=vs(r,i.declarations,i.variables,i.valueTransforms),a=oe(o)?":root":"html",c=`${a} body`,d=wa(t),p=Ta(t,s)??"none",l=[Ee`${c} { background: ${Ia(p,i)}; }`];K(d)&&l.push(`${a} { font-size: ${d}; }`);for(let f of e){let y=n[f.id];if(y){let h=Ta(f,s)??"none",m=wa(f),v=[];if(Zr(p,h)||v.push(Ee`${c} { background: ${Ia(h,i)}; }`),Zr(d,m)||v.push(`${a} { font-size: ${m}; }`),v.length===0)continue;l.push(Ee`@media ${y} { ${Ee.join(v," ")} }`)}}return Ee.join(l," ")}function Ld(o,t,e,n,r){let i=Hi(qi(n)),s=[],a=new Map;if(oe(r)){let m=r.getPrimaryVariant(),v={marginBottom:Hr(m,t)};t.css.createRule(`[${Yr}="true"] > #overlay`,Gr(v));for(let C of e){let I={marginBottom:Hr(C,t)},R=ds(I,v);!R||en(R)||t.css.createRule(`[${Yr}="true"] > #overlay`,Gr(R),C.id)}}kt(t.css.get(),a);let c={},d={};for(let m of e){let v=i[m.id];if(v){let C=new Map;if(kt(t.css.get(m.id),C),!C.size)continue;oe(r)?(c[m.id]=Ut(C),d[m.id]=`.${Ra(m.id)}`):s.push(Ee`@media ${v} { ${Ee.join(Ut(C)," ")}}`)}else kt(t.css.get(m.id),a)}let p=[],l=[];for(let m of t.css.sharedStyleIds){let v=Q("css",m),C=t.imports.addImport(`../${v}`,{exportSpecifier:"*",importBinding:"sharedStyle"});l.push(C),p.push(w.fn(t.imports.addImport("framer",{exportSpecifier:"getFontsFromSharedStyle"}),u`${C}.fonts`))}let f;for(let m of t.componentPresetIds){f??=t.imports.addImport(`../${Hn}`,{exportSpecifier:"*",importBinding:"componentPresets"});let v=u`${f}.fonts?.[${m}]`;p.push(u`(${v} ? ${w.fn(t.imports.addImport("framer",{exportSpecifier:"getFontsFromComponentPreset"}),v)} : [])`)}let y=[An,...Ut(a),...l.map(m=>u`...${m}.css`),...t.css.conditionalRules(o)],h=Vd(r,t,y,s,c,d,i);return{sharedStyleImports:l,sharedFontArrays:p,mediaQueries:i,css:u`const ${b.css} = ${h}`}}function Vd(o,t,e,n,r,i,s){if(Ne(o)||le(o))return e;if(F(o))return[...e,...n];if(oe(o)){let a=t.declarations.file.dedupe("breakpointRules",r),c=t.declarations.file.dedupe("breakpointKeys",u`Object.keys(${a})`),d=t.declarations.file.dedupe("selectors",i),p=t.declarations.file.dedupe("rules",e),l=t.declarations.file.dedupe("mediaQueries",s),f=t.bindings.create("target"),y=t.bindings.create("query"),h=t.bindings.create("selector"),m=t.bindings.create("rule"),v=t.imports.addImport("framer",{exportSpecifier:"RenderTarget"});return u`(target) => {${u.joinLines(u`const isStaticRenderer = ${f} === ${v}.canvas || ${f} === ${v}.export`,u`if (!isStaticRenderer) {${u.joinLines(u`return [...${p}, ...${c}.map(key => {${u.joinLines(u`const ${y} = ${l}[key]`,u`return ${Ee`@media ${y} { ${u`${a}[key].join(" ")`} }`}`)}})]`)}}`,u`return [...${p}, ...${c}.flatMap(key => {${u.joinLines(u`const ${h} = ${d}[key]`,u`return ${a}[key].map(${m} => ${Ee`${h} {${m}}`})`)}})]`)}}`}Se(o)}function Fd(o){if(o.events.needsPathVariables)return`const ${gs} = React.useContext(${o.imports.addImport("framer",{exportSpecifier:"PathVariablesContext"})});`}function Ed(o,t,e){let n=Ge(o)?o.getTopLevelVariants():[];if(n.length<2)return;let r=new $;for(let i of n){let s=i.resolveValue("name")??On(t,i);r[s]=i.id}return e.file.dedupe("humanReadableVariantMap",r)}function Md(o,t,e,n){let r=To(o);S(r,"The primary variant should have a default size as it must be a FrameNode.");let i={default:r},s={[o.id]:`framer-v-${et(o.id)}`},a={},c={},d={},p=wo(e.tree,o);p&&(d[o.id]=p);let l=e.events.variantOnAppearId.get(o.id),f={};!U(l)&&!w.isUndefined(l)&&(f.default=l);for(let y of t){e.metrics.count("variants");let h=Rd(y);if(h){let R=a[h.topLevel]??{};R[h.type]=h.type==="loading"?n?.has(h.topLevel):!0,a[h.topLevel]=R,c[h.topLevel]=[...c[h.topLevel]??[],y.id]}else s[y.id]=`framer-v-${et(y.id)}`;let m=To(y);m&&(i[y.id]=m);let v=wo(e.tree,y);v&&(d[y.id]=v);let C=e.events.variantOnAppearId.get(y.id),I=z(f[y.replicaInfo.inheritsFrom??""]??l);!U(C)&&z(C)!==I&&(f[y.id]=C)}return{gestures:a,breakpoints:d,classNames:s,sizes:i,appearEventMap:f}}function kd(o,t,e,n,r){let i=[];if((oe(o)||F(o))&&e){let a=t.declarations.file.dedupe("HTMLStyle",u`({value}) => {${u.joinLines(u`const onCanvas = ${w.fn(t.imports.addImport("framer",{exportSpecifier:"useIsOnFramerCanvas"}))}`,u`if (onCanvas) return null`,u`return ${Me.tag("style",new $({"data-framer-html-style":"",dangerouslySetInnerHTML:{__html:u`value`}}))}`)}}`);i.push(c=>Me`${u.joinLines(Me.tag(a,new $({value:e})),c)}`)}if(Ne(o)){let a=t.imports.addImport("react",{exportSpecifier:"*",importBinding:"React"}),c=t.imports.addImport("framer-motion",{exportSpecifier:"motion.create"}),d=t.declarations.file.dedupe("Variants",w.fn(c,u`${a}.Fragment`));i.push(p=>Me.tag(d,new $({initial:!1,animate:b.variants}),p))}if(F(o)||oe(o)||le(o)){let a=new $({id:oe(o)?Xo:Qo});i.push(c=>Me`${u.joinLines(c,Me.tag("div",a))}`)}let s=t.imports.addImport("framer-motion",{exportSpecifier:"LayoutGroup"});if(i.push(a=>Me.tag(s,new $({id:u`layoutId ?? ${b.defaultLayoutId}`}),a)),F(o)||oe(o)){let a=t.imports.addImport("framer",{exportSpecifier:"GeneratedComponentContext"});i.push(c=>Me.tag(u`${a}.Provider`,new $({value:{primaryVariantId:o.baseVariantId,variantClassNames:b.variantClassNames,activeVariantId:n,humanReadableVariantMap:r,isLayoutTemplate:oe(o)?!0:void 0}}),c))}return i}function Da(){let o=new w("0ea0c8c");return u`// Generated by Framer (${o})`}var Ro={ref:b.ref,restProps:b.restProps,style:b.style,props:b.props,className:b.className,layoutId:b.layoutId},Do=u`css`,hn=u`Icon`,vr=u`Component`,gn=u`Props`,Ud=[...Object.values(Ro),Do,hn,vr,gn].map(o=>z(o)),Na=ee(async(o,t,e)=>{let{serializationId:n}=e,{modulesStore:r,tree:i,vectorsStore:s}=t,a=i.getScopeNodeFor(o);S(de(a),"Vector set item must be in a VectorSetNode.");let c=i.get(o.id);S(c,"Must have a source node to serialize");let{ctx:d,jsx:p,svg:l,type:f}=Ai(c,a,t,n,Ud),y=Fe("vectorSet",a.id,"default").localId,h=r.getPersistedModuleByLocalId(y);S(h,"VectorSet must be persisted.");let m=i.getRect(o),{propertyControls:v,variableMap:C,types:I,props:R}=ar(a,{...t,...d,cssVariableDefinitions:void 0},"VectorSet","vector",void 0),M=Ad(d),P={name:c.resolveValue("name")??"Vector",empty:Bd(c)?!0:void 0,color:M,set:{localId:y,id:a.id,moduleId:h.id}},D=d.imports.addImport("react",{exportSpecifier:"*",importBinding:"React"}),x=d.imports.addImport("framer",{exportSpecifier:"withCSS"}),k=zd[f],re=E.lines(...d.variables.fallbackDeclarations(),...d.declarations.file.list(),u`interface ${gn} extends ${D}.HTMLAttributes<${D}.${k}> { ${I??u``} }`,u`const ${vr}: ${D}.ComponentType<${gn}> = ${D}.forwardRef<${D}.${k}, ${gn}>(function(${Ro.props}, ${Ro.ref}) {${u.joinLines(R,...d.declarations.component.list(),u`return (${p})`)}})`,u`const ${Do} = ${d.css.rules}`,tt("This is a generated Framer component.",{framerIntrinsicWidth:m.width,framerIntrinsicHeight:m.height,framerSupportedLayoutWidth:"any-prefer-fixed",framerSupportedLayoutHeight:"any-prefer-fixed",framerVariables:C&&JSON.stringify(C),framerImmutableVariables:!0,framerVector:JSON.stringify(P),framerDisableUnlink:as.has(P.set.moduleId)?!0:void 0}),u`const ${hn}: ${D}.ComponentType<${gn}> = ${w.fn(x,vr,Do,n)} as typeof ${vr};`,u`${hn}.displayName = ${c.resolveValue("name")??"Vector"};`,u`export default ${hn}`,v&&w.fn(d.imports.addImport("framer",{exportSpecifier:"addPropertyControls"}),hn,new w(`${z(v)} as any`)));return s.cache(o.id,{svg:z(l),color:M}),er([{revision:c.moduleSourceRevision,type:"vector",source:new w(E.sections(E.linesFrom(d.imports.statements),re)),artifacts:{files:[{name:"icon.svg",type:"svgIcon",content:z(l)}]}}])});function Ad(o){if(o.colors.uniqueColorCount!==1)return;let t=o.colors.singleColor;if(t)return{type:"static",value:t};let e=o.colors.singleVariableColor;if(e)return{type:"variable",value:et(e)}}function Bd(o){return!o.children||o.children.length===0?!0:o.children.every(t=>t.visible===!1)}var zd={0:u`HTMLImageElement`,1:u`HTMLDivElement`,3:u`HTMLSVGElement`,2:u`HTMLSVGElement`};var Pa=ee(async(o,{modulesStore:t},e)=>{let n=[];for(let s of o.getVectorSetItems()){let a=Fe("vector",s.id,"default").localId,c=t.getPersistedModuleByLocalId(a);c&&n.push({id:s.id,name:s.resolveValue("name")??"Vector",moduleId:c.id,saveId:e.includeVectorSetSaveIds?c.saveId:void 0})}let r={framerVectorSet:JSON.stringify({name:o.resolveValue("name")??"Set",items:n})},i=new w(E.lines(tt("This is a generated Framer component.",r),u`const VectorSet: React.ComponentType<unknown> = function VectorSet() { return null; };`,u`export default VectorSet;`));return[{revision:o.moduleSourceRevision,type:"vectorSet",source:i}]});function Va(o){return Math.ceil(o/Math.ceil(o/100))}var xa=class{constructor(t,e){g(this,"status",null);g(this,"results");g(this,"reportProgress");g(this,"onDone");this.reportProgress=t,this.onDone=e}async import(t,e,n){this.status="importing",this.results={scopeId:e,vectors:[],targetLayout:n};let r=n?{left:n.x+n.width*2,top:n.y}:{left:0,top:0};for(let i=0;i<t.length;i++){let s=t[i];if(!s)continue;let a=await _d(s,e,r);if(this.status!=="importing")return;a&&this.results.vectors.push(a),this.reportProgress?.({status:this.status,finishedCount:i+1})}await this.done()}cancel(){this.status="canceled"}async done(){this.results&&await this.onDone?.(this.results),this.status="done"}},La="run-svgo",Od=1e6;async function _d(o,t,e){if(o.size>Od){cn({type:"add",variant:"error",key:La,primaryText:"SVG is too large.",secondaryText:"You may need a PNG.",icon:"error",duration:5e3});return}try{let n=await o.text(),r=Ls(n),i=jd(o.name),s=rs(n,an.createEmpty,r);return s?(s.parentid=t,s.set({name:i,isVectorSetItem:!0,...e}),{node:s,size:r}):void 0}catch(n){console.error("Failed to insert SVG:",n),cn({type:"add",variant:"error",key:La,primaryText:"Failed to insert",secondaryText:"your SVG.",icon:"error"});return}}var $d=/[_-]/gu;function jd(o){let[t]=pi(o);return $o(t.replace($d," "))}var Wd=2;function No(o){if(F(o))return Wd}function cy(o,t,e){if(t.type==="siteMetadata"||t.type==="webPageMetadata")return!0;let n=dn(o,e).includes(t.type);if(S(o.id===t.name&&n,"sourceNode and module must match"),nr(t))return!1;let r=No(o);if(U(r))return!0;let i=t.metadata.codeGenVersion;return B(i)&&i>=r}var Po=1;function Gd(o){let t=o.metadata.compatibleTextStyleVersion;return B(t)?t:0}function py(o){return Gd(o)<Po}var st=ft(Pn(),1);function Ea(o,t){if(Ne(o))return"Smart Component";if(F(o))return"web page";if(ue(t.get(o.parentid)))return"prototype screen";if(ue(o))return"prototype";if(Z(o))return"CMS collection"}function Ma(o,t,e){return F(e)?Ms(o,t,e):e.resolveValue("name")??void 0}function ka(o,t="module",e){let n="is too large and will not update";cn({type:"add",variant:"warning",text:e?(0,st.jsxs)(st.Fragment,{children:[(0,st.jsxs)(Gn,{children:["The ",t]})," \u201C",e,"\u201D ",(0,st.jsx)(Gn,{children:n})]}):(0,st.jsxs)(Gn,{children:["A ",t," ",n]}),key:`module-too-large-${o}`,duration:1/0,extraAction:{title:"Learn more",onClick(){Pe("ui_interaction",{page:"module-too-large-toast",id:"learn_more"}),ts("https://www.framer.com/help/articles/how-to-fix-module-too-large-warning/")}}});let i=`module-too-large-toast-${t.split(" ").join("-")}`;Pe("ui_impression",{page:i})}var qd=1e4,Hd=1e3,yn=N("CodeGenerationStore");function Kd(o){return!(Z(o)||ue(o)||mt(o)||Fn(o)||Et(o)||de(o))}function Qd(o,t){if(!ke(t))return;let e=o.getScopeNodeFor(t);return S(de(e),"Vector set item must be in a VectorSetNode."),e.variables}function Xd(o,t){let e=t.resolveValue("name")?.trim();return e||(xi(t)?"Text":On(o,t,t.__class))}function Ua(o,t,e,n,r,i){let s={},a=Xd(t,e);s.metadata||(s.metadata={});let c=[...i?.files??[]];Kd(e)&&c.push({name:"tree.json",type:"nodeTree",content:JSON.stringify(Object.assign(e.toJS(),{__treeSerializationVersion:o.serializationVersion,__vectorSetVariables:Qd(o,e)}))});let d=No(e);d&&(s.metadata.codeGenVersion=d);let p=i?.packageDependencies;return p&&(s.metadata.packageDependencies=Array.from(p)),Ws(n)&&(s.metadata.compatibleCmsVersion=js),qo(e)&&(s.metadata.compatibleTextStyleVersion=Po),s.assets=i?.assets?Array.from(i.assets):[],{...s,title:a,files:c,errors:i?.errors??[],type:n,name:r}}async function Yd(o,t,e,n,r){if(o&&t instanceof zo&&t.code===1001){let i=Gi(o,a=>n.treeIndex.getScopeIdFor(a))??void 0,s=new Ji({type:"CodeGeneration",nodeId:Ge(o)?o.baseVariantId:o.id,reason:"FileTooLarge",sourceNodeId:o.id,scopeId:i});ka(o.id,Ea(o,n.tree),Ma(n.tree,e,o)),await r(a=>{if(a.isViewOnly)return;a.lineage.setEditReason("codegeneration");let c=ji.ensure(a);yn.debug("Writing ClientFileTooLarge error to tree for",o.id),a.insertNode(s,c.id)})}else yn.reportError(t)}var se,Wt,br=class{constructor(t,e,n,r,i,s){this.componentLoader=t;this.treeStore=e;this.modulesStore=n;this.runWhenIdle=r;this.scheduleDocumentUpdateIgnoringUndo=i;Y(this,se,new ea);Y(this,Wt);g(this,"process",T(this,se).synchronize);g(this,"processWithProgress",T(this,se).synchronizeWithProgress);g(this,"changeScope",()=>T(this,Wt).debounce(Hd));g(this,"isIdle",()=>T(this,se).size===0);g(this,"isBlocking",()=>T(this,se).snapshot().some(t=>t.promise.state==="pending"));ye(this,Wt,new Dn({delay:qd,task:()=>this.runWhenIdle(()=>void T(this,se).synchronize()),abortSignal:s}))}enqueue(t,e,n){T(this,se).snapshot(a=>a.promise.isResolved()?!1:a.id===e?a.promise.state!=="initial":!0);let r=t.get(e);if(!r||!qs(r,t))return;let i=ot(r),s={};for(let{type:a,artifacts:c}of n){let d=Ua(t,this.componentLoader,r,a,i,c);s[Q(a,i)]=d}T(this,se).request(async()=>{try{yn.debug("Persisting transient modules for",e),await this.modulesStore.upsertBatch(s)}catch(a){await Yd(r,a,this.componentLoader,this.treeStore,this.scheduleDocumentUpdateIgnoringUndo)}},{id:e,synchronize:!1})}async persist(t,e,n){let r=this.treeStore.getDataTreeOrPartialTree(),i=r.get(t);if(i)return this.enqueue(r,t,e),n?T(this,Wt).debounce():(await T(this,se).synchronize(),rr(i,r).map(s=>this.modulesStore.getPersistedModuleByLocalId(s)))}async persistBatch(t){let e=this.treeStore.getDataTreeOrPartialTree(),n={},r="batch";for(let i in t){let s=e.get(i),a=t[i];if(!s||!a)continue;let c=ot(s),d=new Set;for(let{type:p,artifacts:l}of a){let f=Q(p,c);S(!d.has(f),"Duplicate local module id",f),d.add(f),n[f]=Ua(e,this.componentLoader,s,p,c,l),r+=`-${f}`}}T(this,se).snapshot(i=>i.promise.isResolved()?!1:i.id===r?i.promise.state!=="initial":!0),await T(this,se).request(async()=>{yn.debug("Persisting transient modules for batch: ",r);try{await this.modulesStore.upsertBatch(n)}catch(i){yn.reportError(i)}},{id:r,synchronize:!0})}get size(){return T(this,se).size}};se=new WeakMap,Wt=new WeakMap;var Zd=()=>({stylePresets:[],componentPresets:[],collections:[],smartComponents:[],screens:[],prototypes:[],webpages:[],metadata:[],layoutTemplates:[],snippets:[]}),_=N("CodeGenerationStore");var el=500,Ba=1500,tl=6e4;function nl(o){for(let t in o.to)if(t in Ki)return!0;return!1}function rl(o){return de(o)?el:Ba}var at,G,He,Gt,Jt,qt,Ht,X,Cr,za,Aa=class extends Un{constructor(e,n,r,i,s,a,c,d,p,l,f,y,h=new Map){super();this.componentLoader=e;this.treeStore=n;this.modulesStore=r;this.vectorsStore=i;this.aiGenerationStore=s;this.assetMap=a;this.timeline=c;this.engineChanges=d;this.scheduleDocumentUpdateIgnoringUndo=p;this.updateTreeCache=l;this.measureNodes=f;Y(this,Cr);Y(this,at,new Set);Y(this,G);Y(this,He,new Map);Y(this,Gt);Y(this,Jt);Y(this,qt,new Map);Y(this,Ht);g(this,"testing",{setComponentGenerationQueue:e=>{ye(this,G,e)},flushQueuedCallbacks:()=>{T(this,He).forEach(e=>e.forEach(n=>n()))},generateAndUpdateQueuedComponents:e=>this.generateAndUpdateQueuedComponents(e),setSerializationId:e=>{ye(this,Ht,e)},setModulesStore:e=>{Object.assign(this,{modulesStore:e}),Object.assign(this.persistence,{modulesStore:e})},waitForProcessing:async e=>{await this.serialization.promise(e)}});g(this,"persistence");g(this,"moduleTypeOrder",{localization:0,webPageMetadata:1,siteMetadata:2,collection:3,draftCollection:4,css:5,componentPresets:6,vector:7,vectorSet:8,canvasComponent:9,screen:10,["prototype"]:11,codeFile:12,config:13,layoutTemplate:14,design:15,kit:16,snippets:17,shader:18});Y(this,X,new Map);g(this,"serialization",{idle:async()=>{let e=[];for(let n of T(this,X).keys())e.push(this.serialization.promise(n)?.then(()=>this.untilCompiled(n)));await Promise.all(e)},isIdle:()=>T(this,X).size===0,prepare:e=>{T(this,G).delete(e);let n=T(this,X).get(e)??new In;T(this,X).set(e,n)},cancel:e=>{T(this,G).delete(e),T(this,X).get(e)?.resolve(),T(this,X).delete(e)},preparing:e=>T(this,X).has(e),promise:e=>T(this,X).get(e),commit:async(e,n,r,i)=>{let s=()=>{T(this,X).get(e.id)?.reject(),T(this,X).delete(e.id)};try{let a=await Uo(this,Cr,za).call(this,e,n,r,i);return a||s(),a}catch(a){throw _.reportError(a),s(),a}}});ye(this,G,h),ye(this,Gt,this.timeline.openNodeChangesReader()),ye(this,Jt,new Dn({delay:Ba,maxDelay:tl,task:()=>this.scheduler.runWhenIdle(()=>{this.generateAndUpdateQueuedComponents()}),abortSignal:y})),this.persistence=new br(this.componentLoader,this.treeStore,this.modulesStore,m=>this.scheduler.runWhenIdle(m),m=>this.scheduleDocumentUpdateIgnoringUndo(m),y),$s({check:()=>{if(De.isTest)return!1;let m=this.treeStore.getDataTreeOrPartialTree();return m.isViewOnly?!1:this.hasBlockingUpdates(m)},effect:()=>{_.debug("Showing Unsaved Changes dialog (generation queue #: ",T(this,G).size,", component ids to generate: ",[...T(this,G).keys()],")");let m=this.getMetrics();m.paused>1?_.reportError("Tab closed with paused code generations",m):(m.persisting>5||m.serializing>5||m.queue>5)&&_.reportError("Tab closed with multiple code generations in progress",m),T(this,at).clear(),this.generateAndUpdateQueuedComponents().then(()=>{this.persistence.process()}).catch(v=>_.reportError(v))}},y),window.addEventListener("blur",async()=>{try{await this.generateAndPersistAllQueuedComponents()}catch(m){_.reportError(m)}},{signal:y})}isIdle(){return T(this,G).size===0&&this.serialization.isIdle()&&this.persistence.isIdle()}getMetrics(){return{queue:T(this,G).size,paused:T(this,at).size,serializing:T(this,X).size,persisting:this.persistence.size}}documentDidLoad(){T(this,G).clear(),T(this,He).clear(),T(this,qt).clear()}telemetrySession(e,n){let r=T(this,qt).get(n);if(r)return r;let i=e.get(n);S(i,"TelemetrySession: source node must exist");let s=new ur(i);return T(this,qt).set(n,s),s}getSerializationId(){return T(this,Ht)?`framer-${T(this,Ht)}`:`framer-${cs(5)}`}async generateAndPersistAllQueuedComponents(){await this.ensureSiteMetadataModule(),await this.ensureSnippetsModule(),await this.generateAndUpdateQueuedComponents(),await this.serialization.idle(),await this.persistence.process()}debugGetComponentSourceNodes(){let e=Zd();S(!1,"This method should only be used in tests.");let n=this.treeStore.getDataTreeOrPartialTree();for(let{node:r,skipChildren:i}of n.root.walkWithSkipChildren())F(r)?(e.webpages.push(r),e.metadata.push(r),i()):Ne(r)?(e.smartComponents.push(r),i()):Z(r)?(e.collections.push(r),i()):Jr(r)?(e.stylePresets.push(r),i()):Et(r)?e.componentPresets.push(r):Js(r,n)?(e.screens.push(r),i()):ue(r)?e.prototypes.push(r):mt(r)?e.metadata.push(r):oe(r)?e.layoutTemplates.push(r):ht(r)&&e.snippets.push(r);return e}postProcess(e,n,r){if(!e.isViewOnly){if(r){T(this,Gt).clear();return}this.ingestChanges(e),T(this,Jt).debounce(rl(n))}}ingestChanges(e){for(let[n,r]of T(this,Gt).read()){if(r.length===0||r.every(s=>s.ignoreInCodeGeneration))continue;let i=e.get(n);if(i){if(F(i)&&Wo(r)){let s=e.get(Qi);s&&this.addChangeToQueue(s)}if(be(i,e)){Di(i,r)&&this.addChangeToQueue(i);continue}if(mt(i)){if(!r.some(nl))continue;this.addChangeToQueue(i)}else if(ue(i))this.addChangeToQueue(i);else{let s=this.treeStore.treeIndex.getGroundNodeIdFor(n),a=e.get(s);if(!a||Ze(a))continue;let c=e.getScopeNodeFor(a);if(!ue(c))continue;this.queueCanvasPageNodesFollowingLinks(e,a)}}}}queueCanvasPageNodesFollowingLinks(e,n){if(this.addChangeToQueue(n),!(!n.cache.links||n.cache.links.size===0))for(let r of n.cache.links){let i=this.treeStore.treeIndex.getGroundNodeIdFor(r),s=e.get(i);!s||Ze(s)||this.queueCanvasPageNodesFollowingLinks(e,s)}}changeScope(){this.treeStore.tree.isViewOnly||De.isTest||this.isIdle()||this.serialization.idle().then(()=>this.generateAndUpdateQueuedComponents()).then(()=>{if(!Ft.isOn("prioritizedModuleEvaluation")){this.persistence.process();return}this.persistence.isIdle()||this.persistence.changeScope()}).catch(e=>_.reportError(e))}async createVectorSet(e,n){let r=e[0];if(!r)return;let s=this.treeStore.getDataTreeOrPartialTree().getScopeNodeFor(r);S(de(s),"VectorSet: VectorSetNode must exist.");let a=performance.now(),c=await this.batchSerializeVectors(e,n);if(!c)return;let d={},p=0,l=Object.keys(c).length,f=Va(l),y=[];for(let h in c){let m=c[h];m&&(d[h]=m,p++,!(p%f!==0&&p!==l)&&(y.push(d),d={}))}for(let h=0;h<y.length;h++){let m=y[h];m&&(await this.persistence.persistBatch(m),n?.("persisting",h))}await this.forceComponentUpdate(s.id),_.debug("createVectorSet: Spent ",performance.now()-a,"ms creating a new vector set.")}async createModuleFromComponentSource(e,n){let r=this.treeStore.getDataTreeOrPartialTree();if(S(!r.isViewOnly,"CodeGenerationStore: viewers cannot create smart components or web pages."),S(yt(e,r),"CodeGenerationStore: componentSourceNode must be a valid component source."),At(e,r,this.modulesStore))return;_.debug("createModuleFromComponentSource",e.id),this.serialization.prepare(e.id);let s=await this.generateComponent(e.id,1,void 0,{intrinsicSize:n});if(!s)throw new Error("Code not generated");return await this.compileOutput(e,s),r=this.treeStore.getDataTreeOrPartialTree(),rr(e,r).map(a=>this.modulesStore.getPersistedModuleByLocalId(a))}revisionNodes(e){let n=[];for(let r of e.root.children)be(r,e)&&n.push(r),(Et(r)||Jo(r))&&r.children.forEach(i=>{be(i,e)&&n.push(i),Z(i)&&i.getUnsortedChildren().forEach(s=>{be(s,e)&&n.push(s)})});return n}nodesWithStaleModules(e,n){let r=[],i=n?.ignoreHint??!1,s=this.treeStore.getDataTreeOrPartialTree();for(let a of this.revisionNodes(s))Ar(a)||e&&!e(a)||(!i&&a.moduleSourceRevisionHint!==a.moduleSourceRevisionCommittedHint||!this.allModulesAreAtRevision(s,a.id))&&r.push(a);return r}canSerialize(e){let n=this.treeStore.getDataTreeOrPartialTree();if(!n.isViewOnly)return!0;let r=n.get(e);if(!r||!n.isGroundNode(r))return!1;let i=n.getScopeNodeFor(r);return le(i)}async updateComponent(e,n=0){S(this.canSerialize(e),"CodeGenerationStore: viewers cannot generate smart component or web page updates.");let r=this.treeStore.getDataTreeOrPartialTree(),i=r.get(e);if(!i||!yt(i,r))return!1;if(this.serialization.preparing(e))return await this.serialization.promise(e),await this.untilCompiled(e),!0;_.debug("Update component: ",e,", Condition: ",n);let s=T(this,G).get(e);this.serialization.prepare(e);let a=await this.generateComponent(e,n,s);return a?this.compileOutput(i,a):!1}async forceComponentUpdate(e){return S(this.canSerialize(e),"CodeGenerationStore: viewers cannot generate smart component or web page updates."),await this.updateComponent(e,2)?(await this.persistence.process(),!0):!1}queueCallbackAfterComponentCompilation(e,n){let r=T(this,He).get(e);r?r.push(n):T(this,He).set(e,[n])}untilCompiled(e){return new Promise(n=>{this.queueCallbackAfterComponentCompilation(e,n)})}calculateNewModuleRevision(e){let n=this.treeStore.getDataTreeOrPartialTree(),r=n.get(e);if(!r||!be(r,n))return 1;if(!(!ht(r)&&!fo(n,e)||!n.has(e)))return ra(e,this.scheduleDocumentUpdateIgnoringUndo)}allModulesAreAtRevision(e,n,r){let i=e.get(n);if(!i||!be(i,e))return!1;let s=r??i.moduleSourceRevision;return dn(i,e).every(a=>this.modulesStore.forType(a).getByStableName(ot(i)).sourceRevision()===s)}async ensureDependencyModulesExist(){let e=this.treeStore.getDataTreeOrPartialTree();for(let n of this.revisionNodes(e))if(yt(n,e)&&!At(n,e,this.modulesStore))try{await this.updateComponent(n.id)}catch(r){_.error("Error updating dependency module",n.id,r)}}async ensureSourceNode(e){let n=this.treeStore.getDataTreeOrPartialTree().get(e),r=sn(n)&&!n.isLoaded()?await n.load():n;if(r){if(F(r)&&(await this.ensureSiteMetadataModule(),S(r.loaded,"WebPageNode must be loaded"),await this.ensureReferencedCollectionsExportUpToDateEnumUtils(r.loaded)),Z(r)&&await this.ensureDependentModulesAreCompatibleWithCollection(r),ke(r)){let i=this.treeStore.getDataTreeOrPartialTree().getScopeNodeFor(r);if(!de(i))return;let s=Q("vectorSet",i.id);if(this.modulesStore.getModuleEntryByLocalId(s))return;await this.createModuleFromComponentSource(i)}await this.ensureAllNodesWithLinksHaveLinkedScopesLoaded(r)}}async ensureSiteMetadataModule(){let e=this.treeStore.getDataTreeOrPartialTree();if(e.isViewOnly)return;let n=e.root;if(!At(n,e,this.modulesStore))return this.updateComponent(n.id)}async ensureSnippetsModule(){let e=this.treeStore.getDataTreeOrPartialTree();if(e.isViewOnly)return;let n=Xi.get(e);if(!n)return;let r=await n.load();if(!(!r||At(r,e,this.modulesStore)))return this.updateComponent(r.id)}hasBlockingUpdates(e){if(T(this,G).size>0){for(let[n,r]of T(this,G))if(e.has(n)&&r)return!0}return!this.persistence.isIdle()||!this.serialization.isIdle()}async updateModules(e,n){let r=this.treeStore.getDataTreeOrPartialTree(),i=r.get(e),s=this.timeline.remoteTreeVersion;if(!i||!yt(i,r))return!1;let a=[];for(let{revision:d,source:p,type:l,artifacts:f}of n){let y={assets:f?.assets,submodules:f?.submodules,binaryAssets:f?.binaryAssets,preventCircularImports:l==="canvasComponent",telemetrySession:this.telemetrySession(r,e),treeVersion:s,sourceRevision:d,kitSectionsStructure:f?.kitSectionsStructure,svgIcon:f?.files?.find(C=>C.type==="svgIcon")?.content,stableName:!0},h=this.modulesStore.forType(l).getByStableName(ot(i)),m=h.sourceRevision()!==d,v=E.sections(Da(),p);!m&&h.currentSourceEquals(v,y)||a.push({localId:h.localId,source:v,options:y})}if(a.length===0)return!1;let c=await this.modulesStore.updateSources(a);return ke(i)&&this.vectorsStore.delete(e),F(i)&&this.aiGenerationStore.deleteKitSectionsStructure(e),c}allModulesExistForSources(e,n){let r=ot(e);for(let i of n)if(!this.modulesStore.getPersistedModuleByLocalId(Q(i.type,r)))return!1;return!0}async compileOutput(e,n){if(!this.canSerialize(e.id))return!1;let r=n.slice().sort((s,a)=>this.moduleTypeOrder[s.type]-this.moduleTypeOrder[a.type]);if(this.allModulesExistForSources(e,r))await this.updateModules(e.id,r);else for(let s of r){let a=await this.updateModules(e.id,[s]),c=ot(e);!this.modulesStore.getPersistedModuleByLocalId(Q(s.type,c))&&a&&await this.persistence.persist(e.id,[s])}return Z(e)&&await this.ensureDependentModulesCanRenderCollectionColors(e),T(this,He).get(e.id)?.forEach(s=>s()),T(this,He).delete(e.id),this.persistence.persist(e.id,n,!0),!0}pauseCodeGeneration(e){return _.debug("Pausing code generation for",e),T(this,at).add(e),()=>{_.debug("Resuming code generation for",e),T(this,at).delete(e),T(this,Jt).debounce()}}async generateAndUpdateQueuedComponents(e){if(this.treeStore.getDataTreeOrPartialTree().isViewOnly)return[];await this.ensureDependencyModulesExist();let n=[],r=new Map;for(let[s]of T(this,G)){if(T(this,at).has(s)||this.serialization.preparing(s))continue;let a=this.treeStore.getDataTreeOrPartialTree(),c=a.get(s);if(!c||!yt(c,a)||e&&!dn(c,a).includes(e)){T(this,G).delete(s);continue}if(this.serialization.prepare(s),ke(c)){let d=a.getScopeNodeFor(c);if(!d)continue;let p=r.get(d.id)??[];p.push(c),r.set(d.id,p)}else n.push(c)}let i=new Set;_.debug("Batch generating queued vector nodes");for(let s of r.values())try{let a=await this.batchSerializeVectors(s,void 0,i);for(let c in a)this.persistence.persist(c,a[c],!0)}catch{}_.debug("Generating queued components",{ids:n.map(tr)});for(let s of n)try{_.debug("Flushing queue of ",s.id);let a=await this.generateComponent(s.id,1);a&&(await this.compileOutput(s,a),i.add(s.id))}catch{}return Array.from(i)}async batchSerializeVectors(e,n,r){let i=e[0];if(!i)return;await this.ensureSourceNode(i.id),await this.ensureSourceCache(i.id),e.forEach(l=>this.serialization.prepare(l.id));let s=await oa(e,this.scheduleDocumentUpdateIgnoringUndo);S(s,"VectorSet: newModuleRevisions must exist");let a={componentLoader:this.componentLoader,assetMap:this.assetMap,modulesStore:this.modulesStore,treeStore:this.treeStore,tree:this.treeStore.getDataTreeOrPartialTree(),vectorsStore:this.vectorsStore,aiGenerationStore:this.aiGenerationStore,engineChanges:this.engineChanges,measureNodes:this.measureNodes},c=await Promise.all(e.map(async l=>{if(!s[l.id])return;let m=(await this.serializerForSourceNode(this.treeStore.getDataTreeOrPartialTree(),l)(l,a,{serializationId:this.getSerializationId()}))?.[0];return S(m,"VectorSet: source must exist.",l.id),this.serialization.promise(l.id)?.resolve(),T(this,X).delete(l.id),[l.id,m]})),d=0,p={};for(let l of c){if(!l)continue;let[f,y]=l;await this.updateModules(f,[y])&&(p[f]=[y],n?.("serializing",d),d++,r?.add(f))}return p}async createVersionedVectorSet(e){await this.generateAndPersistAllQueuedComponents();let n=await this.generateComponent(e.id,2,void 0,{includeVectorSetSaveIds:!0});return!n||!await this.compileOutput(e,n)?!1:(await this.persistence.process(),!0)}isSkippedEmptyScopeNode(e){return ht(e)?!1:!!(sn(e)&&(!e.isLoaded()||e.loaded.children?.length===0))}async generateComponent(e,n,r,i){_.debug("Ensure source node",e),await this.ensureSourceNode(e),_.debug("Ensure source cache",e),await this.ensureSourceCache(e);let s=await this.calculateNewModuleRevision(e),a=this.treeStore.getDataTreeOrPartialTree(),c=a.get(e);if(!c||!yt(c,a)||!this.shouldGenerateUnderCondition(a,n,c,s,r)){_.debug("Cancel serialization",e),this.serialization.cancel(e);return}let d=Ge(c)?c.getPrimaryVariant():c;return _.debug("Serialize",e),this.serialization.commit(c,d,n,i)}shouldGenerateUnderCondition(e,n,r,i,s){let a=s??T(this,G).get(r.id);if(T(this,G).delete(r.id),!At(r,e,this.modulesStore))return!0;switch(n){case 2:return!0;case 1:return!U(i)||!this.allModulesAreAtRevision(e,r.id,i);case 0:return!U(i)&&!!a&&!this.allModulesAreAtRevision(e,r.id,i);default:Se(n)}}addChangeToQueue(e){if(!this.shouldSkipChange(e)){if(ke(e)&&this.vectorsStore.queue(e.id),Ar(e)){let n=e.parentid;S(n,"Collection node has no parent"),T(this,G).set(n,!0);return}T(this,G).set(e.id,!0)}}serializerForSourceNode(e,n){return Z(n)?fa:Ge(n)?Io:Jr(n)?Ca:ue(n)?ya:mt(n)?Fs:Et(n)?ha:de(n)?Pa:ke(n)?Na:ht(n)?Gs:le(e.get(n.parentid))?Io:Sa}shouldSkipChange(e){if(Ze(e)){let n=Re(e.codeComponentIdentifier);if(tn(n)&&n.type==="screen")return!0}return!1}async ensureSourceCache(e){let n=this.treeStore.getDataTreeOrPartialTree().get(e);!n||n.update===n.cache.lastUpdate||await new Promise(r=>{this.scheduler.runBeforeNextFrame(()=>{sn(n)&&n.update!==n.cache.lastUpdate&&this.updateTreeCache(n.id),r()})})}async ensureDependentModulesAreCompatibleWithCollection(e){let n=Q("collection",e.id),r=this.modulesStore.getDependentsOfModule(n);!r||r.size===0||await Promise.all(Array.from(r).map(async i=>{let s=i,a=this.modulesStore.getPersistedModuleByLocalId(s);if(!(!a||!nr(a)))return this.forceComponentUpdate(a.name)}))}async ensureDependentModulesCanRenderCollectionColors(e){let n=Q("collection",e.id),r=this.modulesStore.getDependentsOfModule(n);if(!r||r.size===0)return;let i=this.modulesStore.forType("collection").getByStableName(e.id);i&&i.annotations(null,"default")?.framerColorSyntax&&await Promise.all(Array.from(r).map(async s=>{let[a,c]=Mi(s);a==="draftCollection"||this.modulesStore.forType(a).getByStableName(c)?.annotations(null,"default")?.framerColorSyntax||await this.forceComponentUpdate(c)}))}async ensureReferencedCollectionsExportUpToDateEnumUtils(e){let n=new Set;for(let r of e.variables){if(r.type!=="controlReference"||r.expectedType!=="enum")continue;let i=Re(r.entityIdentifier);if(!tn(i)||i.type!=="collection")continue;let c=this.modulesStore.forType("collection").getByStableName(i.localIdName)?.annotations(null,"default")?.framerEnumToDisplayNameUtils;B(c)&&c>=2||n.add(i.localIdName)}for(let r of n)Pe("ui_interaction",{page:"canvas",id:"regenerate-collection-for-enum-utils"}),await this.forceComponentUpdate(r)}async ensureAllNodesWithLinksHaveLinkedScopesLoaded(e){let n=new Set,r=this.treeStore.getDataTreeOrPartialTree();r.beginAllowPartialScopeAccess();for(let i of e.walkWithSkipChildren()){if(!Ei(i.node))continue;let s=i.node.getLink();if(!ii(s))continue;let a=r.get(s.webPageId);if(!a||a.loaded)continue;let c=this.modulesStore.forType("screen").getByStableName(s.webPageId)?.annotations(null,"default");U(c?.framerScrollSections)&&(n.add(a),i.skipChildren())}r.endAllowPartialScopeAccess(),await r.loadScopes(Array.from(n))}};at=new WeakMap,G=new WeakMap,He=new WeakMap,Gt=new WeakMap,Jt=new WeakMap,qt=new WeakMap,Ht=new WeakMap,X=new WeakMap,Cr=new WeakSet,za=async function(e,n,r,i){let s=this.treeStore.getDataTreeOrPartialTree();if(!mt(e)&&!s.has(n.id))return;let a=this.telemetrySession(s,e.id),c=a.start("synchronize"),d=performance.now();_.debug("Waiting for ModulesStore to be idle",{id:e.id}),await this.modulesStore.whenIdle();let p=performance.now()-d;if(_.debug("Waited",Math.round(p/1e3*100)/100,"seconds for ModulesStore to be idle",{id:e.id}),c.end(),s=this.treeStore.getDataTreeOrPartialTree(),!s.has(n.id))return;let l=e.draftOrCurrent();if(r!==2&&this.isSkippedEmptyScopeNode(l))return;let f=a.start("serialize");Z(e)&&ol(e,this.componentLoader,s,this);let y=this.serializerForSourceNode(s,e);T(this,X).get(e.id)?.resolve(),T(this,X).delete(e.id);let h=await y(e,{componentLoader:this.componentLoader,assetMap:this.assetMap,modulesStore:this.modulesStore,treeStore:this.treeStore,tree:this.treeStore.getDataTreeOrPartialTree(),vectorsStore:this.vectorsStore,aiGenerationStore:this.aiGenerationStore,engineChanges:this.engineChanges,measureNodes:this.measureNodes},{serializationId:this.getSerializationId(),initialIntrinsicSize:i?.intrinsicSize,includeVectorSetSaveIds:i?.includeVectorSetSaveIds});return h.forEach(({source:m,artifacts:v})=>{if(_.trace("serializeComponent",`
>>>> >>>>
`,z(m),`
<<<< <<<<`),v?.submodules)for(let[C,I]of v.submodules)_.trace("serializeComponent",`
>>>>`,C,`>>>>
`,I,`
<<<<`,C,"<<<<")}),f.end(h),h};function ol(o,t,e,n){let r=o.instanceIdentifier,i=t.dataForIdentifier(r);if(!i||!Object.values(i.properties).some(c=>c?.type==="image"))return;let a=new Set;for(let c of e.root.children){if(!sn(c))continue;if(F(c)&&c.dataIdentifier===r){a.add(c);continue}c.loaded?.some(p=>Go(p)&&p.dataIdentifier===r)&&a.add(c)}a.forEach(c=>{n.forceComponentUpdate(c.id).catch(Bo)})}function Tr(o){let{appEnvironment:t,session:e,seq:n,count:r,reasons:i,changes:s}=o;return{appEnvironment:t,session:e,seq:n,changes:s,count:r,reasons:i}}function Oa(o,t){return{...o,next:t}}function _a(o){return"rows"in o}var il={cache:!0,update:!0,mutable:!0,children:!0};function sl(o,t){if(o!=="cached")return t}function $a(o){return JSON.parse(JSON.stringify(o,sl))}function wr(o,t,e){let n=new Set,r=!1;function i(a,c){n.add(a.id),c+="."+a.id;let d=t.get(a.id);if(!d)r=!0,e.push("-node: "+c+(Vn(a)?" (replica child)":""));else{let p=[],l=a.children?.map(y=>y.id).join(","),f=d.children?.map(y=>y.id).join(",");l!==f&&p.push(" .children: ["+l+"] != ["+f+"]");for(let[y,h]of a.entries()){if(y in il)continue;let m=d[y];Vt(h,m)?h&&typeof h=="object"&&h.__proto__!==(typeof m=="object"&&m&&"__proto__"in m?m.__proto__:void 0)&&p.push(" ."+y+": different prototypes"):(h===void 0||m===void 0||!Vt($a(h),$a(m)))&&y!=="contentHash"&&p.push(" ."+y+": "+JSON.stringify(h)+" != "+JSON.stringify(m))}p.length>0&&(r=!0,e.push("!node: "+c+(Vn(a)?" (replica child)":"")),e.push(...p))}for(let p of a.children??[])i(p,c)}function s(a,c){c+="."+a.id,n.has(a.id)||(r=!0,e.push("+node: "+c+(Vn(a)?" (replica child)":"")));for(let d of a.children??[])s(d,c)}return i(o.root,""),s(t.root,""),r}var xo=class{constructor(t,e){this.id=t;this.store=e;g(this,"loadedScope")}loadScopeDataFromStore(){let t=this.store.getObject(this.id);if(!t){he.debug("No object with id "+this.id+" in the store");return}return t}createNodeFromData(t){let e=this.buildPage(t);if(e)return e.cache.isShallowLoad=!1,e}async run(t){if(this.loadedScope)return this.loadedScope;let e=performance.now(),n=this.loadScopeDataFromStore(),r=performance.now()-e;if(await t.yield(),this.loadedScope)return this.loadedScope;let i=performance.now(),s=this.createNodeFromData(n),a=performance.now()-i;return this.loadedScope=new vt(s,r+a),this.loadedScope}force(){if(this.loadedScope)return this.loadedScope;let t=performance.now(),e=this.loadScopeDataFromStore(),n=this.createNodeFromData(e),r=performance.now()-t;return this.loadedScope=new vt(n,r),this.loadedScope}buildPage(t){if(!t)return;let e=[],n=he.isLoggingTraceMessages()?[]:void 0,r=nt(t,void 0,{extraChecksAndFixes:!0,errors:e,warnings:n});if(r&&Zn(r,e),e.length>0&&he.warn("errors loading server tree: "+e.join(`
`)),n&&n.length>0&&he.trace("warnings loading server tree: "+n.join(`
`)),!!r)return r}},he=N("CrdtDocumentLoader"),Kt=class extends qe{constructor(e,...n){super(...n);this.store=e;g(this,"parsedIds",new Set)}async loadFirstCrdtTree(e){let n=[],i=this.store.getObjectWithShallowChildren(e.rootId,1);S(i,"Root object not found in store");let s=[...oo],a,c=this.settings.activeNodeId,d=c?this.store.getObjectWithShallowChildren(c,1):void 0;for(;d&&d.parentid!==e.rootId;){if(!d.parentid)throw Error("active node has no parent");d=this.store.getObjectWithShallowChildren(d.parentid,1)}Ue(d)?s.push(d.id):(a=sr(i.children,i?.homePageNodeId),s.push(a.maybeFirstPage.id));let p=nt(i,null,{extraChecksAndFixes:!0,errors:n,warnings:n});S(p,"Unable to load document");for(let y of p.children)y.cache.isShallowLoad=!0;for(let y of s){if(!y)continue;let h=this.store.getObject(y);if(!h){he.debug("No value for "+y);continue}let m=nt(h);S(m,"Scope node instance could not be created"),m.cache.isShallowLoad=!1;let v=p.children.findIndex(I=>I.id===y);p.children[v]=m,this.parsedIds.add(y);let C=m;y===a?.maybeFirstPage.id&&a.firstDesignPage&&Hs(C,a.firstDesignPage)!==C&&s.push(a.firstDesignPage.id)}no(p,n);for(let y of p.children)this.parsedIds.has(y.id)||this.scopesToLoad.add(y.id);p.children.forEach(y=>{if(!this.parsedIds.has(y.id)&&Array.isArray(y.children)&&F(y)){y.cache.isShallowLoad=!0;return}});let l=an.createByAdoptingRoot(p);l.verify(),l=$r.treeDidLoad(l,this.componentLoader,[]).didNonLinearMove(this.componentLoader);let f=[];return to(l,f)&&(f.forEach(y=>{n.push(`${y.id}: code component links itself via ${y.stack}`),ro(l,y.id,y.stack)}),l=l.commit(this.componentLoader)),await this.emitWrapped(()=>{if(this.scheduler.isDone())return;let y=performance.now();l.setService("loader",this),this.emit("loadedFirstData",l),pe("parsingFirstPage"),this.parsingDuration+=performance.now()-y}),l}async createTreeFromBuffer(e){this.documentSize=e.byteLength;let n=this.store.loadVersionFromBuffer(e);if(this.emit("loadedFormatVersion",n),this.scheduler.isCancelled()){this.store.reset();return}try{this.store.fromBuffer(e);let r=this.store.getObject("meta");if(!r)throw new Error("Meta field not found");if(!Oo(r.version))throw Error("cannot read document version");if(this.canvasTreeVersion=r.version,he.debug("createTree",this.canvasTreeVersion,Bt(this.documentSize),Ce(this.loadingDuration)),this.emit("loadedDocumentVersion",r.version),this.scheduler.isCancelled()){this.store.reset();return}this.tree=await this.loadFirstCrdtTree(r),await this.loadAllScopesAsync()}catch(r){throw this.store.reset(),r}}async start(){await this.scheduler.run(async()=>{he.debug("start"),pe("parsingInit"),this.updatePauseResumeState();let e=performance.now(),n=await this.loadCrdtData();this.loadingDuration=performance.now()-e,await this.scheduler.yield(),await this.createTreeFromBuffer(n)})}async loadCrdtData(){if(this.settings.loadedData&&this.settings.loadedData instanceof Uint8Array)return he.debug("loadData: loadedData"),this.settings.loadedData;let e=this.settings.initData,n=e?.version===this.treeVersion,r=e?.prefetchPromise;if(he.debug("loadData: prefetch"),n&&r){e&&delete e.prefetchPromise;let s=await r;if(r.then(a=>a.duration).then(a=>{pe("dataLoad",a)}),await this.scheduler.yield(),s.status<200||s.status>=300)throw new Error(`Failed to fetch project data. Status code: ${s.status}`);if(s.buffer){he.debug("loadData: prefetch bytes parser");let a=await s.buffer;return await this.scheduler.yield(),new Uint8Array(a)}}he.debug("loadData: fetch");let i;this.settings.refreshAccessToken&&(i=await this.settings.refreshAccessToken({}),await this.scheduler.yield());for(let s=0;s<lr;++s){let a=await fetch(this.documentURL,i);if(a.ok){await this.scheduler.yield();let c=await a.arrayBuffer();return await this.scheduler.yield(),new Uint8Array(c)}(a.status<200||a.status>=300)&&(he.debug("onErrorStatusLoaded, retry:",s),await this.scheduler.sleep(s*un+Math.random()*un))}throw Error(`Failed to fetch project data after attempting ${lr} times`)}createLoadingScope(e){return new xo(e,this.store)}resetForCrashRecovery(e){let n=[],i=this.store.getObject("meta");if(!i)throw Error("Meta field not found in CRDT store during crash recovery");let s=this.store.getObjectWithShallowChildren(i.rootId,1),a=nt(s,null,{extraChecksAndFixes:!0,errors:n,warnings:n});if(!a)throw Error("Unable to create root from store during crash recovery");for(let l of a.children)l.cache.isShallowLoad=!0;this.parsedIds=new Set,this.scopesToLoad=new Set,this.currentLoadingScope=void 0,this.addedByDiff=new Set,this.removedByDiff=new Set,this.loadCallbacksPerScope=new Map,this.activelyLoadingScope=!1;let c=[...oo];e&&c.push(e);for(let l of c){let f=this.store.getObject(l);if(!f)continue;let y=nt(f);if(!y)continue;y.cache.isShallowLoad=!1;let h=a.children.findIndex(m=>m.id===l);h>=0&&(a.children[h]=y),this.parsedIds.add(l)}no(a,n);for(let l of a.children)this.parsedIds.has(l.id)||this.scopesToLoad.add(l.id);let d=an.createByAdoptingRoot(a);d.verify(),d=$r.treeDidLoad(d,this.componentLoader,[]).didNonLinearMove(this.componentLoader);let p=[];return to(d,p)&&(p.forEach(l=>{n.push(`${l.id}: code component links itself via ${l.stack}`),ro(d,l.id,l.stack)}),d=d.commit(this.componentLoader)),n.length>0&&he.warn("[crash-recovery] errors rebuilding tree from store:",n.join(`
`)),d.setService("loader",this),this.tree=d,this.loadedFirstScope=!0,d}};var _e=N("remote:sync"),Ir=class{constructor(t){this.committer=t;g(this,"session",0);g(this,"treeVersion",0);g(this,"updatesSeen",0);g(this,"init",0);g(this,"expectingInitialUpdates",0);g(this,"hasError",!1);g(this,"waitingForTree",!1);g(this,"messageSeq",0);g(this,"unconfirmedCrdtUpdates",new Map)}get waitingForInitialUpdates(){return this.expectingInitialUpdates>this.updatesSeen}get isLoading(){return this.waitingForTree||this.waitingForInitialUpdates}get isReady(){return!(this.hasError||this.waitingForTree||this.waitingForInitialUpdates)}error(t,e){return this.hasError=!0,Error(t,{cause:e})}verify(t,e){let n=this.committer.getTreeForVersion(t);if(!n)return _e.debug("verify: unable to find tree with version",t),!0;if(n.containsLocalEdits)return _e.debug("verify: unable verify an entry with local edits"),!0;let r=n.tree,i=r.computeTreeHash();if(i!==e){if(_e.warn("verify: failed",i,"!==",e),e===0)return!0;_e.reportError("Tree verification failed",{localHash:i,serverHash:e,treeVersion:t,treeSize:r.size()})}else _e.debug("verify: passed; hash:",e);return i===e}setTree(t,e,n){_e.info("setTree",e),this.committer.reset(t,n),this.treeVersion=e,this.waitingForTree=!1,this.hasError=!1,this.unconfirmedCrdtUpdates.clear(),this.committer.recordHistoricTree(e,0)}resetSession(){this.messageSeq=0,this.unconfirmedCrdtUpdates.clear(),this.treeVersion=0,this.waitingForTree=!1}debugResetSessionAndTree(t){this.resetSession(),this.setTree(t,0)}handleInit(t,e){return this.init+=1,_e.info("init",this.init,{treeVersion:t,initialUpdates:e,localTreeVersion:this.treeVersion}),this.hasError=!1,this.expectingInitialUpdates=e,this.updatesSeen=0,this.treeVersion!==t||this.waitingForTree?(this.waitingForTree=!0,!0):(this.committer.remoteTreeVersion=t,this.committer.recordHistoricTree(t,0),!1)}hasMessageForRemote(){return this.committer.hasLocalEdits()}hasOnlyEmptyChangesForRemote(){return this.committer.hasLocalEdits()?this.committer.hasOnlyEmptyChangesForRemote():!0}onLoadedFirstData(){this.committer.resetLastSeqTaken()}createMessage(t){let e=this.committer.takePendingRows(t);if(e.length<=0)return null;let n=this.committer.getEditReasons(),r={seq:++this.messageSeq,rows:e,reasons:n,ts:Date.now()};return _e.debug("create CRDT rows message:",e.length,"inflight:",this.unconfirmedCrdtUpdates.size,r.seq),this.unconfirmedCrdtUpdates.set(r.seq,r),r}hasUnconfirmedChanges(){return this.unconfirmedCrdtUpdates.size>0}createUnconfirmedMessages(){S(this.isReady);let t=Array.from(this.unconfirmedCrdtUpdates.values());return this.unconfirmedCrdtUpdates.clear(),t.map(e=>{let n={...e,seq:++this.messageSeq};return this.unconfirmedCrdtUpdates.set(n.seq,n),n})}handleConfirmMessage(t){if(this.hasError||this.waitingForTree)return;let e=t.seq,n=this.unconfirmedCrdtUpdates.get(e);if(S(n,"update not found for seq",e),this.unconfirmedCrdtUpdates.delete(e),S(Number.isFinite(t.next),"Confirm must have tree version"),t.next!==this.treeVersion+1){if(t.next<=this.treeVersion){_e.debug("ignoring old confirm:",t.next," <= ",this.treeVersion);return}throw this.error("missing update: "+this.treeVersion+" + 1 != "+t.next)}this.treeVersion=t.next,this.committer.handleRemoteConfirm(t.next,this.unconfirmedCrdtUpdates.size)}handleRemotePatches(t,e,n){if(!(this.hasError||this.waitingForTree)){if(S(Number.isFinite(e),"Update must have tree version"),e!==this.treeVersion+1){if(e<=this.treeVersion){_e.debug("ignoring old update:",e," <= ",this.treeVersion);return}throw this.error("missing update: "+this.treeVersion+" + 1 != "+e)}return this.treeVersion=e,this.committer.handleRemotePatches(t,e,this.unconfirmedCrdtUpdates.size)}}loadedAllScopes(){this.committer.loadedAllScopes(this.unconfirmedCrdtUpdates.size)}loadOneScope(t,e){return this.committer.loadOneScope(t,e)}};var ct=N("remote:connection"),Te=N("remote:verify"),al=5,Lo=class{constructor(t,e,n,r,i){this.componentLoader=e;this.userId=n;this.projectId=r;this.callbacks=i;g(this,"treeSync");g(this,"remoteUpdates",[]);g(this,"ignoreTreeVerifies",!1);g(this,"ignoreTreeVerifyVersion",0);g(this,"shouldCrashFromDebug",!1);g(this,"loader");g(this,"documentSize",0);g(this,"loaderPromise");g(this,"recorder");g(this,"scopeClassCache",new Map);g(this,"url");S(t instanceof _s,"tree updater must be a CrdtTreeCommitter"),this.treeSync=new Ir(t),this.treeSync.waitingForTree=!0,window.store=this.store}get unconfirmedCrdtUpdates(){return this.treeSync.unconfirmedCrdtUpdates}get treeVersion(){return this.treeSync.treeVersion}get isReady(){return this.treeSync.isReady}get waitingForTree(){return this.treeSync.waitingForTree}get store(){return this.treeSync.committer.store}get isLoading(){return this.treeSync.isLoading}get localUpdatesInFlight(){return[]}get localUpdatesAtInit(){return[]}get hasError(){return this.treeSync.hasError}get init(){return this.treeSync.init}get session(){return this.treeSync.session}setTree(t,e,n){this.treeSync.setTree(t,e,n)}get hasUpdatesToProcess(){return!this.waitingForTree&&this.remoteUpdates.length>0}resetSession(){this.treeSync.resetSession()}debugResetSessionAndTree(t){this.treeSync.debugResetSessionAndTree(t)}debugCrash(){this.shouldCrashFromDebug=!0}canProcessChanges(){if(!this.treeSync.isReady||this.shouldCrashFromDebug){if(this.treeSync.hasOnlyEmptyChangesForRemote())return!1;let t="is not ready";throw this.treeSync.hasError?t="had an error":this.treeSync.waitingForTree?t="is waiting for tree data":this.treeSync.waitingForInitialUpdates?t="is waiting for initial updates":this.shouldCrashFromDebug&&(this.shouldCrashFromDebug=!1,t="is doing a deliberate crash test"),this.treeSync.error("cannot create local updates when the document "+t)}return!0}processViewOnly(){this.store.seq<=0||(this.treeSync.onLoadedFirstData(),ct.warn("cannot create local updates when the user is a viewer"))}handleRows(t,e){this.remoteUpdates.push(e)}handleConfirmRows(t){this.remoteUpdates.push(t)}handleInit(t,e){return this.remoteUpdates.length=0,{needsDownload:this.treeSync.handleInit(t,e)}}handleTreeUpdate(){throw new Error("Json tree updates cannot be handled by Crdt data handler")}handleTreeVerify(t,e,n){if(!this.treeSync.isReady||this.ignoreTreeVerifies||this.ignoreTreeVerifyVersion===e||this.treeSync.committer.tree.getService("loader"))return;if(!this.treeSync.verify(e,n)){ct.info("Tree verify failed for version",e,"hash",n);let s=this.treeSync.committer.getTreeForVersion(e)?.tree;s&&(this.verifyLocalTreeWithServer(t,s,e),this.verifyLocalTreeWithServerJson(t,s,e)),this.remoteUpdates.length=0,this.treeSync.hasError=!0;let a=new Error("Local document out of sync with document on server.");this.callbacks.error(a);return}let r=qn(),i=xt.isDevelopment||xt.isLocal;if(r||i){let s=this.treeSync.committer.getTreeForVersion(e)?.tree;s&&(this.verifyLocalTreeWithServer(t,s,e),this.verifyLocalTreeWithServerJson(t,s,e))}}processRemoteUpdates(){if(ct.debug("processRemoteUpdates: starting - waitingForTree:",this.treeSync.waitingForTree,"waitingForInitialUpdates:",this.treeSync.waitingForInitialUpdates,"hasError:",this.treeSync.hasError,"isReady:",this.isReady,"remoteUpdates.length:",this.remoteUpdates.length),this.treeSync.waitingForTree){ct.debug("processRemoteUpdates: exiting early - waitingForTree=true");return}if(this.loader?.activelyLoadingScope){ct.debug("processRemoteUpdates: exiting early - activelyLoadingScope=true");return}let t;try{if(S(!this.treeSync.committer.tree.hasUncommittedChanges(),"tree must not have uncommitted changes"),this.shouldCrashFromDebug)throw this.shouldCrashFromDebug=!1,Error("RemoteDocument CrashTest");for(;this.remoteUpdates.length>0;){let e=this.remoteUpdates.shift();if(!e)break;if(t=e,!_a(e)){this.treeSync.handleConfirmMessage(e);continue}S(typeof e.next=="number","Update must have tree version"),$n.verifyBatches(e.rows),this.ensureAllScopesAreLoaded(e.rows);let n=this.writeServerUpdateToTheStore(e);if(n){let r=this.treeSync.handleRemotePatches(n,e.next,e.rows.length);r&&this.loader?.addNodeChanges(r)}this.treeSync.updatesSeen+=1}if(this.loader){let e=this.treeSync.committer.tree.root.children;if(!e.some(r=>Ue(r)&&r.isValid())){ct.info("cannot show any page, forcing load of next page");let r=e.find(s=>Ue(s));if(!r)throw Error("No scope to load");let i=this.loader.loadScope(r.id);if(!i)throw Error("Unable to load scope");this.treeSync.loadOneScope(i,!1)}}this.callbacks.updateProcessed(this.treeSync.committer.tree)}catch(e){let n=Pt(e);throw this.remoteUpdates.length=0,ct.error("Error processing remote updates:",n),ct.debug("Last update:",t),this.callbacks.errorRecoverable(),this.treeSync.error(n.message),n}}async verifyTreeWithServer(){let t=new URL(`/projects/${this.projectId}/tree/latest?forceSnapshot=true`,window.location.href),e;try{this.ignoreTreeVerifies=!0,e=await fetch(t,await it.withAuthorizationHeader({}))}finally{this.ignoreTreeVerifies=!1}if(!e.ok)throw Error(`unable to fetch document json: ${e.status} ${e.statusText}`);let n=e.headers.get("etag")||"",r=Number.parseInt(n.match(/Version-(\d+)/u)?.[1]??"0",10);if(!Number.isFinite(r)||r<=0)throw Error(`unable to parse document tree version from: ${n}`);let i=this.treeSync.treeVersion-r,s=this.treeSync.committer.getTreeForVersion(r)?.tree;if(!s)throw Error(`unable to get the local tree for version ${r}`);this.ignoreTreeVerifyVersion=r;let a=new Uint8Array(await e.arrayBuffer()),c=await this.loadServerTree(a,t.toString(),r),d=this.compareTreeWithServerJson(s,c,r);if(d)throw d;return this.url&&await this.verifyLocalTreeWithServerJson(this.url,s,r),i}async loadServerTree(t,e,n){S(!t||t instanceof Uint8Array,"treeData must be a Uint8Array");let r,i=new $n({client:0,user:""}),s=new Kt(i,this.componentLoader,n,e,{partialParsing:!0,loadInBackground:!0,loadedData:t,requestIdleCallback:this.callbacks.requestIdleCallback});return s.on("loadedFirstData",a=>{s.on("loadedScope",c=>{let d=a.root.children.findIndex(p=>p.id===c.id);a.remove(c.id),a.insertNode(c,a.root.id,d),a=a.commit(this.componentLoader)}),s.on("loadedAllData",()=>{r=a})}),await s.start(),S(r,"loadedAllData not called"),r}async loadServerJsonTree(t,e,n){let r,i=new qe(this.componentLoader,n,e,{partialParsing:!0,loadInBackground:!0,loadedData:t,requestIdleCallback:this.callbacks.requestIdleCallback});return i.on("loadedFirstData",s=>{i.on("loadedScope",a=>{let c=s.root.children.findIndex(d=>d.id===a.id);s.remove(a.id),s.insertNode(a,s.root.id,c),s=s.commit(this.componentLoader)}),i.on("loadedAllData",()=>{r=s})}),await i.start(),S(r,"loadedAllData not called"),r}flushUpdates(t){let e=this.treeSync.createMessage(this.userId);return e?(t.sendMessage({type:"rows",value:e}),!0):!1}resendUnconfirmedUpdates(t){let e=this.treeSync.createUnconfirmedMessages();for(let n of e)t.sendMessage({type:"rows",value:n})}cancelAndClearLoader(){this.loader?.scheduler.cancel(),this.loader=void 0}maybeSend(t){if(!this.treeSync.isReady||!this.treeSync.hasMessageForRemote())return"nothingToSend";if(this.treeSync.unconfirmedCrdtUpdates.size>=al)return"postpone";let n=this.treeSync.createMessage(this.userId);return n?(t.sendMessage({type:"rows",value:n}),"didSend"):"nothingToSend"}writeServerUpdateToTheStore(t){let e=new $n({client:0,user:"temp-user"});e.addSerializableRows(t.rows);let n=Os(this.store,e);return this.recorder&&this.recorder({source:"remote",rows:e.getSerializableRows()}),n}ensureAllScopesAreLoaded(t){if(!this.loader)return;let e=zs(this.store,t,this.scopeClassCache);for(let n of e){if(this.loader.hasLoadedScope(n))continue;let r=this.loader.loadScope(n);r&&this.treeSync.loadOneScope(r,!1)}}createLoader(t,e,n){this.url=t,this.loader?.scheduler.cancel();let r=new Kt(this.store,this.componentLoader,e,t,n);return this.loader=r,r.on("loadedFirstData",()=>{this.treeSync.onLoadedFirstData()}),this.loader}finishLoading(){this.loader=void 0}async verifyLocalTreeWithServer(t,e,n){try{let r=new URL(t.replace(/\d+\.crdt.*/u,n+".crdt"),window.location.href).pathname,i=new URL(r,window.location.href).toString();Te.debug("verifying local tree with server crdt:",i);let s=await fetch(i,await it.withAuthorizationHeader({}));if(!s.ok)if(s.status===404){let d=new URL(`/projects/${this.projectId}/tree/latest`,window.location.href);if(Te.debug("404, retrying crdt with:",d),s=await fetch(d,await it.withAuthorizationHeader({})),s.ok){if(!s.headers.get("etag")?.includes(n.toString()))throw Error(`lastest tree version does not match: ${s.headers.get("etag")} ${n}`)}else throw Error(`unable to fetch latest crdt document: ${s.status} ${s.statusText}`)}else throw Error(`unable to fetch crdt document: ${s.status} ${s.statusText}`);let a=new Uint8Array(await s.arrayBuffer()),c=await this.loadServerTree(a,t,n);Te.debug("using crdt from server"),this.compareTreeWithServerJson(e,c,n)}catch(r){Te.error("Error:",r),this.callbacks.error(Pt(r))}}async verifyLocalTreeWithServerJson(t,e,n){try{let r=new URL(t.replace(/\d+\.crdt.*/u,n+".json"),window.location.href).pathname,i=new URL(r,window.location.href).toString();Te.debug("verifying local tree with server json:",i);let s=await fetch(i,await it.withAuthorizationHeader({}));if(!s.ok)throw Error(`unable to fetch document json: ${s.status} ${s.statusText}`);let a=await s.text(),c=await this.loadServerJsonTree(a,i,n);Te.debug("using json from server"),this.compareTreeWithServerJson(e,c,n)}catch(r){Te.error("Error:",r),this.callbacks.error(Pt(r))}}compareTreeWithServerJson(t,e,n){Te.debug("local:",t.computeTreeHash(),t.size(),"remote:",e.computeTreeHash(),e.size(),"version:",n);let r,i=[];return wr(t,e,i)?(Te.warn(`trees are different
`+i.join(`
`)),r=Error("Local document different from server document."),Te.reportError(r,{differences:i})):i.length>0?Te.debug(`trees have warnings:
`+i.join(`
`)):Te.debug("trees are same"),r}getRowsToSend(){return this.treeSync.committer.takePendingRows(this.userId)}loadedAllScopes(){this.treeSync.loadedAllScopes()}loadOneScope(t,e){return this.treeSync.loadOneScope(t,e)}hasUnconfirmedChanges(){return this.treeSync.hasUnconfirmedChanges()}resetTreesForRecovery(t){if(!this.loader){let e=[],n=this.store.getObject(this.treeSync.committer.tree.root.id);return Yn({version:Ii,root:n},this.componentLoader,e)}return this.loader.resetForCrashRecovery(t)}error(t,e){return this.treeSync.error(t,e)}};var dt=ft(Er(),1);var ja=Symbol("uninitialized");function cl(o){return o+1}function xv(o,t,e,n){let r=gi(),[,i]=(0,dt.useReducer)(cl,0),s=(0,dt.useRef)(ja);s.current===ja&&(s.current=t());let a=(0,dt.useRef)(t);a.current=t;let c=(0,dt.useRef)(e);if(!xn(e,c.current)){c.current=e;let p=s.current,l=a.current();(n?!Vt(p,l):!xn(p,l))&&(s.current=l)}let d=Array.isArray(o)?o:[o];return(0,dt.useEffect)(()=>{let p=()=>{let y=s.current,h=a.current();(n?Vt(y,h):xn(y,h))||(s.current=h,i())},l=[...d,p],f=r.scheduler.changes.observe(...l);return()=>r.scheduler.changes.removeObserver(f)},d),s.current}var te=ft(Er(),1);var dl=0,Rr=class{constructor(){g(this,"id",++dl);g(this,"currentRtt",NaN);g(this,"rtts",[]);g(this,"rttIndex",0);g(this,"pending",Array.from(Array(128),()=>({type:"",time:0})));g(this,"start",0);g(this,"end",0);g(this,"overflow",0);g(this,"lastSendTime",0);g(this,"bytesSent",0);g(this,"bytesReceived",0)}read(){let{bytesSent:t,bytesReceived:e,id:n}=this;return this.bytesSent=0,this.bytesReceived=0,[t,e,this.rtt(),n]}computeRtt(){let t=this.rtts.length;if(t===0){this.currentRtt=NaN;return}let e=0;for(let n of this.rtts)e+=n;this.currentRtt=e/t}lastSend(){return this.lastSendTime}rtt(){return Number.isNaN(this.currentRtt)&&this.computeRtt(),Math.max(this.currentRtt||0,this.pendingRtt())}pendingRtt(){if(this.start===this.end)return 0;let t=this.pending[this.start];return performance.now()-t.time}pendingCount(t){if(!t)return this.start>this.end?128-this.start+this.end:this.end-this.start;let e=0;for(let n=this.start;n!==this.end;n=n+1&127)this.pending[n].type===t&&e++;return e}sent(t,e){this.bytesSent+=e.length,this.end===(this.start===0?127:this.start-1)&&(this.start=this.start+1&127,this.overflow++);let n=this.pending[this.end];n.type=t,n.time=performance.now(),this.end=this.end+1&127,this.lastSendTime=n.time}received(t){this.bytesReceived+=t.length}reset(){this.start=0,this.end=0,this.overflow=0,this.rtts=[],this.rttIndex=0,this.currentRtt=NaN}acked(){if(this.start===this.end){console.warn("Called SocketStats.acked() with empty buffer");return}if(this.overflow>0){this.overflow--;return}let t=this.pending[this.start],e=performance.now()-t.time;this.rtts.length<32?this.rtts.push(e):(this.rtts[this.rttIndex]=e,this.rttIndex=this.rttIndex+1&31),this.start=this.start+1&127,this.currentRtt=NaN}};var Ke=N("remote:socket"),ll=32;function ul(o){switch(o){case"AccessDenied":case"ClientNeedsUpdate":case"ClientTooNew":case"DocumentNotFound":case"UnsupportedSchema":case"Maintenance":case"UnknownPermanentError":case"ClientSidePermanentError":case"CrdtMigrationFailed":return!1;case"ReconnectToNewServer":case"UnknownRecoverableError":case"ClientSideRecoverableError":return!0;default:return Se(o)}}function zv({url:o,documentConnection:t,tunnel:e=void 0}){let n=(0,te.useRef)(null),r=(0,te.useRef)(!0),i=(0,te.useRef)({onConnect:new Set,onDisconnect:new Set,onMessage:new Set}),s=(0,te.useRef)(o),a=(0,te.useRef)(!0),c=(0,te.useRef)(void 0);function d(){c.current!==void 0&&(window.clearTimeout(c.current),c.current=void 0)}let p=(0,te.useCallback)(()=>{a.current=!1;let h=n.current;h&&h.ws.readyState<WebSocket.CLOSING&&(h.clientClosed=!0,h.ws.close())},[]),l=(0,te.useCallback)(()=>{if(d(),!a.current||n.current)return;function h(P){c.current===void 0&&(c.current=window.setTimeout(()=>{c.current=void 0,navigator.onLine&&(document.hidden&&!De.isApiPlugin||l())},P))}let m=new URL(s.current);if(m.searchParams.set("v",ll.toString()),m.searchParams.set("tunnel",e||""),jn()&&m.searchParams.set("mode","crdt"),t.treeSchema<=0)return;m.searchParams.set("treeSchema",t.treeSchema.toString()),m.searchParams.set("treeVersion",t.treeVersion.toString()),Ke.debug("connecting to",m.href);let v=performance.now(),C=new WebSocket(m.href),I=new Rr,R={ws:C,stats:I,clientClosed:!1};t.setSocketStats(I);let M=0;C.addEventListener("open",()=>{Ke.debug("open"),M=window.setInterval(()=>{if(performance.now()-I.lastSend()<1e3||I.pendingCount("ping")>1||C.readyState!==WebSocket.OPEN)return;let P="ping {}";C.send(P),I.sent("ping",P)},1e3);for(let P of i.current.onConnect)try{P(r.current)}catch(D){Ke.warn("Error in onConnect handler:",D)}r.current=!1}),C.addEventListener("close",P=>{let D=fl(P);if(Ke.debug("close:",D,"clientClosed:",R.clientClosed,P),M!==0&&(clearInterval(M),M=0),n.current===R){ul(D)||(a.current=!1);for(let x of i.current.onDisconnect)try{x(D)}catch(k){Ke.warn("Error in onDisconnect handler:",k)}if(n.current=null,a.current){let x=1e3;D==="ReconnectToNewServer"?x=50:performance.now()-v<5e3&&(x=5e3),h(x)}}}),C.addEventListener("message",P=>{try{let D=P.data;I.received(D);let x=ml(D);if(x.type==="ack"){I.acked();return}else x.type==="redirect"&&(s.current=x.value.url);for(let k of i.current.onMessage)try{k(x)}catch(re){Ke.warn("Error in onMessage handler:",re)}}catch(D){Ke.warn("Error receiving:",D)}}),n.current=R},[t]);(0,te.useEffect)(()=>{l()},[l]);let f=(0,te.useCallback)(({online:h,visible:m})=>{h&&(m||De.isApiPlugin)?l():De.isApiPlugin||d()},[l]);return pl(f),(0,te.useMemo)(()=>({getSocketStats(){return n.current?.stats},connect(){a.current=!0,l()},disconnect(){p()},onConnect(h){return i.current.onConnect.add(h),()=>{i.current.onConnect.delete(h)}},onDisconnect(h){return i.current.onDisconnect.add(h),()=>{i.current.onDisconnect.delete(h)}},onMessage(h){return i.current.onMessage.add(h),()=>{i.current.onMessage.delete(h)}},send(h){if(!n.current||n.current.ws.readyState!==1){h.type!=="state"&&Ke.warn("Dropping",h.type,"message.");return}try{let m=`${h.type} ${JSON.stringify(h.value)}`;n.current.ws.send(m),n.current.stats.sent(h.type,m)}catch(m){Ke.warn("Error sending",h.type,"message:",m)}},forceReconnect(){n.current&&(n.current.stats.reset(),n.current.clientClosed=!0,n.current.ws.close(),n.current=null),a.current=!0,l()}}),[l,p])}function pl(o){(0,te.useEffect)(()=>{document.addEventListener("visibilitychange",t),window.addEventListener("online",t),window.addEventListener("offline",t);function t(){o({online:navigator.onLine,visible:!document.hidden})}return()=>{document.removeEventListener("visibilitychange",t),window.removeEventListener("online",t),window.removeEventListener("offline",t)}},[o])}function fl(o){switch(o.reason){case"ERR_RECONNECT_TO_NEW_SERVER":return"ReconnectToNewServer";case"ERR_ACCESS_DENIED":return"AccessDenied";case"ERR_CLIENT_NEEDS_UPDATE":return"ClientNeedsUpdate";case"ERR_DOCUMENT_NOT_FOUND":return"DocumentNotFound";case"ERR_UNSUPPORTED_SCHEMA_VERSION":return"UnsupportedSchema";case"ERR_MAINTENANCE":return"Maintenance";case"ERR_INVALID_OPERATION":return"ClientSidePermanentError";case"ERR_CRDT_MIGRATION_FAILED":return"CrdtMigrationFailed";case"ERR_UNKNOWN":return"UnknownPermanentError"}return o.code===1011?"ClientNeedsUpdate":"UnknownRecoverableError"}function ml(o){let t=o.indexOf(" "),e=o.indexOf(" ",t+1);S(t>=0&&e>=0,"Invalid data");let n=o.substring(0,t),r=o.substring(t+1,e),i=o.substring(e+1),s=JSON.parse(i);return{id:n,type:r,value:s}}function Wa(o){return typeof o=="object"&&o!==null&&"next"in o}function Dr(o){return Wa(o)&&"session"in o}function Nr(o){return Wa(o)&&"changes"in o&&Array.isArray(o.changes)}var $e=N("remote:sync"),Ga=2**52,Pr=class{constructor(t,e,n=0,r){this.timeline=t;this.componentLoader=e;g(this,"rollingDiff",null);g(this,"session",Math.floor(Math.random()*Ga));g(this,"seq",0);g(this,"treeVersion",0);g(this,"updatesSeen",0);g(this,"init",0);g(this,"expectingInitialUpdates",0);g(this,"localUpdatesInFlight",[]);g(this,"localUpdatesAtInit",[]);g(this,"hasError",!1);g(this,"waitingForTree",!1);this.setTree(t.tree,n,r)}get waitingForInitialUpdates(){return this.expectingInitialUpdates>this.updatesSeen}get isLoading(){return this.waitingForTree||this.waitingForInitialUpdates}get isReady(){return!(this.hasError||this.waitingForTree||this.waitingForInitialUpdates)}get tree(){return this.timeline.tree}error(t,e){return this.hasError=!0,Error(t,{cause:e})}verify(t,e){let n=this.timeline.getTreeForVersion(t);if(!n)return $e.info("verify: unable to find tree with version",t),!0;let r=n.computeTreeHash();if(r!==e){if($e.warn("verify: failed",r,"!==",e),e===0)return!0;$e.reportError("Tree verification failed",{localHash:r,serverHash:e,treeVersion:t,treeSize:n.size()})}else $e.debug("verify: passed; hash:",e);return r===e}setTree(t,e,n){$e.info("setTree",e),this.timeline.reset(t,n),this.setRemoteTreeVersion(e),!!n?.isLoading&&(this.rollingDiff=new Us,this.rollingDiff.addChanges(n?.initialChanges)),this.treeVersion=e,this.waitingForTree=!1,this.hasError=!1,this.localUpdatesInFlight=[]}resetSession(){this.treeVersion=0,this.session=Math.floor(Math.random()*Ga),this.localUpdatesInFlight=[],this.localUpdatesAtInit=[]}debugResetSessionAndTree(t){this.resetSession(),this.setTree(t,0)}handleInit(t,e){return this.init+=1,this.init===1&&pe("wsTreeInitMessages"),$e.info("init",this.init,{treeVersion:t,initialUpdates:e,localTreeVersion:this.treeVersion}),$e.debug("init updates:",{seen:this.updatesSeen,inFlight:this.localUpdatesInFlight.length,previous:this.localUpdatesAtInit.length}),this.hasError=!1,this.expectingInitialUpdates=e,this.updatesSeen=0,this.localUpdatesAtInit=this.localUpdatesInFlight.slice(),this.treeVersion!==t||this.waitingForTree?(this.waitingForTree=!0,!0):!1}trimForShallowLoading(){let t=this.timeline,e=this.getRemoteIndex()-3;e<=0||(t.trimmed+=e,$e.debug("trim",e,"new offset:",t.trimmed,"entries.length:",t.entries.length,"after load"),t.entries.splice(0,e),S(this.timeline.remoteTreeIndex===0||this.getRemoteIndex()>=0,"must have some buffer before remoteTreeIndex"))}loadedAllScopes(){let t=this.timeline;$e.info("done loading, took:",Math.round((performance.now()-t.resetTime)/100)/10,"seconds"),S(t.isPartialLoading,"Must be in loading mode"),t.isPartialLoading=!1,this.rollingDiff=null;let e=this.getRemoteEntry();e&&(e.version=t.remoteTreeVersion,this.trimForShallowLoading())}loadOneScope(t,e){let n=this.timeline;$e.debug("loadOneScope:",t.id),S(n.isPartialLoading,"Must be loading"),S(!t.cache.isShallowLoad,"Scope must not be shallow");let r=this.getRemoteEntry();S(r,"remote tree is missing");let i=n.tree.isViewOnly;r.tree.editClosed=!1,r.tree.isViewOnly=!1,r.tree.inEditor=!1,r.tree.makeLatest();let s=new Set,a=r.tree.root.children.findIndex(d=>d.id===t.id);if(t.__class==="WebPageNode"||t.__class==="SmartComponentNode"){Bs(t),r.tree=r.tree.commitWithLoadedScope(this.componentLoader,t);for(let d of t.walk())n.trackChange(d.id),s.add(d.id)}else r.tree.remove(t.id),r.tree.insertNode(t,r.tree.root.id,a);if(this.rollingDiff){let d=this.rollingDiff.getChanges();s.size>0?Qr(d,s)&&rt(r.tree,d):rt(r.tree,d)}else{let d=0,p=s.size>0,l=this.getRemoteIndex();for(let f of n.entries){if(d>l)break;d++,!f.wasScopeInsert&&(p&&!Qr(f.changes,s)||(p=!1,rt(r.tree,f.changes)))}}a===-1?S(!r.tree.get(t.id),"Scope must have been deleted by remote diffs"):r.tree.loadReplicasAndCodeComponents(t);let c=r.tree.commit(this.componentLoader,(d,p)=>{let l=d?.id??p?.id;l&&n.trackChange(l)});return r.tree.inEditor=!0,c.inEditor=!0,this.incrementRemoteTreeIndex(),e||(n.latestReversibleNodeChanges=null),this.addTreeToTimeline(c),n.legacyMode&&n.invalidateAllCursors(),n.tree.isViewOnly=i,this.rollingDiff&&this.trimForShallowLoading(),n.tree}getRemoteEntry(){return this.timeline.getEntry(this.getRemoteIndex())}setRemoteTreeVersion(t){if(this.timeline.remoteTreeVersion=t,this.timeline.isPartialLoading)return;let e=this.getRemoteEntry();S(e,"remote tree is missing"),e.version=t}};var Le=N("remote:sync"),xr=class extends Pr{constructor(){super(...arguments);g(this,"localChangesSentToRemote",0)}setTree(e,n,r){super.setTree(e,n,r),this.localChangesSentToRemote=0}handleRemoteUpdate(e){if(this.hasError||this.waitingForTree)return;S(typeof e.next=="number","must be a valid tree update");let n=e.next;if(Le.trace("this:",this.session,this.seq,"at:",this.treeVersion,"update:",e),n!==this.treeVersion+1){if(n<=this.treeVersion){Le.debug("ignoring old update:",n," <= ",this.treeVersion);return}throw this.error("missing update: "+this.treeVersion+" + 1 != "+n)}if(this.updatesSeen+=1,this.treeVersion=n,Dr(e)&&e.session===this.session){let r=this.localUpdatesInFlight[0];if(r?.seq===e.seq)this.localUpdatesInFlight.shift(),this.confirmLocalChangesByRemote(r.count,n),r.confirmed=!0;else{let i=this.localUpdatesAtInit.find(s=>s.seq===e.seq);if(i)this.insertRemoteChanges(i.changes,n),i.confirmed=!0;else{let s=this.localUpdatesInFlight.findIndex(c=>c.seq===e.seq),a=s===-1?"unknown local update: "+e.seq+" != "+r?.seq:"missing local update: "+e.seq+" != "+r?.seq+", is index: "+s;throw this.error(a)}}}else Nr(e)?e.changes.length>0&&this.insertRemoteChanges(e.changes,n):Le.reportErrorOncePerMinute(new Error("Unknown remote update"),{update:e})}confirmLocalChangesByRemote(e,n=0){let r=this.timeline;if(S(e>=1,"cannot confirm less than one change"),S(this.localChangesSentToRemote>=e,"cannot confirm local changes that have not been sent"),S(r.remoteTreeIndex<r.localTreeIndex,"must have unconfirmed local changes"),this.rollingDiff)for(let i=1;i<=e;i++)this.rollingDiff.addChanges(r.getEntry(r.remoteTreeIndex+i)?.changes);return this.localChangesSentToRemote-=e,r.incrementRemoteTreeIndex(e),this.setRemoteTreeVersion(n),r.tree}insertRemoteChanges(e,n=0){let r=this.timeline;Le.debug("insertRemoteChanges:",e.length),S(r.tree===r.getLastEntry().tree,"tree out of sync"),S(r.remoteTreeIndex<=r.localTreeIndex,"remote tree too far ahead"),this.rollingDiff&&this.rollingDiff.addChanges(e);let i=this.getRemoteEntry();S(i,"remote tree is missing");let s=r.tree.isViewOnly;i.tree.editClosed=!1,i.tree.isViewOnly=!1,i.tree.makeLatest(),i.tree.beginAllowPartialScopeAccess(),rt(i.tree,e);let a=i.tree.commitDiffs(this.componentLoader);for(let d of e)r.trackChange(d.id,d);for(let d of i.tree.getNodesChangedByCommit())r.trackChange(d.id);r.incrementRemoteTreeIndex(1),r.latestReversibleNodeChanges=null;let c=r.entries.length-this.getRemoteIndex();return S(c>=0,"computed rebase is off"),c===0?this.addRemoteTreeWithChanges(a,e):this.rebaseRemoteTreeWithChanges(a,e,c),this.trim(),this.setRemoteTreeVersion(n),i.tree.endAllowPartialScopeAccess(),r.tree.isViewOnly=s,r.tree}addRemoteTreeWithChanges(e,n){Le.trace("addRemoteTreeWithChanges:",n.length);let r=this.timeline.getLastEntry();return S(e.lineage===r.tree.lineage,"Trees must belong to the same line."),S(!e.hasUncommittedChanges(),"Tree cannot have uncommitted changes."),r.tree!==e&&r.tree.releaseMemory(),this.timeline.addEntry(e,n)}rebaseRemoteTreeWithChanges(e,n,r){let i=this.timeline;Le.debug("rebaseRemoteTreeWithChanges:",r,"changes:",n.length),S(e.lineage===i.getLastEntry().tree.lineage,"Trees must belong to the same line."),S(!e.hasUncommittedChanges(),"Tree cannot have uncommitted changes."),S(i.entries.length>=r,"rebase",r,"> commits",i.entries.length);let s=i.entries.splice(i.entries.length-r,r);S(s.length===r,"must have",r,"entries to process");let a=i.addEntry(e,n,[],!0),c=e;for(let d=0;d<r;d++){let p=s[d];rt(e,p.changes),e=e.commitDiffs(this.componentLoader);for(let l of p.changes)i.trackChange(l.id,l);for(let l of c.getNodesChangedByCommit())i.trackChange(l.id);i.addEntry(e,p.changes,p.editReasons,p.wasRebase),e!==c&&(c.releaseMemory(),c=e)}return i.tree=e,a}addTreeToTimeline(e){let r=this.timeline.entries.length-this.getRemoteIndex();S(r>=0,"computed rebase is off");let i;r===0?i=this.addRemoteTreeWithChanges(e,[]):i=this.rebaseRemoteTreeWithChanges(e,[],r),i.wasScopeInsert=!0}loadCompleteTree(e,n=0){let r=this.timeline;Le.debug("load complete tree:",r.tree.sizeAtStart(),"->",e.size(),"entries:",r.entries.length),S(r.trimmed===0,"cannot load complete tree while having local changes"),S(!e.hasUncommittedChanges(),"tree should be clean"),r.entries.forEach((c,d)=>{d>r.remoteTreeIndex||rt(e,c.changes)}),e.hasUncommittedChanges()&&(e=e.commitDiffs(this.componentLoader));let i=[],s=r.tree;if(s.sizeAtStart()*2>e.size()){let c={};for(let d of e.root.walk()){let p=s.getNodeAtStart(d.id)||void 0,l=Zi(p,d);l&&(c[l.id]=l),r.trackChange(d.id,l)}i=Object.values(c),Le.debug("load complete tree, diff:",i.length)}else r.invalidateAllCursors(),Le.debug("load complete tree, resending:",r.tree.size());r.incrementRemoteTreeIndex(1),r.latestReversibleNodeChanges=null;let a=r.entries.length-r.remoteTreeIndex;return S(a>=0,"computed rebase is off"),e.lineage!==r.tree.lineage?(r.reset(e),this.setRemoteTreeVersion(n),r.tree):(a===0?this.addRemoteTreeWithChanges(e,i):this.rebaseRemoteTreeWithChanges(e,i,a),this.setRemoteTreeVersion(n),this.trim(),r.tree.forEachNode(c=>r.trackChange(c.id)),r.tree)}incrementRemoteTreeIndex(){this.timeline.incrementRemoteTreeIndex(1)}getRemoteIndex(){return this.timeline.remoteTreeIndex-this.timeline.trimmed}getUnconfirmedChangeCount(){return this.timeline.localTreeIndex-this.timeline.remoteTreeIndex}hasChangesForRemote(){let e=this.timeline.remoteTreeIndex+this.localChangesSentToRemote,n=this.timeline.localTreeIndex;return S(e<=n,"inconsistency in getting local changes to send"),e<n}hasOnlyEmptyChangesForRemote(){let e=this.timeline.remoteTreeIndex+this.localChangesSentToRemote,n=this.timeline.localTreeIndex;return e>=n?!0:this.timeline.computeForwardChanges(e,n).length===0}createUpdateToSend(){if(!this.isReady)throw Error("cannot create updates while not ready");if(!this.hasChangesForRemote())return null;let{changes:e,count:n,reasons:r}=this.getForwardChangesForRemote(),i=++this.seq,s={session:this.session,seq:i,changes:e,count:n,reasons:r,confirmed:!1};return this.localUpdatesInFlight.push(s),s}getForwardChangesForRemote(){let e=this.timeline.remoteTreeIndex+this.localChangesSentToRemote,n=this.timeline.localTreeIndex,r=this.timeline.getChangesBetweenEntries(e,n);return this.localChangesSentToRemote+=r.count,r}commitAndCreateUpdate(e=0){S(De.isTest),this.timeline.commitLocalTree();let n=this.createUpdateToSend();return n?Oa(n,e):null}resetTreesForRecovery(){return Le.info("reset trees for recovery, remote:",this.getRemoteIndex(),"last index:",this.timeline.localTreeIndex,"number of entries to reapply to remote tree",this.localChangesSentToRemote),this.timeline.resetTreesForRecovery(this.getRemoteIndex(),this.localChangesSentToRemote)}trim(){if(this.timeline.isPartialLoading)return;let e=0;this.timeline.remoteTreeIndex>0?e=this.getRemoteIndex()-100:e=this.timeline.localTreeIndex-this.timeline.trimmed-100,!(e<=75)&&(this.timeline.trimmed+=e,Le.debug("trim",e,"new offset:",this.timeline.trimmed,"entries.length:",this.timeline.entries.length),this.timeline.entries.splice(0,e),S(this.timeline.remoteTreeIndex===0||this.getRemoteIndex()>=0,"must have some buffer before remoteTreeIndex"))}};var Qt=N("remote:connection"),Tt=N("remote:verify"),hl=5,Ja=class{constructor(t,e,n,r){this.componentLoader=e;this.projectId=n;this.callbacks=r;g(this,"treeSync");g(this,"remoteUpdates",[]);g(this,"ignoreTreeVerifies",!1);g(this,"ignoreTreeVerifyVersion",0);g(this,"shouldCrashFromDebug",!1);g(this,"loader");S(t instanceof As,"timeline must be a TreeTimeline"),this.treeSync=new xr(t,e),this.treeSync.waitingForTree=!0}get init(){return this.treeSync.init}setTree(t,e,n){this.treeSync.setTree(t,e,n)}get timeline(){return this.treeSync.timeline}get treeVersion(){return this.treeSync.treeVersion}get isReady(){return this.treeSync.isReady}get waitingForTree(){return this.treeSync.waitingForTree}get isLoading(){return this.treeSync.isLoading}get session(){return this.treeSync.session}resetSession(){this.treeSync.resetSession()}debugResetSessionAndTree(t){this.treeSync.debugResetSessionAndTree(t)}debugCrash(){this.shouldCrashFromDebug=!0}canProcessChanges(){if(this.treeSync.trim(),!this.treeSync.isReady||this.shouldCrashFromDebug){if(this.treeSync.hasOnlyEmptyChangesForRemote())return!1;let t="is not ready";throw this.treeSync.hasError?t="had an error":this.treeSync.waitingForTree?t="is waiting for tree data":this.treeSync.waitingForInitialUpdates?t="is waiting for initial updates":this.shouldCrashFromDebug&&(this.shouldCrashFromDebug=!1,t="is doing a deliberate crash test"),this.treeSync.error("cannot create local updates when the document "+t)}return!0}processViewOnly(){if(!this.treeSync.hasChangesForRemote())return;let{changes:t,count:e}=this.treeSync.getForwardChangesForRemote();Qt.warn("cannot create local updates when the user is a viewer, ignoring:",t),this.treeSync.confirmLocalChangesByRemote(e)}maybeSend(t){if(!this.treeSync.isReady||!this.treeSync.hasChangesForRemote())return"nothingToSend";let e=this.treeSync.localUpdatesInFlight.length;if(e>=hl)return"postpone";let n=this.treeSync.createUpdateToSend();return n?(Qt.debug("sending update:",e,n.changes.length,n.reasons),t.sendMessage({type:"treeUpdate",value:Tr(n)}),"didSend"):"nothingToSend"}handleRows(){throw Error("Crdt tree updates cannot be handled by Json data handler")}handleConfirmRows(){throw Error("Crdt tree updates cannot be handled by Json data handler")}get hasUpdatesToProcess(){return!this.waitingForTree&&this.remoteUpdates.length>0}handleInit(t,e){return this.remoteUpdates.length=0,{needsDownload:this.treeSync.handleInit(t,e)}}handleTreeVerify(t,e,n){if(!this.treeSync.isReady||this.ignoreTreeVerifies||this.ignoreTreeVerifyVersion===e)return;if(!this.treeSync.verify(e,n)){let s=this.treeSync.timeline.getTreeForVersion(e);if(s){let c=this.treeSync.timeline.entries.slice();this.verifyLocalTreeWithServer(t,s,e,c)}this.remoteUpdates.length=0,this.treeSync.hasError=!0;let a=new Error("Local document out of sync with document on server.");this.callbacks.error(a);return}let r=qn(),i=xt.isDevelopment||xt.isLocal;if(r||i){let s=this.treeSync.timeline.getTreeForVersion(e);if(s){let a=this.treeSync.timeline.entries.slice();this.verifyLocalTreeWithServer(t,s,e,a)}}}async verifyLocalTreeWithServer(t,e,n,r){try{let i=t.replace(/\d+\.json/u,n+".json"),s=await fetch(i,await it.withAuthorizationHeader({}));if(!s.ok)throw Error(`unable to fetch document json: ${s.status} ${s.statusText}`);let a=await s.text(),c=await this.loadServerTree(a,i,n);this.compareTreeWithServerJson(e,c,n,r)}catch(i){Tt.error("Error:",i)}}compareTreeWithServerJson(t,e,n,r){Tt.debug("local:",t.computeTreeHash(),t.size(),"remote:",e.computeTreeHash(),e.size(),"version:",n);let i,s=[];return wr(t,e,s)?(Tt.warn(`trees are different
`+s.join(`
`)),r&&Tt.debug("timeline.entries",r),i=Error("Local document different from server document."),Tt.reportError(i,{differences:s,changes:r?.slice(-25).map(c=>c.changes)})):s.length>0?Tt.debug(`trees have warnings:
`+s.join(`
`)):Tt.debug("trees are same"),i}handleTreeUpdate(t){this.remoteUpdates.push(t)}processRemoteUpdates(){if(this.treeSync.waitingForTree)return;let t;try{if(S(!this.timeline.tree.hasUncommittedChanges(),"tree must not have uncommitted changes"),this.shouldCrashFromDebug)throw this.shouldCrashFromDebug=!1,Error("RemoteDocument CrashTest");for(;this.remoteUpdates.length>0;){let e=this.remoteUpdates.shift();if(!e)break;t=e,this.ensureAllScopesAreLoaded(e),this.treeSync.handleRemoteUpdate(e),this.loader&&!Dr(e)&&this.loader.addNodeChanges(e.changes)}if(this.loader){let e=this.timeline.tree.root.children;if(!e.some(r=>Ue(r)&&r.isValid())){Qt.info("cannot show any page, forcing load of next page");let r=e.find(s=>Ue(s));if(!r)throw Error("No scope to load");let i=this.loader.loadScope(r.id);if(!i)throw Error("Unable to load scope");this.treeSync.loadOneScope(i,!1)}}this.callbacks.updateProcessed(this.timeline.tree)}catch(e){let n=Pt(e);throw this.remoteUpdates.length=0,Qt.error("Error processing remote updates:",n),Qt.debug("Last update:",t),this.treeSync.error(n.message),this.callbacks.errorRecoverable(),n}}ensureAllScopesAreLoaded(t){if(!this.loader||!Nr(t))return;let e=new Set;for(let n of t.changes)n.previousScope&&(e.add(n.previousScope),e.add(n.to.parentid));for(let n of e){if(this.loader.hasLoadedScope(n))continue;let r=this.loader.loadScope(n);r&&this.treeSync.loadOneScope(r,!1)}}createLoader(t,e,n){this.loader?.scheduler.cancel();let r=new qe(this.componentLoader,e,t,n);return this.loader=r,this.loader}async verifyTreeWithServer(){let t=new URL(`/projects/${this.projectId}/tree/latest?forceSnapshot=true`,window.location.href),e;try{this.ignoreTreeVerifies=!0,e=await fetch(t,await it.withAuthorizationHeader({}))}finally{this.ignoreTreeVerifies=!1}if(!e.ok)throw Error(`unable to fetch document json: ${e.status} ${e.statusText}`);let n=e.headers.get("etag")||"",r=Number.parseInt(n.match(/Version-(\d+)/u)?.[1]??"0",10);if(!Number.isFinite(r)||r<=0)throw Error(`unable to parse document tree version from: ${n}`);let i=this.treeSync.treeVersion-r,s=this.treeSync.timeline.getTreeForVersion(r);if(!s)throw Error(`unable to get the local tree for version ${r}`);this.ignoreTreeVerifyVersion=r;let a=await e.text(),c=await this.loadServerTree(a,t.toString(),r),d=this.compareTreeWithServerJson(s,c,r);if(d)throw d;return i}async loadServerTree(t,e,n){S(!t||K(t),"treeData must be a string");let r,i=new qe(this.componentLoader,n,e,{partialParsing:!0,loadInBackground:!0,loadedData:t,requestIdleCallback:this.callbacks.requestIdleCallback});return i.on("loadedFirstData",s=>{i.on("loadedScope",a=>{let c=s.root.children.findIndex(d=>d.id===a.id);s.remove(a.id),s.insertNode(a,s.root.id,c),s=s.commit(this.componentLoader)}),i.on("loadedAllData",()=>{r=s})}),await i.start(),S(r,"loadedAllData not called"),r}get localUpdatesInFlight(){return this.treeSync.localUpdatesInFlight}get localUpdatesAtInit(){return this.treeSync.localUpdatesAtInit}get hasError(){return this.treeSync.hasError}flushUpdates(t){if(this.localUpdatesInFlight.length===0)return!1;let e=this.treeSync.createUpdateToSend();return e&&t.sendMessage({type:"treeUpdate",value:Tr(e)}),!0}resendUnconfirmedUpdates(t){S(this.isReady);let e=this.localUpdatesAtInit.filter(n=>!n.confirmed);if(e.length!==0){Qt.debug("resending local updates:",e.length);for(let n of e)t.sendMessage({type:"treeUpdate",value:Tr(n)})}}cancelAndClearLoader(){this.loader?.scheduler.cancel(),this.loader=void 0}finishLoading(){this.loader=void 0}loadOneScope(t,e){return this.treeSync.loadOneScope(t,e)}loadedAllScopes(){this.treeSync.loadedAllScopes()}hasUnconfirmedChanges(){return this.treeSync.getUnconfirmedChangeCount()>0}resetTreesForRecovery(t){return this.treeSync.resetTreesForRecovery()}error(t){return this.treeSync.error(t)}};var gl={Today:0,Yesterday:1,"Last 7 days":7,"Last 30 days":30,"Last 90 days":90};function yb(o){let t=gl[o],e=or(0);if(o==="Yesterday"){let n=or(-1);return[n,n]}return t===0?[e,e]:[or(-t),e]}function Vo(o){if(o<1)return Vo(o+1)*Math.pow(Math.random(),1/o);let t=o-1/3,e=1/Math.sqrt(9*t);for(;;){let n=0,r=0;do{let s=Math.random(),a=Math.random();n=Math.sqrt(-2*Math.log(s))*Math.cos(2*Math.PI*a),r=1+e*n}while(r<=0);r=r*r*r;let i=Math.random();if(i<1-.0331*(n*n)*(n*n)||Math.log(i)<.5*n*n+t*(1-r+Math.log(r)))return t*r}}function qa(o,t,e=.95,n=5e3){let r=t+1,i=o-t+1,s=[];for(let l=0;l<n;l++){let f=Vo(r),y=Vo(i);s.push(f/(f+y))}s.sort((l,f)=>l-f);let a=(1-e)/2,c=1-a,d=s[Math.floor(s.length*a)]??0,p=s[Math.floor(s.length*c)]??0;return[d,p]}var yl=864e5,Sl=36e5;function vl(o,t){return _i({start:o,end:t}).map(e=>e.toISOString())}function bl(o,t){let e=[],n=o.getTime(),r=t.getTime();for(;n<=r;)e.push(new Date(n).toISOString()),n+=Sl;return e}function Cl(o,t){return Oi({start:o,end:t}).map(e=>e.toISOString())}function Tl(o,t){let e=[],n=o.getTime(),r=t.getTime();for(;n<=r;)e.push(new Date(n).toISOString()),n+=yl;return e}function Ha(o,t,e,n,r="local"){let i=o.map(({timestamp:f})=>new Date(f)).sort((f,y)=>f.getTime()-y.getTime()),s=r==="utc"?new Date(t):so(t),a=r==="utc"?new Date(e):so(e),c=i[0],d=i[i.length-1],p=c&&c>s?c:s,l=d&&d>a?d:a;return n==="hour"?r==="utc"?bl(p,l):vl(p,l):r==="utc"?Tl(p,l):Cl(p,l)}function wl(o,t,e){let r=e.length,i=new Map;for(let{step:p,count:l}of t){let f=i.get(p)??0;i.set(p,f+l)}let s=i.get(1)??0,a=i.get(r)??0,c=s>0?a/s:0,d=[];for(let p=1;p<=r;p++){let l=i.get(p)??0;if(p>1&&l>0&&(i.get(p-1)??0)<l){let h=d[d.length-1];h&&(h.count=l,h.cumulativeDropOff=s>0?(s-l)/s:0)}let f=s>0?(s-l)/s:0;d.push({step:p,count:l,cumulativeDropOff:f,stepwiseDropOff:0})}return{timestamp:o,startCount:s,finalCount:a,conversionRate:c,funnelSteps:d}}function Il(o,t,e,n){let i=e.length,s=Map.groupBy(t,c=>c.abVariantId),a=[];for(let[c,d]of s){let p=n.get(c);p||(p=new Map,n.set(c,p));for(let{step:m,count:v}of d){let C=p.get(m)??0;p.set(m,C+v)}let l=p.get(1)??0,f=p.get(i)??0;if(l===0||f>l)continue;let y=l>0?f/l:0,h=qa(l,f);a.push({abVariantId:c,startCount:l,finalCount:f,conversionRate:y,conversionRateCredibleInterval:h})}return{timestamp:o,variants:a}}function Rl(o){return o[0]?.abVariantId!==void 0}function Fo(o,t,e,{fromDay:n,toDay:r},i){if(o.length===0)return[];let s=Rl(o),a=new Map,c=Ha(o,n,r,t,i),d=Map.groupBy(o,l=>l.timestamp),p=[];for(let l of c){let f=d.get(l)??[];f.length===0&&p.length===0||(s?p.push(Il(l,f,e,a)):p.push(wl(l,f,e)))}return p}function Ka(o,t){return 1-o/t}function Eo(o,t){let e=o[0],n=0;if(!e)return[];let r="abVariantId"in e?e.abVariantId:void 0;return o.reduce((i,{step:s,count:a,abVariantId:c},d)=>{let p=0,l=0;return d>0&&(p=a===0?1:Ka(a,e.count),l=n===0?1:Ka(a,n)),i[d]={step:s,count:a,cumulativeDropOff:p,stepwiseDropOff:l,...c&&{abVariantId:c}},n=a,i},t.map((i,s)=>({step:s+1,count:0,cumulativeDropOff:1,stepwiseDropOff:1,abVariantId:r})))}var Dl="all",Nl="other";function Lr(o,t){return t?Map.groupBy(o,e=>e[t]??Nl):new Map([[Dl,o]])}var Xa=20;function Fb(o,t,e){let n=t.fromDay===t.toDay?"hour":"day";return Qe("stats",o,t,e,{granularity:n})}function Eb(o,t,e){return Qe("session-stats",o,t,e)}function Mb(o,t,e){return Qe("live-sessions",o,t,e)}function kb(o,t,e,n,r=Xa){return Qe("top-field",o,e,n,{name:t,limit:String(r)})}function Ub(o,t,e,n,r=Xa){return Qe("top-fields",o,e,n,{names:t,limit:String(r)})}async function Ab(o,t,e){if(t.steps.length===0)return;let{dropOff:n}=await Qe("funnel-drop-off",o,t,e),r=Lr(n,t.groupBy),i=new Map;return r.forEach((s,a)=>{i.set(a,Eo(s,t.steps))}),i}async function Bb(o,t,e){if(t.steps.length===0)return;let{counts:n,granularity:r}=await Qe("funnel-counts",o,t,e),i=Lr(n,t.groupBy),s=new Map;return i.forEach((a,c)=>{s.set(c,Fo(a,r,t.steps,t))}),s}async function zb(o,t,e){let{dropOff:n,metrics:r}=await Qe("funnel-drop-off",o,t,e),i=Lr(n,"abVariantId"),s=new Map;return i.forEach((a,c)=>{s.set(c,Eo(a,t.steps))}),{dropOff:s,metrics:r}}async function Ob(o,t,e){let{counts:n,granularity:r}=await Qe("funnel-counts",o,t,e);return Fo(n,r,t.steps,t,"utc")}var Qa=Intl.DateTimeFormat().resolvedOptions().timeZone;async function Qe(o,t,{fromDay:e,toDay:n,filters:r,steps:i,funnelFilters:s,groupBy:a,abTestId:c,controlVariantId:d},p,l){let f=new URLSearchParams;if(e&&f.set("startDate",e),n&&f.set("endDate",n),Qa&&!c&&f.set("timezone",Qa),r)for(let h in r){let m=r[h];m&&f.set(h,m.value)}if(l)for(let[h,m]of Object.entries(l))if(Array.isArray(m))for(let v of m)f.append(h,v);else f.set(h,m);if(c&&f.set("abTestId",c),d&&f.set("controlVariantId",d),i&&i.length>0&&f.set("steps",JSON.stringify(i)),s)for(let h in s){let m=s[h];if(m)for(let v of m)f.append(h,v)}return a&&(f.set("groupBy",a),f.set("groupByLimit","5")),await ir.get(`/web/v3/projects/${t}/site-stats/${o}?${f.toString()}`,void 0,p)}async function Gb(o,t){return ir.get(`/web/v1/sites/hostnames/${o}`,void 0,t)}var Ya=class extends Un{};var Za=class{constructor(){g(this,"undoBuffer",[]);g(this,"redoBuffer",[]);g(this,"undoGroup",[]);g(this,"scheduledEndUndoGroup")}canUndo(){return this.undoBuffer.length>0}peekUndo(){return this.undoBuffer.at(-1)}undo(t,e){let n=this.undoBuffer.pop();if(U(n))return;t.applyReverseChanges(n.changes),this.redoBuffer.push({...n,...e});let r=this.undoBuffer.length;return this.undoGroup.forEach((i,s)=>{this.undoGroup[s]=Math.min(i,r)}),n}canRedo(){return this.redoBuffer.length>0}peekRedo(){return this.redoBuffer.at(-1)}redo(t,e){let n=this.redoBuffer.pop();if(!U(n))return t.applyChanges(n.changes),this.undoBuffer.push({...n,...e}),n}beginUndoGroup(){this.undoGroup.push(this.undoBuffer.length)}discardUndoGroup(t){let e=this.undoGroup.pop();if(U(e)||e>=this.undoBuffer.length)return;let n=this.undoBuffer.splice(e),r=Kr(n);return t.applyReverseChanges(r),n[0]}scheduleEndUndoGroup(){let t=this.undoGroup.pop();U(t)||t>=this.undoBuffer.length||(this.scheduledEndUndoGroup=t)}processScheduledEndUndoGroup(t){let e=this.scheduledEndUndoGroup;if(this.scheduledEndUndoGroup=void 0,U(e)||e>=this.undoBuffer.length)return;let n=this.undoBuffer.splice(e),r=Kr(n);this.undoBuffer.push({changes:r,...t})}clearUndoStack(){this.undoBuffer.length=0,this.redoBuffer.length=0,this.undoGroup.length=0,this.scheduledEndUndoGroup=void 0}addUndoEntry(t){this.undoBuffer.push(t),this.redoBuffer.length=0}getUndoBufferSize(){return this.undoBuffer.length}};var ec="utils";function tc(o,t){let e=Re(t);if(!Lt(e)||e.kind!=="localModuleExport")return;let n=o.getPersistedModuleByLocalId(e.localId);if(n&&n.exports.includes(ec))return{exportIdentifier:ec,moduleURL:n.moduleURL,collectionId:e.localIdName}}function eC(o,t){if(F(t)&&t.dataIdentifier)return tc(o,t.dataIdentifier)}function tC(o,t,e){for(let n of t.variables){if(!di(n))continue;let r=tc(o,n.dataIdentifier);r&&e(r)}}function oC(o,t){let e=t.getPrimaryVariant();qr(e)&&(o.routes[t.id]=e.pageEffects)}function iC(o,t,e){let n=t.getPrimaryVariant();if(qr(n)){let r={};for(let i in n.pageEffects)r[i]=e.dedupe("effect",n.pageEffects[i]);o.routes[t.id]=r}}var Pl=N("exportToHTML");function nc(o,t,e,n=new Set([e]),r=new Set){for(let{node:i,skipChildren:s}of e.walkWithSkipChildren()){if(r.has(i)){s();continue}r.add(i);for(let a of Fi(i,t)){let c=Vi(a);if(!c)continue;let d=o.getNode(c);if(d){if(!o.isGroundNode(d)){Pl.reportError("Navigation target node must be ground node",{sourceId:i.id,targetId:d.id});continue}n.add(d),nc(o,t,d,n,r)}}Ze(i)&&Object.values(es(o,i,t)).flat().forEach(a=>nc(o,t,a.node,n,r))}return n}function mC(o,t,e,n=void 0){if(!e&&!n)return;let r=n??ns(e??[]);r.length&&Is.resetPropertiesToMasterValues(o,t,r)}export{gl as a,yb as b,Fb as c,Eb as d,Mb as e,kb as f,Ub as g,Ab as h,Bb as i,zb as j,Ob as k,tc as l,eC as m,tC as n,oC as o,iC as p,cy as q,nc as r,mC as s,Va as t,xa as u,xe as v,ac as w,Iu as x,Ru as y,dc as z,py as A,Aa as B,$l as C,jl as D,Wl as E,lo as F,dr as G,qe as H,Kt as I,Lo as J,Gb as K,Ya as L,xv as M,Za as N,Rr as O,ll as P,ul as Q,zv as R,fl as S,ml as T,Ja as U};
//# sourceMappingURL=https://app.framerstatic.com/chunk-MLB6MY3K.mjs.map
