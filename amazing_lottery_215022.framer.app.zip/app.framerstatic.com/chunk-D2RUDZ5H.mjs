import{sd as n,ts as r}from"https://app.framerstatic.com/chunk-LGEU5DK3.mjs";function a(o){for(let t in o.pathVariables){let e=o.pathVariables[t];if(r(e))return e}}function c(o,t){let e=o.getNode(t.webPageId);return n(e)?e:null}export{a,c as b};
//# sourceMappingURL=https://app.framerstatic.com/chunk-D2RUDZ5H.mjs.map
