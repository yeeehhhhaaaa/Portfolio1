import{b as r}from"https://app.framerstatic.com/chunk-6QFQV45R.mjs";r();
//# sourceMappingURL=https://app.framerstatic.com/chunk-MSD4OAKF.mjs.map
