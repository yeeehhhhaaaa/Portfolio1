import{a as e}from"https://app.framerstatic.com/chunk-FDX2C2EY.mjs";function o(){return e("(prefers-color-scheme: dark)")}export{o as a};
//# sourceMappingURL=https://app.framerstatic.com/chunk-IM24HCZX.mjs.map
