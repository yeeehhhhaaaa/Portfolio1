import{c as a}from"https://app.framerstatic.com/chunk-AHQIRSXG.mjs";var d=a((i,e)=>{"use strict";e.exports=typeof globalThis.ReactDOM>"u"?void 0:globalThis.ReactDOM});export{d as a};
//# sourceMappingURL=https://app.framerstatic.com/chunk-ZTI6U46V.mjs.map
